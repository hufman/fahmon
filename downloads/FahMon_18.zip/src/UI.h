/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _UI_H
#define _UI_H

#include "fahMon.h"


class UI
{
public:
  static void setVisible(HWND hItem, BOOL visibility)
  {
    ShowWindow(hItem, visibility);
  }

  static void show(HWND hItem)
  {
    ShowWindow(hItem, TRUE);
  }

  static void hide(HWND hItem)
  {
    ShowWindow(hItem, FALSE);
  }

  static void setEnabled(HWND hItem, bool enabled)
  {
    EnableWindow(hItem, (enabled) ? TRUE : FALSE);
  }

  static void enable(HWND hItem)
  {
    EnableWindow(hItem, TRUE);
  }

  static void disable(HWND hItem)
  {
    EnableWindow(hItem, FALSE);
  }

  static void enableRedraw(HWND hItem)
  {
    SendMessage(hItem, WM_SETREDRAW, (WPARAM)TRUE, 0);
  }

  static void disableRedraw(HWND hItem)
  {
    SendMessage(hItem, WM_SETREDRAW, (WPARAM)FALSE, 0);
  }

  static HFONT getFont(HWND hItem)
  {
    return (HFONT)SendMessage(hItem, WM_GETFONT, (WPARAM)0, (LPARAM)0);
  }

  static void setFont(HWND hItem, HFONT newFont)
  {
    SendMessage(hItem, WM_SETFONT, (WPARAM)newFont, (LPARAM)TRUE);
  }
};


#endif
