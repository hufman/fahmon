/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _UILISTVIEW_H
#define _UILISTVIEW_H

#include "UI.h"
#include "commctrl.h"


class UIListView : public UI
{
public:
  static void enableFullRowSelection(HWND hList) {ListView_SetExtendedListViewStyle(hList, LVS_EX_FULLROWSELECT);}

  static void setCurrentSelection(HWND hList, unsigned int item);
  static unsigned int getCurrentSelection(HWND hList) {return SendMessage(hList, LVM_GETNEXTITEM, -1, LVNI_FOCUSED);}

  static void addColumn(HWND hList, unsigned int columnIndex, const char* name, unsigned int width);
  static void deleteColumn(HWND hList, unsigned int columnIndex) {ListView_DeleteColumn(hList, columnIndex);}

  static unsigned int getColumnWidth(HWND hList, unsigned int columnIndex) {return ListView_GetColumnWidth(hList, columnIndex);}

  static void insertItemWithoutIcon(HWND hList, unsigned int itemIndex, unsigned int columnIndex, const char* name);
  static void insertItemWithIcon(HWND hList, unsigned int itemIndex, unsigned int columnIndex, unsigned int iconIndex, const char* name);
  static void deleteItem(HWND hList, unsigned int itemIndex) {ListView_DeleteItem(hList, itemIndex);}
  static void deleteAllItems(HWND hList) {ListView_DeleteAllItems(hList);}

  static void setItemText(HWND hList, unsigned int itemIndex, unsigned int columnIndex, const char* name);
  static void getItemText(HWND hList, unsigned int itemIndex, unsigned int columnIndex, char* itemText, unsigned int itemTextMaxLength);
};


#endif
