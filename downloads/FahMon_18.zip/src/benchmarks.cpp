/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "benchmarks.h"
#include "limits.h"


Benchmarks Benchmarks::mInstance;


/**
 * Constructor.
**/
ClientId::ClientId(const char* name, unsigned short int number)
{
  lstrcpyn(mClientName, name, CLIENT_NAME_MAX_LENGTH);
  mClientNumber = number;
}


/**
 * Constructor.
**/
ClientId::ClientId(BufferedInputFile *inputFile)
{
  unsigned short int length;

  // First, there is the length of the client name
  // We should take care to not use a too large value
  inputFile->read(&length, sizeof(length));
  if(length >= CLIENT_NAME_MAX_LENGTH)
    length = CLIENT_NAME_MAX_LENGTH - 1;

  inputFile->read(mClientName, length);
  mClientName[length] = '\0';
  inputFile->read(&mClientNumber, sizeof(mClientNumber));
}


/**
 * Save this object to the given file.
**/
inline void ClientId::saveToFile(BufferedOutputFile *outFile) const
{
  unsigned short int length;

  length = (unsigned short int)lstrlen(mClientName);
  outFile->write(&length, sizeof(length));
  outFile->write(mClientName, length);
  outFile->write(&mClientNumber, sizeof(mClientNumber));
}







/**
 * Constructor.
**/
ABenchmark::ABenchmark(unsigned short int clientNumber, unsigned short int time)
{
  mClientNumber         = clientNumber;
  mRunMinTime           = time;
  mRunAvgTime           = time;
  mRunAvgTimeIterations = 1;
}


/**
 * Constructor.
**/
ABenchmark::ABenchmark(BufferedInputFile *inputFile)
{
  inputFile->read(&mClientNumber, sizeof(mClientNumber));
  inputFile->read(&mRunMinTime, sizeof(mRunMinTime));
  inputFile->read(&mRunAvgTime, sizeof(mRunAvgTime));
  inputFile->read(&mRunAvgTimeIterations, sizeof(mRunAvgTimeIterations));
}


/**
 * Add a new time to this benchmark.
 * The minimum and average times are updated.
**/
void ABenchmark::addNewTime(unsigned short int newTime)
{
  unsigned int tmpValue;

  // Is it smaller than the smallest known one ?
  if(newTime < mRunMinTime)
    mRunMinTime = newTime;

  // In any case, use it to compute the average time if the number of iterations is not too high
  if(mRunAvgTimeIterations != USHRT_MAX)
  {
    tmpValue = ((unsigned int)mRunAvgTime) * ((unsigned int)mRunAvgTimeIterations) + ((unsigned int)newTime);
    ++mRunAvgTimeIterations;
    mRunAvgTime = (unsigned short int)(tmpValue / ((unsigned int)mRunAvgTimeIterations));
  }
}


/**
 * Save this benchmark to the given file.
**/
inline void ABenchmark::saveToFile(BufferedOutputFile *outFile) const
{
  outFile->write(&mClientNumber, sizeof(mClientNumber));
  outFile->write(&mRunMinTime, sizeof(mRunMinTime));
  outFile->write(&mRunAvgTime, sizeof(mRunAvgTime));
  outFile->write(&mRunAvgTimeIterations, sizeof(mRunAvgTimeIterations));
}


/**
 * Add a new client to the database.
 * If a client with the same name already exists, it is not added.
 * In any of these two case, the corresponding clientNumber is returned.
 *
 * @param name The name of the client to add.
 * @param clientNumber Used to store the clientNumber.
 *
 * @return true is everything was OK, false otherwise (the client could NOT be added and clientNumber is NOT changed).
**/
bool Benchmarks::registerClient(const char* name, unsigned short int *clientNumber)
{
  unsigned int i, maxId, currId;

  // First, we test if the client already exists or not
  maxId = 0;
  for(i=0; i<mClients.getNbItems(); ++i)
  {
    currId = mClients.getItem(i)->getClientNumber();

    // Name already in use ?
    if(lstrcmpi(mClients.getItem(i)->getClientName(), name) == 0)
    {
      *clientNumber = currId;
      return true;
    }
    else
    {
      // Otherwise, keep the higher id to determine which value to use as a new clientNumber
      if(maxId < currId)
        maxId = currId;
    }
  }

  // Can we add a new client?
  if(maxId == USHRT_MAX)
    return false;
  else
    ++maxId;

  *clientNumber = maxId;
  mClients.addItem(new ClientId(name, maxId));

  return true;
}


/**
 * Load a file containing the benchmarks.
**/
bool Benchmarks::loadBenchmarksFromFile(const char* filename)
{
  unsigned int i, projectNumber;
  unsigned short int nbClients;
  BufferedInputFile benchmarksFile(filename);

  if(benchmarksFile.isValid() == false)
    return false;

  // We first load the clients
  benchmarksFile.read(&nbClients, sizeof(nbClients));
  for(i=0; i<nbClients; ++i)
    mClients.addItem(new ClientId(&benchmarksFile));

  // And then the benchmarks
  while(benchmarksFile.read(&projectNumber, sizeof(projectNumber)) == true)
  {
    if(projectNumber < PROJECTS_MAX_KNOWN_NUMBER)
    {
      if(projectNumber < mMinProjectNumber)
        mMinProjectNumber = projectNumber;
      if(projectNumber > mMaxProjectNumber)
        mMaxProjectNumber = projectNumber;

      benchmarksFile.read(&nbClients, sizeof(nbClients));
      for(i=0; i<nbClients; ++i)
        mBenchmarks[projectNumber].addItem(new ABenchmark(&benchmarksFile));
    }
  }

  // That's all
  return true;
}


/**
 * Save the benchmarks to a file.
**/
bool Benchmarks::saveBenchmarksToFile(const char* filename) const
{
  unsigned int i, j;
  unsigned short int nbClients;
  BufferedOutputFile outFile(filename);

  if(outFile.isValid() == false)
    return false;

  // First, we save the clients
  nbClients = (unsigned short int)mClients.getNbItems();
  outFile.write(&nbClients, sizeof(nbClients));
  for(i=0; i<nbClients; ++i)
    mClients.getItem(i)->saveToFile(&outFile);

  // And then all the benchmarks
  for(i=getMinRegisteredProjectNumber(); i<=getMaxRegisteredProjectNumber(); ++i)
  {
    nbClients = (unsigned short int)mBenchmarks[i].getNbItems();
    if(nbClients != 0)
    {
      outFile.write(&i, sizeof(i));
      outFile.write(&nbClients, sizeof(nbClients));

      for(j=0; j<nbClients; ++j)
        mBenchmarks[i].getItem(j)->saveToFile(&outFile);
    }
  }

  // That's all
  return true;
}


/**
 * @return The name of the client which is identified by the given number.
**/
const char* Benchmarks::getClientName(unsigned short int clientNumber) const
{
  unsigned int i;

  for(i=0; i<mClients.getNbItems(); ++i)
    if(mClients.getItem(i)->getClientNumber() == clientNumber)
      return mClients.getItem(i)->getClientName();

  return NULL;
}


/**
 * @return The benchmark, if any, for the given couple {project, client}.
**/
ABenchmark* Benchmarks::getBenchmark(unsigned int projectNumber, unsigned short int clientNumber) const
{
  unsigned int i;
  const TDynamicArray<ABenchmark>* benchmarksArray;

  if(projectNumber >= PROJECTS_MAX_KNOWN_NUMBER)
    return NULL;

  benchmarksArray = &mBenchmarks[projectNumber];
  for(i=0; i<benchmarksArray->getNbItems(); ++i)
    if(benchmarksArray->getItem(i)->getClientNumber() == clientNumber)
      return benchmarksArray->getItem(i);

  return NULL;
}


/**
 * Add a new run time for the given {project, client} couple.
**/
void Benchmarks::addRunTime(unsigned int projectNumber, unsigned short int clientNumber, unsigned short int runTime)
{
  ABenchmark* benchmark = getBenchmark(projectNumber, clientNumber);

  if(benchmark != NULL)
    benchmark->addNewTime(runTime);
  else if(projectNumber < PROJECTS_MAX_KNOWN_NUMBER)
  {
    mBenchmarks[projectNumber].addItem(new ABenchmark(clientNumber, runTime));

    if(projectNumber < mMinProjectNumber)
      mMinProjectNumber = projectNumber;
    if(projectNumber > mMaxProjectNumber)
      mMaxProjectNumber = projectNumber;
  }
}
