/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _BENCHMARKS_H
#define _BENCHMARKS_H

#include "fahMon.h"
#include "bufferedInputFile.h"
#include "bufferedOutputFile.h"
#include "t_DynamicArray.h"


/**
 * A client is represented by:
 *  - A name
 *  - A number, used as an identifier
**/
class ClientId
{
protected:
  char mClientName[CLIENT_NAME_MAX_LENGTH];
  unsigned short int mClientNumber;

public:
  ClientId(const char* name, unsigned short int number);
  ClientId(BufferedInputFile *inputFile);

  void saveToFile(BufferedOutputFile *outFile) const;


  //
  // Inline members
  //

  const char* getClientName(void) const {return mClientName;}
  unsigned short int getClientNumber(void) const {return mClientNumber;}
};




/**
 * Store the benchmarks for a particular client.
**/
class ABenchmark
{
protected:
  unsigned short int mClientNumber;
  unsigned short int mRunMinTime;
  unsigned short int mRunAvgTime;
  unsigned short int mRunAvgTimeIterations;

public:
  ABenchmark(BufferedInputFile *inputFile);
  ABenchmark(unsigned short int clientNumber, unsigned short int time);

  void saveToFile(BufferedOutputFile *outFile) const;
  void addNewTime(unsigned short int newTime);

  
  //
  // Inline members
  //
  
  unsigned short int getClientNumber(void) const {return mClientNumber;}
  unsigned short int getRunMinTime(void) const {return mRunMinTime;}
  unsigned short int getRunAvgTime(void) const {return mRunAvgTime;}  
};




class Benchmarks
{
protected:
  TDynamicArray<ClientId> mClients;
  TDynamicArray<ABenchmark> mBenchmarks[PROJECTS_MAX_KNOWN_NUMBER];

  unsigned int mMinProjectNumber;
  unsigned int mMaxProjectNumber;

public:
  static Benchmarks mInstance;

  Benchmarks::Benchmarks(void) {mMinProjectNumber=PROJECTS_MAX_KNOWN_NUMBER-1; mMaxProjectNumber=0;}

  const char* getClientName(unsigned short int clientNumber) const;
  bool registerClient(const char* name, unsigned short int *clientNumber);
  ABenchmark* getBenchmark(unsigned int projectNumber, unsigned short int clientNumber) const;
  void addRunTime(unsigned int projectNumber, unsigned short int clientNumber, unsigned short int runTime);

  bool loadBenchmarksFromFile(const char* filename);
  bool saveBenchmarksToFile(const char* filename) const;


  //
  // Inline members
  //

  unsigned int getMinRegisteredProjectNumber(void) const {return mMinProjectNumber;}
  unsigned int getMaxRegisteredProjectNumber(void) const {return mMaxProjectNumber;}

  /**
   * @return The number of stored benchmarks for a given project.
  **/
  unsigned int getNbBenchmarks(unsigned int projectNumber) const
  {
    assert(projectNumber < PROJECTS_MAX_KNOWN_NUMBER);

    return mBenchmarks[projectNumber].getNbItems();
  }


  /**
   * @return All the known benchmarks for the given project.
  **/
  const TDynamicArray<ABenchmark>* getBenchmarks(unsigned int projectNumber) const
  {
    assert(projectNumber < PROJECTS_MAX_KNOWN_NUMBER);

    return &mBenchmarks[projectNumber];
  }
};


#endif
