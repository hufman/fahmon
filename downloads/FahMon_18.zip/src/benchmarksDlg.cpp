/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "benchmarksDlg.h"
#include "resource.h"
#include "prefsmanager.h"
#include "benchmarks.h"
#include "fahProject.h"
#include "projectsManager.h"
#include "fahCore.h"
#include "tools.h"
#include "UIComboBox.h"
#include "UIText.h"


/**
 * Constructor
**/
BenchmarksDlg::BenchmarksDlg(HINSTANCE hInstance, HWND parentDlg) : MyDialogBox(hInstance, parentDlg, ID_DLG_BENCHMARKS), ResizableDlg(false)
{
  mHasBeenInitialized = false;
}


/**
 * Destructor.
**/
BenchmarksDlg::~BenchmarksDlg(void)
{
  if(mHasBeenInitialized == true)
    DeleteObject(mFixedFont);
}


/**
 * Initialize the dialog box
**/
inline void BenchmarksDlg::initialize(void)
{
  char buffer[64];

  setSmallIcon(ID_ICO_DIALOG);
  wsprintf(buffer, "%s  /  Benchmarks", PrefsManager::mInstance.mAppNameVersion);
  setTitle(buffer);

  // Bind all the controls to their corresponding attributes
  mHCbbProjects      = getItem(ID_BEN_CBB_PROJECTS);
  mHLblSeeBenchamrks = getItem(ID_BEN_LBL_SEEBENCHMARKS);
  mHTxtDescription   = getItem(ID_BEN_TXT_DESCRIPTION);
  mHBtnClose         = getItem(ID_BEN_BTN_CLOSE);

  mFixedFont = CreateFont(15, 7, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, "Courier New");
  UIText::setFont(mHTxtDescription, mFixedFont);

  // Define the resizing behavior
  setDlgResizable(DLG_BENCHMARKS_MIN_WIDTH, DLG_BENCHMARKS_MIN_HEIGHT);
  // Add a resize grip, resize the dialog box and center it
  initResizableDlg(mHDlg, mHInstance, PrefsManager::mInstance.mBenchmarksDlgWidth, PrefsManager::mInstance.mBenchmarksDlgHeight);
}


/**
 * Fill the text area with the description of the given project
**/
void BenchmarksDlg::fillDescriptionArea(unsigned int projectNumber) const
{
  char buffer[256], fmtTime[128];
  const FahProject* projectInfo;
  const TDynamicArray<ABenchmark>* projectBenchmarks;
  const ABenchmark* aBenchmark;
  unsigned int i;

  wsprintf(buffer, "Project : %u\r\n", projectNumber);
  UIText::setText(mHTxtDescription, buffer);

  projectInfo = ProjectsManager::mInstance.getProjectInfos(projectNumber);

  // Do we have some information on this project?
  if(projectInfo == NULL)
    UIText::appendText(mHTxtDescription, "No information on this project.\r\n");
  else
  {
    wsprintf(buffer, "Core    : %s\r\n", FahCore::coretoa(projectInfo->mCore));
    UIText::appendText(mHTxtDescription, buffer);

    wsprintf(buffer, "Frames  : %u\r\n", projectInfo->mNbRuns);
    UIText::appendText(mHTxtDescription, buffer);

    wsprintf(buffer, "Credit  : %u\r\n", (unsigned int)projectInfo->mValue);
    UIText::appendText(mHTxtDescription, buffer);
  }

  // Retrieve the benchmarks for this project
  assert(projectNumber < PROJECTS_MAX_KNOWN_NUMBER);
  projectBenchmarks = Benchmarks::mInstance.getBenchmarks(projectNumber);
  // There MUST be some benchmarks, otherwise the project would not be selectable
  assert(projectBenchmarks != NULL);

  UIText::appendText(mHTxtDescription, "\r\n\r\n-- List of benchmarks --\r\n");
  for(i=0; i<projectBenchmarks->getNbItems(); ++i)
  {
    aBenchmark = projectBenchmarks->getItem(i);

    // The benchmark can't be NULL, as the index we use is smaller than the total number of items in the list
    assert(aBenchmark != NULL);

    wsprintf(buffer, "\r\n%s -> \r\n", Benchmarks::mInstance.getClientName(aBenchmark->getClientNumber()));
    UIText::appendText(mHTxtDescription, buffer);

    Tools::accurateSecondsToString(fmtTime, aBenchmark->getRunMinTime());
    wsprintf(buffer, "  Min. Time / Frame : %s\r\n", fmtTime);
    UIText::appendText(mHTxtDescription, buffer);

    Tools::accurateSecondsToString(fmtTime, aBenchmark->getRunAvgTime());
    wsprintf(buffer, "  Avg. Time / Frame : %s\r\n", fmtTime);
    UIText::appendText(mHTxtDescription, buffer);
  }
}


/**
 * Manage the WM_INITDIALOG message
**/
BOOL BenchmarksDlg::onInitDialog(void)
{
  unsigned int i, index;
  char buffer[16];

  if(mHasBeenInitialized == false)
  {
    initialize();
    mHasBeenInitialized = true;
  }

  // Fill the combo box with the projects for which we have some benchmarks
  // Each entry is associated with the project number, so that we don't have to convert the string back to an integer
  // when the selection is changed
  UICombobox::reset(mHCbbProjects);
  index = 0;
  for(i=Benchmarks::mInstance.getMinRegisteredProjectNumber(); i<=Benchmarks::mInstance.getMaxRegisteredProjectNumber(); ++i)
  {
    if(Benchmarks::mInstance.getNbBenchmarks(i) != 0)
    {
      wsprintf(buffer, "%u", i);
      UICombobox::addEntry(mHCbbProjects, buffer);
      UICombobox::setItemData(mHCbbProjects, index, i);
      ++index;
    }
  }

  // Select the first item in the combo box or disable it if there is no entry
  if(UICombobox::getCount(mHCbbProjects) != 0)
  {
    UICombobox::enable(mHCbbProjects);
    UICombobox::setCurrentSelection(mHCbbProjects, 0);
    fillDescriptionArea(UICombobox::getItemData(mHCbbProjects, 0));
    SetFocus(mHCbbProjects);
  }
  else
  {
    UICombobox::disable(mHCbbProjects);
    UIText::setText(mHTxtDescription, "No registered benchmarks.");
    SetFocus(mHBtnClose);
  }

  return FALSE;
}


/**
 * Manage the WM_COMMAND message
**/
BOOL BenchmarksDlg::onCommand(unsigned int notifyCode, unsigned int id, HWND hControl)
{
  switch(id)
  {
    case ID_BEN_CBB_PROJECTS:
      if(notifyCode == CBN_SELCHANGE)
        fillDescriptionArea(UICombobox::getItemData(mHCbbProjects, UICombobox::getCurrentSelection(mHCbbProjects)));
      break;

    case ID_BEN_BTN_CLOSE:
      if(notifyCode == BN_CLICKED)
        onClose();
      break;
  }

  return FALSE;
}


/**
 * Manage the WM_CTLCOLORSTATIC message
**/
BOOL BenchmarksDlg::onCtlColorStatic(HDC hDc, HWND hWnd)
{
  if(hWnd == mHTxtDescription)
  {
    SetBkColor(hDc, RGB(255, 255, 255));
    return (BOOL)GetStockObject(WHITE_BRUSH);
  }

  return FALSE;
}


/**
 * Manage the WM_SIZE message
**/
BOOL BenchmarksDlg::onSize(unsigned int fwSizeType, unsigned int width, unsigned int height)
{
  sizeHasChanged(mHDlg, fwSizeType, width, height);
  return FALSE;
}


/**
 * The size has changed, so we have to move the controls
**/
void BenchmarksDlg::reflowControls(unsigned int clientAreaWidth, unsigned int clientAreaHeight) const
{
  unsigned int lblX = (clientAreaWidth - 221) / 2 - 2;

  // Move and/or resize controls
  SetWindowPos(mHLblSeeBenchamrks, NULL, lblX, 10, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHCbbProjects, NULL, lblX + 149, 10, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHBtnClose, NULL, (clientAreaWidth - 68) / 2, clientAreaHeight-33, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHTxtDescription, NULL, 10, 41, clientAreaWidth-20, clientAreaHeight-83, SWP_NOZORDER);

  // Save the new size
  PrefsManager::mInstance.mBenchmarksDlgWidth  = clientAreaWidth;
  PrefsManager::mInstance.mBenchmarksDlgHeight = clientAreaHeight;
}
