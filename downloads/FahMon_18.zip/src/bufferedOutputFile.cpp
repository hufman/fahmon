/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "bufferedOutputFile.h"


BufferedOutputFile::BufferedOutputFile(const char* filename)
{
  mBufferedDataSize = 0;
  mHFile            = CreateFile(filename, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
  
  if(mHFile == INVALID_HANDLE_VALUE)
    mValid = false;
  else
    mValid = true;
}


BufferedOutputFile::~BufferedOutputFile(void)
{
  if(mBufferedDataSize != 0)
    flush();
  CloseHandle(mHFile);
}


inline void BufferedOutputFile::flush(void)
{
  DWORD written;

  WriteFile(mHFile, mBufferedData, mBufferedDataSize, &written, NULL);
  mBufferedDataSize = 0;
}


void BufferedOutputFile::write(const void* srcPtr, unsigned int bytesToWrite)
{
  DWORD written;
  unsigned int leftSpace = BOF_BUFFER_SIZE - mBufferedDataSize;

  if(bytesToWrite > leftSpace)
  {
    flush();
    leftSpace = BOF_BUFFER_SIZE;
  }

  if(bytesToWrite > leftSpace)
    WriteFile(mHFile, srcPtr, bytesToWrite, &written, NULL);
  else
  {
    CopyMemory(&mBufferedData[mBufferedDataSize], srcPtr, bytesToWrite);
    mBufferedDataSize += bytesToWrite;
  }
}
