/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "clientsList.h"
#include "bufferedOutputFile.h"
#include "xmlParser.h"
#include "prefsmanager.h"
#include "fileTools.h"


enum{CLIENT, NAME, DIRECTORY};


ClientsList ClientsList::mInstance;


/**
 * Save the list to the given file.
**/
void ClientsList::saveToFile(const char* filename)
{
  char buffer[512];
  unsigned int i;
  FahClient *client;
  BufferedOutputFile outFile(filename);

  if(outFile.isValid() == true)
  {
    for(i=0; i<mClients.getNbItems(); ++i)
    {
      client = mClients.getItem(i);
      if(lstrlen(client->getClientName()) + lstrlen(client->getPath()) < 256)
      {
        wsprintf(buffer, "<client>\n\t<name>%s</name>\n\t<directory>%s</directory>\n</client>\n", client->getClientName(), client->getPath());
        outFile.write(buffer, lstrlen(buffer));
      }
    }
  }
}


/**
 * Load the list from the given file
**/
void ClientsList::loadFromFile(const char* filename)
{
  unsigned int fileSize;
  char *fileString, name[CLIENT_NAME_MAX_LENGTH], directory[PATH_MAX_LENGTH], *tagError = NULL;
  XMLParser *parser;
  char errorMessage[128];

  // Open and read the whole file
  fileString = FileTools::loadTextFile(filename, &fileSize);
  if(fileString == NULL)
    return;

  // Create a parser the recognizes the keyword of the configuration file
  parser = new XMLParser(fileString);
  parser->addTag("client", CLIENT);
  parser->addTag("name", NAME);
  parser->addTag("directory", DIRECTORY);

  parser->nextToken();
  while(parser->getToken() != XMLParser::TK_END)
  {
    if(parser->getToken() != XMLParser::TK_START_TAG || parser->getTag() != CLIENT)
      tagError = "<client>";
    else
    {
      parser->nextToken();
      if(parser->getToken() != XMLParser::TK_START_TAG || parser->getTag() != NAME)
        tagError = "<name>";
      else
      {
        parser->nextToken();
        if(parser->getToken() != XMLParser::TK_TEXT)
          tagError = "A client name";
        else
        {
          lstrcpyn(name, parser->getTextValue(), CLIENT_NAME_MAX_LENGTH);
          parser->nextToken();
          if(parser->getToken() != XMLParser::TK_END_TAG || parser->getTag() != NAME)
            tagError = "</name>";
          else
          {
            parser->nextToken();
            if(parser->getToken() != XMLParser::TK_START_TAG || parser->getTag() != DIRECTORY)
              tagError = "<directory>";
            else
            {
              parser->nextToken();
              if(parser->getToken() != XMLParser::TK_TEXT)
                tagError = "A client directory";
              else
              {
                lstrcpyn(directory, parser->getTextValue(), PATH_MAX_LENGTH);
                parser->nextToken();
                if(parser->getToken() != XMLParser::TK_END_TAG || parser->getTag() != DIRECTORY)
                  tagError = "</directory>";
                else
                {
                  addClient(name, directory);

                  parser->nextToken();    
                  if(parser->getToken() != XMLParser::TK_END_TAG || parser->getTag() != CLIENT)
                    tagError = "</client>";
                  else
                    parser->nextToken();
                }
              }
            }
          }
        }
      }
    }

    // If an error occured, signal it
    if(tagError)
    {
      wsprintf(errorMessage, "clients.cfg: %s was expected (line %d)", tagError, parser->getCurrentLine());
      MessageBox(NULL, errorMessage, PrefsManager::mInstance.mAppName, MB_OK | MB_ICONERROR);
      break;
    }
  }
  delete parser;

  if(fileString)
    delete[] fileString;
}
