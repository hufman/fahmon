/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "date.h"
#include "tools.h"


/**
 * Constructor.
 * The format of the String should be something like '13:25:40'
**/
Date::Date(const char* timestamp)
{
  mNbHours   = Tools::atoi(timestamp);
  mNbMinutes = Tools::atoi(&timestamp[3]);
  mNbSeconds = Tools::atoi(&timestamp[6]);
}


/**
 * Compute the number of elapsed seconds between the current date and the one given as a parameter
**/
unsigned int Date::computeElapsedSeconds(Date *anotherDate)
{
  int nbSec = (anotherDate->mNbHours - mNbHours) * 3600 + (anotherDate->mNbMinutes - mNbMinutes) * 60 + anotherDate->mNbSeconds - mNbSeconds;

  if(nbSec > 0)
    return nbSec;

  return nbSec + 86400;
}
