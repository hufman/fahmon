/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "fahClient.h"
#include "benchmarks.h"
#include "fileTools.h"
#include "tools.h"
#include "prefsmanager.h"

#define FILE_UNITINFO     "unitinfo.txt"
#define FILE_CLIENTCONFIG "client.cfg"
#define FILE_CLIENTLOG    "FAHlog.txt"


/**
 * Analyze a client located in the specified directory
**/
FahClient::FahClient(const char* clientname, const char* directory)
{
  unsigned int length;

  // The client has not been loaded for the moment ...
  mValid = false;
  // ... So we don't known if it is running or not
  mIsRunning = false;

  Benchmarks::mInstance.registerClient(clientname, &mClientNumber);

  // Store the name of the client
  lstrcpyn(mClientName, clientname, CLIENT_NAME_MAX_LENGTH);

  // Append a backslash to the directory if needed
  length = lstrlen(directory);
  if(directory[length-1] == '\\')
  {
    mBasePath = new char[length+1];
    CopyMemory(mBasePath, directory, length+1);
  }
  else
  {
    mBasePath = new char[length+2];
    CopyMemory(mBasePath, directory, length);
    mBasePath[length] = '\\';
    ++length;
    mBasePath[length] = '\0';
  }

  mUnitinfoPath = new char[length + 13];
  CopyMemory(mUnitinfoPath, mBasePath, length);
  CopyMemory(&mUnitinfoPath[length], FILE_UNITINFO, 13);

  mClientCfgPath = new char[length + 11];
  CopyMemory(mClientCfgPath, mBasePath, length);
  CopyMemory(&mClientCfgPath[length], FILE_CLIENTCONFIG, 11);

  mFahLogPath = new char[length + 11];
  CopyMemory(mFahLogPath, mBasePath, length);
  CopyMemory(&mFahLogPath[length], FILE_CLIENTLOG, 11);

  mLog.setPath(mFahLogPath);
}


/**
 * Destructor
**/
FahClient::~FahClient(void)
{
  delete[] mBasePath;
  delete[] mUnitinfoPath;
  delete[] mClientCfgPath;
  delete[] mFahLogPath;
}


/**
 * Load data from the file 'unitinfo.txt'
 * The buffer MUST end with a LF character and bufferSize should not take it into account
**/
inline void FahClient::loadUnitinfo(char* buffer, unsigned int bufferSize)
{
  unsigned int startPos, endPos;
  char tmpChar;

  startPos = 0;
  while(true)
  {
    // Find the next line
    while(buffer[startPos] != CHAR_LF)
      ++startPos;

    // Stop parsing if we have reached the end
    if(startPos >= bufferSize)
      break;

    ++startPos;
    tmpChar = buffer[startPos];
    switch(tmpChar)
    {
      //
      // --~~== Name of the protein ==~~--
      //
      case 'N':
        // Find the start of the project number
        startPos += 6;
        while(startPos < bufferSize && (buffer[startPos] < '0' || buffer[startPos] > '9'))
          ++startPos;

        if(startPos < bufferSize)
          mWUInformation.setProjectNumber(Tools::atoi(&buffer[startPos]));
        break;

      //
      // --~~== Current progress
      //
      case 'P':
        startPos += 10;
        mWUInformation.setProgress(Tools::atoi(&buffer[startPos]));
        break;

      //
      // --~~== Download and due time ==~~--
      //
      case 'D':
        if(buffer[startPos+1] == 'o')
        {
          startPos += 15;
          endPos = startPos;

          while(buffer[endPos] != CHAR_LF)
            ++endPos;

          if(endPos < bufferSize)
          {
            if(buffer[endPos-1] == CHAR_CR)
              --endPos;

            buffer[endPos] = '\0';
            mWUInformation.setDownloadTime(&buffer[startPos]);
            buffer[endPos] = CHAR_LF;
            startPos = endPos;
          }
        }
        else
        {
          startPos += 10;
          endPos = startPos;

          while(buffer[endPos] != CHAR_LF)
            ++endPos;

          if(endPos < bufferSize)
          {
            if(buffer[endPos-1] == CHAR_CR)
              --endPos;

            buffer[endPos] = '\0';
            mWUInformation.setDueTime(&buffer[startPos]);
            buffer[endPos] = CHAR_LF;
            startPos = endPos;
          }
        }
        break;
    }
  }
}


/**
 * Load the file 'config.cfg'
 * The buffer MUST end with a LF character and bufferSize should not take it into account
**/
inline void FahClient::loadConfigFile(char* buffer, unsigned int bufferSize)
{
  unsigned int startPos, endPos;
  bool userNameOk, teamNumberOk;
  char tmpChar;

  startPos     = 0;
  userNameOk   = false;
  teamNumberOk = false;
  while(!userNameOk || !teamNumberOk)
  {
    // Find the next line
    while(buffer[startPos] != CHAR_LF)
      ++startPos;

    // Stop parsing if we have reached the end of the buffer
    if(startPos >= bufferSize)
      break;

    ++startPos;
    tmpChar = buffer[startPos];
    switch(tmpChar)
    {
      // Username ?
      case 'u':
        if(Tools::strcmp(&buffer[startPos], "username", 8))
        {
          startPos += 9;
          userNameOk = true;
          endPos = startPos;
          while(buffer[endPos] != CHAR_LF)
            ++endPos;
          if(endPos < bufferSize)
          {
            if(buffer[endPos-1] == CHAR_CR)
              --endPos;

            buffer[endPos] = '\0';
            mUserInformation.setUserName(&buffer[startPos]);
            buffer[endPos] = CHAR_LF;
            startPos = endPos;
          }
        }
        break;

      // Team
      case 't':
        if(Tools::strcmp(&buffer[startPos], "team", 4))
        {
          startPos += 5;
          teamNumberOk = true;
          mUserInformation.setTeamNumber(Tools::atoi(&buffer[startPos]));
        }
        break;
    }
  }
}


/**
 * Retrieve information on the client
**/
void FahClient::load(void)
{
  char *buffer;
  unsigned int toBeRead, lastRunNumber;

  // BUGFIX Do not initialize mValid to false, this can cause flickering in multi view:
  // 1. Selection changes
  // 2. Client starts loading and sets mValid to false
  // 3. List is redrawn and the client is striked out as mValid is false
  // 4. Client finishes loading, and mValid is set to true
  // 5. Text is changed in the list
  // 6. The item is no longer striked out, a flicker as occured

  // Read the whole unitinfo file and load it
  buffer = FileTools::loadTextFile(mUnitinfoPath, &toBeRead);
  if(buffer == NULL)
  {
    mValid = false;
    return;
  }
  buffer[toBeRead] = CHAR_LF;
  loadUnitinfo(buffer, toBeRead);
  delete[] buffer;

  // Read the whole 'client.cfg' file and load it
  buffer = FileTools::loadTextFile(mClientCfgPath, &toBeRead);
  if(buffer == NULL)
  {
    mValid = false;
    return;
  }
  buffer[toBeRead] = CHAR_LF;
  loadConfigFile(buffer, toBeRead);
  delete[] buffer;

  // Read the log file
  mLog.load();

  if(PrefsManager::mInstance.mAnalyseLastFrameDuration == true)
  {
    lastRunNumber = mLog.getLastRunInformation()->getRunNumber();
    mLog.analyzeLastRun();

    // If the run we've found is not the same as the previous one, register it to the benchmarks manager
    if(mLog.getLastRunInformation()->isValid() == true && lastRunNumber != mLog.getLastRunInformation()->getRunNumber())
      Benchmarks::mInstance.addRunTime(mWUInformation.getProjectNumber(), mClientNumber, mLog.getLastRunInformation()->getRunDuration());

    if(PrefsManager::mInstance.mCheckForActivity == true)
      checkForActivity();

    if(PrefsManager::mInstance.mComputeETA == true && (PrefsManager::mInstance.mCheckForActivity == false || mIsRunning == true))
      computeETA();
  }

  mValid = true;
}


/**
 * Check if the client is running
**/
inline void FahClient::checkForActivity(void)
{
  unsigned int trigger;
  const ABenchmark* benchmark;

  mIsRunning = false;

  // We first have to determine which value to use as a trigger:
  //  1) If available, use the duration of the last run, as it should be the more accurate one
  //  2) Use the average run duration for this couple {machine, project} if available
  //  3) As a last solution, use a fixed trigger of 1 hour
  if(mLog.getLastRunInformation()->isValid() == true)
    trigger = mLog.getLastRunInformation()->getRunDuration() << 1;
  else
  {
    benchmark = Benchmarks::mInstance.getBenchmark(mWUInformation.getProjectNumber(), mClientNumber);
    if(benchmark != NULL)
      trigger = ((unsigned int)benchmark->getRunAvgTime()) << 1;
    else
      trigger = 3600;
  }

  // Improvement: we now use the elapsed time since the last write acess to the log file.
  // The elapsed time since the end of the last run was used before.
  if(mLog.getElapsedTimeSinceLastWriteAccess() < trigger)
    mIsRunning = true;
}


/**
 * Format the attribute mETA with the ETA
**/
inline void FahClient::computeETA(void)
{
  const ABenchmark* benchmark;
  unsigned int nbTotalRuns;
  unsigned int timePerRun;
  unsigned int nbLeftSeconds;

  // Retrieve the number of runs for this WU, or guess it if we can
  nbTotalRuns = mWUInformation.getNbRuns();
  if(nbTotalRuns == 0 && mWUInformation.getProgress() != 0)
  {
    nbTotalRuns = mLog.getLastRunInformation()->getRunNumber() * 100 / mWUInformation.getProgress();
    nbTotalRuns = nbTotalRuns - (nbTotalRuns % 20);
  }

  // If we still have no clue about the number of runs, we can't give an ETA
  if(nbTotalRuns == 0)
    CopyMemory(mETA, "No ETA", 7);
  // If the total number of runs has been reached, the WU is finished
  else if(mLog.getLastRunInformation()->getRunNumber() >= nbTotalRuns)
    CopyMemory(mETA, "Finished", 9);
  else
  {
    // We use the average time per run
    benchmark  = Benchmarks::mInstance.getBenchmark(mWUInformation.getProjectNumber(), mClientNumber);
    timePerRun = 0;

    // No valid information about the last run, so we'll use only the average time if it is available
    if(mLog.getLastRunInformation()->isValid() == false)
    {
      if(benchmark != NULL)
        timePerRun = (unsigned int)benchmark->getRunAvgTime();
    }
    else
    {
      // We are sure that, if there is correct information about the last run, then there is also available information
      // about the average time, so 'benchmark' pointer can't be NULL.
      // If it is the case, then something is wrong in the code.
      assert(benchmark != NULL);

      // My theory about the computation of the ETA :-)
      //
      // As the computation of the WU is reaching the end, the duration of the last run will become more important.
      // However, when the computation has just begun, the average duration of a run is much more important than the 'current'
      // duration of runs.
      // So the duration used as a 'metric' is composed by the two durations, in regards of the progress of the computation.
      //
      //    Tm = Average run duration
      //    Tl = Duration of the last run
      //    Y  = Total number of runs for the WU
      //    X  = Number of the last run
      //
      //    Duration = (Tl * X / Y) + (Tm * (1 - X / Y))
      //             = Tl * X / Y + Tm - Tm * X / Y
      //             = (Tl - Tm) * X / Y + Tm

      int Tm = benchmark->getRunAvgTime();
      int Tl = mLog.getLastRunInformation()->getRunDuration();
      int Y  = nbTotalRuns;
      int X  = mLog.getLastRunInformation()->getRunNumber();

      timePerRun = (unsigned int)((Tl - Tm) * X / Y + Tm);
    }

    // If we have no metric, we can't give an ETA
    if(timePerRun == 0)
      CopyMemory(mETA, "No ETA", 7);
    else
    {
      nbLeftSeconds = timePerRun * (nbTotalRuns - mLog.getLastRunInformation()->getRunNumber());

      // We can give a more accurate value by using the elapsed time since the last run
      if(mLog.getLastRunInformation()->getElapsedTimeSinceThisRun() > timePerRun)
        nbLeftSeconds -= timePerRun;
      else
        nbLeftSeconds -= mLog.getLastRunInformation()->getElapsedTimeSinceThisRun();

      // That's all, we just have to format it
      Tools::secondsToString(mETA, nbLeftSeconds);
    }
  }
}
