/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _FAHWORKUNIT_
#define _FAHWORKUNIT_

#include "fahMon.h"
#include "FahCore.h"

#define DATE_MAX_LENGTH 128


class FahWorkUnit
{
protected:
  unsigned int mProjectNumber;
  unsigned int mProgress;
  double mCredit;
  FahCore::CORE mCore;
  unsigned int mNbRuns;
  char mDownloadTime[DATE_MAX_LENGTH];
  char mDueTime[DATE_MAX_LENGTH];

public:
  FahWorkUnit(void);

  unsigned int getProjectNumber(void) const {return mProjectNumber;}
  void setProjectNumber(unsigned int projectNumber);

  unsigned int getProgress(void) const {return mProgress;}
  void setProgress(unsigned int progress) {mProgress = progress;}

  const char* getDownloadTime(void) const {return mDownloadTime;}
  void setDownloadTime(const char* downloadTime) {lstrcpyn(mDownloadTime, downloadTime, DATE_MAX_LENGTH);}

  const char* getDueTime(void) const {return mDueTime;}
  void setDueTime(const char* dueTime) {lstrcpyn(mDueTime, dueTime, DATE_MAX_LENGTH);}

  // -1.0 if unknown
  double getCredit(void) const {return mCredit;}

  FahCore::CORE getCore(void) const {return mCore;}

  unsigned int getNbRuns(void) const {return mNbRuns;}
};


#endif
