/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef  _FILETOOLS_H
#define  _FILETOOLS_H

#include "fahMon.h"


class FileTools
{
public:
  static char* loadTextFile(const char* filename, unsigned int *filesize);
  static char* linuxFmtToWindowsFmt(const char* text, unsigned int *oldTextLength);
  static bool getLastWriteAccess(const char* filename, FILETIME *fileTime);
//  static bool exists(const char* filename);
};


#endif
