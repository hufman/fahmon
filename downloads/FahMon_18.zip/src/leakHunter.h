/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _LEAK_HUNTER_H_INCLUDED_
#define _LEAK_HUNTER_H_INCLUDED_


#ifdef _MEMORY_DEBUG_

// Redefine new and delete operators
void* __cdecl operator new(size_t size, const char *file, int line);
void  __cdecl operator delete(void* ptr);

// This macro replaces the new operator by a version which automatically insert the file and the line
// of the allocation, thanks to the preprocessor
#define new new(__FILE__, __LINE__)

#endif

// Check for unfreed memory
void lh_dump(void);

#endif
