/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "FahMon.h"
#include <commctrl.h>
#include "MainDlg.h"
#include "benchmarks.h"


#define MUTEX_UNIQUE_NAME "__FAHMON__A36FE9CDC67942FAD666"


/**
 * Entry point
**/
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
  INITCOMMONCONTROLSEX initcc;
  MainDlg *dlg;
  bool startMinimized;

  // Load the needed components for our dialogs
  initcc.dwSize = sizeof(INITCOMMONCONTROLSEX);
  initcc.dwICC = ICC_PROGRESS_CLASS | ICC_TAB_CLASSES | ICC_LISTVIEW_CLASSES;
  InitCommonControlsEx(&initcc);

  // Load files
  PrefsManager::mInstance.loadPrefs(FILE_PREFERENCES);
  Benchmarks::mInstance.loadBenchmarksFromFile(FILE_BENCHMARKS);
  ClientsList::mInstance.loadFromFile(FILE_CLIENTSLIST);

  // Block other instances if needed
  if(PrefsManager::mInstance.mThereCanBeOnlyOne)
  {
    // This is the method recommanded by Microsoft
    CreateMutex(NULL, TRUE, MUTEX_UNIQUE_NAME);
    if(GetLastError() == ERROR_ALREADY_EXISTS)
      return FALSE;
  }

  // TODO A real command line :)
  // Check the command line
  startMinimized = false;
  if(!lstrcmp(lpCmdLine, "-minimize"))
    startMinimized = true;

  Worker::mInstance = new Worker();

  // Create the main dialog box, and display it
  dlg = new MainDlg(hInstance, startMinimized);
  dlg->showModal(!startMinimized, LoadAccelerators(hInstance, MAKEINTRESOURCE(ID_ACC_MAIN)));
  delete dlg;

  // Save files
  PrefsManager::mInstance.savePrefs(FILE_PREFERENCES);
  Benchmarks::mInstance.saveBenchmarksToFile(FILE_BENCHMARKS);

  delete Worker::mInstance;

  // Search for unfreed memory
  lh_dump();

  return TRUE;
}


/**
 * Unused main, it is there for libctiny.lib to link correctly in release mode
**/
int main(int argc, char** argv)
{
  return 0;
}
