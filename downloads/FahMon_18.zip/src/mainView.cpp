#include "mainView.h"
#include <commctrl.h>
#include "fahProject.h"
#include "fahCore.h"
#include "resource.h"
#include "tools.h"

#include "UI.h"
#include "UIEdit.h"
#include "UIGroup.h"
#include "UIText.h"


/**
 * Constructor.
**/
MainView::MainView(HWND hDialog, HWND hViewControl, unsigned int currentClient)
{
  mHDialog       = hDialog;
  mHViewControl  = hViewControl;
  mCurrentClient = currentClient;

  UI::show(mHViewControl);


  // Bind each control with its corresponding attribute
  mHGrpWuInfo          = getItem(ID_MAI_GRP_WUINFO);
  mHIcoInfo            = getItem(ID_MAI_ICO_INFO);
  mHLblError           = getItem(ID_MAI_LBL_ERROR);
  mHPrgProgress        = getItem(ID_MAI_PRG_PROGRESS);
  mHLblProgress        = getItem(ID_MAI_LBL_PROGRESS);
  mHTxtLog             = getItem(ID_MAI_TXT_LOG);
  mHLblProjectValue    = getItem(ID_MAI_LBL_PROJECTVALUE);
  mHLblDownloadedValue = getItem(ID_MAI_LBL_DOWNLOADEDVALUE);
  mHLblDueTimeValue    = getItem(ID_MAI_LBL_DUETIMEVALUE);
  mHLblCreditValue     = getItem(ID_MAI_LBL_CREDITVALUE);
  mHLblCoreName        = getItem(ID_MAI_LBL_CORENAME);
  mHLblProject         = getItem(ID_MAI_LBL_PROJECT);
  mHLblCredit          = getItem(ID_MAI_LBL_CREDIT);
  mHLblDownloaded      = getItem(ID_MAI_LBL_DOWNLOADED);
  mHLblDueTime         = getItem(ID_MAI_LBL_DUETIME);
}


/**
 * Change the label of the main group box
**/
void MainView::setGroupLabel(const char* label)
{
  UIGroup::setText(mHGrpWuInfo, label);
  InvalidateRect(mHIcoInfo, NULL, FALSE);
}


/**
 * Show/Hide, Enable/Disable 'view-independant' items.
 *
 * @param view TRUE if the view mode is chosen, FALSE otherwise.
**/
void MainView::switchBetweenViewAndError(BOOL view)
{
  unsigned int menuItemEnabled = (view == TRUE) ? MF_ENABLED : MF_GRAYED;

  UI::setVisible(mHLblError, !view);
  UI::setVisible(mHPrgProgress, view);
  UI::setVisible(mHLblProgress, view);
  UI::setVisible(mHTxtLog, view);
  UI::setVisible(mHLblProjectValue, view);
  UI::setVisible(mHLblDownloadedValue, view);
  UI::setVisible(mHLblDueTimeValue, view);
  UI::setVisible(mHLblCreditValue, view);
  UI::setVisible(mHLblCoreName, view);
  UI::setVisible(mHGrpWuInfo, view);
  UI::setVisible(mHIcoInfo, view);
  UI::setVisible(mHLblProject, view);
  UI::setVisible(mHLblCredit, view);
  UI::setVisible(mHLblDownloaded, view);
  UI::setVisible(mHLblDueTime, view);
  EnableMenuItem(GetMenu(mHDialog), ID_MIT_VIEWSTATS, menuItemEnabled);
}


/**
 * Update the information about the core and the credit of the current WU.
 *
 * @param client The client for which the information has to be updated, can be NULL.
**/
void MainView::displayCorePoints(const FahClient *client)
{
  char buffer[128];

  // Should we retrieve the current client?
  if(!client)
    client = ClientsList::mInstance.getClient(mCurrentClient);

  // Credit for this WU
  if(client->getWUCredit() == -1)
    UIText::setText(mHLblCreditValue, "Unknown");
  else
  {
    wsprintf(buffer, "%d.%02d", (int)client->getWUCredit(), (int)(client->getWUCredit()*100-((int)client->getWUCredit())*100));  // Emulate %.2f of sprintf (not loaded with libctiny.lib)
    UIText::setText(mHLblCreditValue, buffer);
  }

  // Core
  wsprintf(buffer, "%s core", FahCore::coretoa(client->getWUCore()));
  UIText::setText(mHLblCoreName, buffer);
}


/**
 * Update the information about the current WU.
**/
void MainView::displayInfo(void)
{
  FahClient *client = ClientsList::mInstance.getClient(mCurrentClient);
  char buffer[128];

  // Display information only if the client is valid
  if(client->isValid())
  {
    if(mErrorMode)
    {
      mErrorMode = false;
      switchToView();
    }

    // Core and points information
    displayCorePoints(client);
    // Project number
    wsprintf(buffer, "%d", client->getWUProjectNumber());
    UIText::setText(mHLblProjectValue, buffer);
    // Was downloaded on
    UIText::setText(mHLblDownloadedValue, client->getWUDownloadTime());
    // Due time
    UIText::setText(mHLblDueTimeValue, client->getWUDueTime());
    // Progression
    SendMessage(mHPrgProgress, PBM_SETPOS, (WPARAM)client->getWUProgress(), (LPARAM)0);
    wsprintf(buffer, "[%02d%%]", client->getWUProgress());
    UIText::setText(mHLblProgress, buffer);

    // Update the log area
    UIEdit::disableRedraw(mHTxtLog);
    UIEdit::setText(mHTxtLog, client->getLogContent());
    UIEdit::scrollToEnd(mHTxtLog);
    UIEdit::enableRedraw(mHTxtLog);
  }
  else if(!mErrorMode)
  {
    mErrorMode = true;
    switchToError();
  }
}
