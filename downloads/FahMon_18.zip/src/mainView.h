#ifndef _MAINVIEW_H
#define _MAINVIEW_H

#include "fahMon.h"
#include "prefsManager.h"
#include "fahClient.h"
#include "projectsManager.h"
#include "clientsList.h"


class MainView
{
protected:
  // Attributes used to bind controls
  HWND mHGrpWuInfo;
  HWND mHIcoInfo;
  HWND mHLblError;
  HWND mHPrgProgress;
  HWND mHLblProgress;
  HWND mHTxtLog;
  HWND mHLblProjectValue;
  HWND mHLblDownloadedValue;
  HWND mHLblDueTimeValue;
  HWND mHLblCreditValue;
  HWND mHLblCoreName;
  HWND mHLblProject;
  HWND mHLblCredit;
  HWND mHLblDownloaded;
  HWND mHLblDueTime;

  HWND mHDialog;
  HWND mHViewControl;
  unsigned int mCurrentClient;
  bool mErrorMode;

  void switchBetweenViewAndError(BOOL show);
  void switchToError(void) {switchBetweenViewAndError(FALSE);}
  void switchToView(void) {switchBetweenViewAndError(TRUE);}

  void setGroupLabel(const char* label);
  HWND getItem(unsigned int id) const {return GetDlgItem(mHDialog, id);}

public:
  MainView(HWND hDialog, HWND hViewControl, unsigned int currentClient);
  virtual ~MainView(void) {}

  bool getErrorMode(void) const {return mErrorMode;}
  void displayInfo(void);
  void displayCorePoints(const FahClient *client = NULL);

  const FahClient* getCurrentClient(void) const {return ClientsList::mInstance.getClient(mCurrentClient);}
  unsigned int getCurrentClientIndex(void) const {return mCurrentClient;}
  void leave(void) {ShowWindow(mHViewControl, FALSE);}
  void gainFocus(void) {SetFocus(mHViewControl);}
  void enable(BOOL enabled) {EnableWindow(mHViewControl, enabled);}

  virtual void init(unsigned int currentClient, bool errorMode) = 0;
  virtual void reloadRequested(void) = 0;
  virtual void reloadDone(unsigned int clientIndex) = 0;
  virtual BOOL onNotify(NMHDR* information) = 0;
};


#endif
