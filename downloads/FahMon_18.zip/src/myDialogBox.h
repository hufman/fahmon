/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _MYDIALOGBOX_H
#define _MYDIALOGBOX_H

#include "fahMon.h"


class MyDialogBox
{
public:
  MyDialogBox(HINSTANCE hInstance, HWND hParentDlg, unsigned int dialogID);
  virtual ~MyDialogBox(void);

  virtual int showModal(bool visible = true, HACCEL accelerators = NULL);
  void endDialog(unsigned int exitCode) const;

protected:
  HWND mHDlg;
  HWND mHDlgParent;
  unsigned int mDlgId;
  HINSTANCE mHInstance;  

  // ------------------------------------- //
  //     ~~== Messages management ==~~     //
  // ------------------------------------- //
  static BOOL CALLBACK sDialogProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
  virtual BOOL dialogProc(UINT msg, WPARAM wParam, LPARAM lParam);
  virtual BOOL onInitDialog(void) {return TRUE;}
  virtual BOOL onCommand(unsigned int notifyCode, unsigned int id, HWND hControl) {return FALSE;}
  virtual BOOL onNotify(unsigned int id, NMHDR* information) {return FALSE;}
  virtual BOOL onCtlColorStatic(HDC hDc, HWND hWnd) {return FALSE;}
  virtual BOOL onSize(unsigned int fwSizeType, unsigned int width, unsigned int height) {return FALSE;}
  virtual BOOL onClose(void) {endDialog(1); return FALSE;}
  // ------------------------------------- //
  //     ~~== Messages management ==~~     //
  // ------------------------------------- //

  HWND getItem(unsigned int id) const {return GetDlgItem(mHDlg, id);}
  const HWND getHwnd(void) const {return mHDlg;}
  const HINSTANCE getHInstance(void) const {return mHInstance;}
  void showChildDialog(MyDialogBox* child) const;

  int errorMessageBox(const char* text) const;
  int warningMessageBox(const char* text) const;
  int questionMessageBox(const char* text) const;

  void setSmallIcon(unsigned int iconId) const {SendMessage(mHDlg, WM_SETICON, (WPARAM)ICON_SMALL, (LPARAM)LoadIcon(mHInstance, MAKEINTRESOURCE(iconId)));}
  void setTitle(const char* title) const {SetWindowText(mHDlg, title);}
};


#endif
