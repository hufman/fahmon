/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "prefsDlg.h"
#include <commctrl.h>
#include "resource.h"
#include "prefsmanager.h"
#include "tools.h"

#include "UICheckbox.h"
#include "UIButton.h"
#include "UIEdit.h"
#include "UIRadioButton.h"
#include "UIText.h"


/**
 * Constructor
**/
PrefsDlg::PrefsDlg(HINSTANCE hInstance, HWND parentDlg) : MyDialogBox(hInstance, parentDlg, ID_DLG_PREFS)
{
  mHasBeenInitialized = false;
  mPrefsHaveChanged   = false;
}


/**
 * Initialize this dialog box
**/
void PrefsDlg::initialize(void)
{
  char buffer[64];

  // Set the title and the icon of the dialog box
  wsprintf(buffer, "%s  /  Configuration", PrefsManager::mInstance.mAppNameVersion);
  setTitle(buffer);
  setSmallIcon(ID_ICO_DIALOG);

  // Bind each control with its corresponding attribute
  mHChkMinimizeToTray        = getItem(ID_PRE_CHK_MINIMIZETOTRAY);
  mHChkLogHScroll            = getItem(ID_PRE_CHK_LOGHSCROLL);
  mHChkThereCanBeOnlyOne     = getItem(ID_PRE_CHK_THERECANBEONLYONE);
  mHChkAnalyseLastFrame      = getItem(ID_PRE_CHK_ANALYSELASTFRAME);
  mHChkComputeEta            = getItem(ID_PRE_CHK_COMPUTEETA);
  mHChkDetectInactiveClients = getItem(ID_PRE_CHK_DETECTINACTIVECLIENTS);
  mHChkAutoReload            = getItem(ID_PRE_CHK_AUTORELOAD);
  mHChkHTTPProxyEnabled      = getItem(ID_PRE_CHK_HTTPPROXYENABLED);
  mHTxtAutoReload            = getItem(ID_PRE_TXT_AUTORELOAD);
  mHTxtHTTPProxyAddress      = getItem(ID_PRE_TXT_HTTPPROXYADDRESS);
  mHTxtHTTPProxyPort         = getItem(ID_PRE_TXT_HTTPPROXYPORT);
  mHRadList                  = getItem(ID_PRE_RAD_LIST);
  mHRadTabs                  = getItem(ID_PRE_RAD_TABS);
  mHRadMulti                 = getItem(ID_PRE_RAD_MULTI);
  mHSpiAutoReload            = getItem(ID_PRE_SPI_AUTORELOAD);
  mHBtnOk                    = getItem(ID_PRE_BTN_OK);
  mHBtnApply                 = getItem(ID_PRE_BTN_APPLY);
}


/**
 * The value of a control has changed
**/
void PrefsDlg::prefsChanged(void)
{
  mPrefsHaveChanged = true;
  UIButton::enable(mHBtnApply);
}


/**
 * Write changes to the PrefsManager
**/
void PrefsDlg::saveChanges(void)
{
  char buffer[128];

  // General checkboxes
  PrefsManager::mInstance.mMinimizeToTrayEnabled = UICheckbox::getState(mHChkMinimizeToTray);
  PrefsManager::mInstance.mLogHScrollEnabled     = UICheckbox::getState(mHChkLogHScroll);
  PrefsManager::mInstance.mThereCanBeOnlyOne     = UICheckbox::getState(mHChkThereCanBeOnlyOne);

  // Last run duration
  PrefsManager::mInstance.mAnalyseLastFrameDuration = UICheckbox::getState(mHChkAnalyseLastFrame);
  if(PrefsManager::mInstance.mAnalyseLastFrameDuration == false)
  {
    PrefsManager::mInstance.mComputeETA       = false;
    PrefsManager::mInstance.mCheckForActivity = false;
  }
  else
  {
    PrefsManager::mInstance.mComputeETA       = UICheckbox::getState(mHChkComputeEta);
    PrefsManager::mInstance.mCheckForActivity = UICheckbox::getState(mHChkDetectInactiveClients);
  }
  

  // Auto reload
  PrefsManager::mInstance.mAutoReloadEnabled = UICheckbox::getState(mHChkAutoReload);
  if(PrefsManager::mInstance.mAutoReloadEnabled)
  {
    GetWindowText(mHTxtAutoReload, buffer, 128);
    PrefsManager::mInstance.mAutoReloadFrequency = Tools::atoi(buffer);
  }

  // HTTP Proxy Configuration
  PrefsManager::mInstance.mHTTPProxyEnabled = UICheckbox::getState(mHChkHTTPProxyEnabled);
  if(PrefsManager::mInstance.mHTTPProxyEnabled)
  {
    GetWindowText(mHTxtHTTPProxyAddress, PrefsManager::mInstance.mHTTPProxyAddress, 128);
    GetWindowText(mHTxtHTTPProxyPort, buffer, 128);
    PrefsManager::mInstance.mHTTPProxyPort = Tools::atoi(buffer);
  }

  // Main dialog box view
  if(UIRadioButton::getState(mHRadList))
    PrefsManager::mInstance.mMainDlgView = PrefsManager::MDV_LIST;
  else if(UIRadioButton::getState(mHRadTabs))
    PrefsManager::mInstance.mMainDlgView = PrefsManager::MDV_TABS;
  else
    PrefsManager::mInstance.mMainDlgView = PrefsManager::MDV_MULTI;

  mPrefsHaveChanged = false;
}


/**
 * Manager the WM_INITDIALOG message
**/
BOOL PrefsDlg::onInitDialog(void)
{
  char buffer[64];

  if(!mHasBeenInitialized)
  {
    initialize();
    mHasBeenInitialized = true;
  }

  // General checkboxes
  UICheckbox::setState(mHChkLogHScroll, PrefsManager::mInstance.mLogHScrollEnabled);
  UICheckbox::setState(mHChkThereCanBeOnlyOne, PrefsManager::mInstance.mThereCanBeOnlyOne);
  UICheckbox::setState(mHChkAutoReload, PrefsManager::mInstance.mAutoReloadEnabled);
  UICheckbox::setState(mHChkMinimizeToTray, PrefsManager::mInstance.mMinimizeToTrayEnabled);
  UICheckbox::setState(mHChkHTTPProxyEnabled, PrefsManager::mInstance.mHTTPProxyEnabled);

  EnableWindow(mHSpiAutoReload, PrefsManager::mInstance.mAutoReloadEnabled);
  SendMessage(mHSpiAutoReload, UDM_SETRANGE, (WPARAM)0, (LPARAM)MAKELONG(9999, 0));

  wsprintf(buffer, "%d", PrefsManager::mInstance.mAutoReloadFrequency);
  UIEdit::setText(mHTxtAutoReload, buffer);
  if(PrefsManager::mInstance.mAutoReloadEnabled)
    UIEdit::enable(mHTxtAutoReload);
  else
    UIEdit::disable(mHTxtAutoReload);


  // -- Checkboxes that depends on the last run duration --
  UICheckbox::setState(mHChkAnalyseLastFrame, PrefsManager::mInstance.mAnalyseLastFrameDuration);
  UICheckbox::setEnabled(mHChkDetectInactiveClients, PrefsManager::mInstance.mAnalyseLastFrameDuration);
  UICheckbox::setEnabled(mHChkComputeEta, PrefsManager::mInstance.mAnalyseLastFrameDuration);
  if(PrefsManager::mInstance.mAnalyseLastFrameDuration == false)
  {
    UICheckbox::setState(mHChkComputeEta, false);
    UICheckbox::setState(mHChkDetectInactiveClients, false);
  }
  else
  {
    UICheckbox::setState(mHChkComputeEta, PrefsManager::mInstance.mComputeETA);
    UICheckbox::setState(mHChkDetectInactiveClients, PrefsManager::mInstance.mCheckForActivity);
  }


  // -- Main dialog view --
  switch(PrefsManager::mInstance.mMainDlgView)
  {
    case PrefsManager::MDV_LIST:
      UIRadioButton::setState(mHRadList, true);
      UIRadioButton::setState(mHRadTabs, false);
      UIRadioButton::setState(mHRadMulti, false);
      break;

    case PrefsManager::MDV_TABS:
      UIRadioButton::setState(mHRadTabs, true);
      UIRadioButton::setState(mHRadList, false);
      UIRadioButton::setState(mHRadMulti, false);
      break;

    case PrefsManager::MDV_MULTI:
      UIRadioButton::setState(mHRadMulti, true);
      UIRadioButton::setState(mHRadTabs, false);
      UIRadioButton::setState(mHRadList, false);
      break;
  }

  // -- HTTP Proxy --
  // Address
  UIText::setEnabled(mHTxtHTTPProxyAddress, PrefsManager::mInstance.mHTTPProxyEnabled);
  UIText::setText(mHTxtHTTPProxyAddress, PrefsManager::mInstance.mHTTPProxyAddress);
  // Port
  UIText::setEnabled(mHTxtHTTPProxyPort, PrefsManager::mInstance.mHTTPProxyEnabled);
  wsprintf(buffer, "%d", PrefsManager::mInstance.mHTTPProxyPort);
  UIText::setText(mHTxtHTTPProxyPort, buffer);

  // No modifications yet
  mPrefsHaveChanged = false;
  UIButton::disable(mHBtnApply);
  SetFocus(mHBtnOk);

  return FALSE;
}


/**
 * Manage the WM_CLOSE message
**/
BOOL PrefsDlg::onClose(void)
{
  if(mPrefsHaveChanged)
    if(questionMessageBox("Some changes have been made.\nDo you want to save them?") == IDYES)
      saveChanges();

  return MyDialogBox::onClose();
}


/**
 * Manage the WM_COMMAND message
**/
BOOL PrefsDlg::onCommand(unsigned int notifyCode, unsigned int id, HWND hControl)
{
  bool enabled;

  switch(notifyCode)
  {
    case EN_CHANGE:
      if(id == ID_PRE_TXT_AUTORELOAD || id == ID_PRE_TXT_HTTPPROXYADDRESS || id == ID_PRE_TXT_HTTPPROXYPORT)
        prefsChanged();
      break;

    case BN_CLICKED:
      enabled = UICheckbox::getState(hControl);
      switch(id)
      {
        // -------- BE CAREFUL, THESE TWO LABELS ARE LINKED TOGETHER --------
        case ID_PRE_CHK_AUTORELOAD:
          EnableWindow(mHTxtAutoReload, enabled);
          EnableWindow(mHSpiAutoReload, enabled);
        case ID_PRE_CHK_MINIMIZETOTRAY:
        case ID_PRE_CHK_LOGHSCROLL:
        case ID_PRE_CHK_THERECANBEONLYONE:
        case ID_PRE_CHK_DETECTINACTIVECLIENTS:
        case ID_PRE_CHK_COMPUTEETA:
          prefsChanged();
          break;
        // ------------------------------------------------------------------

        case ID_PRE_CHK_ANALYSELASTFRAME:
          UICheckbox::setEnabled(mHChkComputeEta, enabled);
          UICheckbox::setEnabled(mHChkDetectInactiveClients, enabled);
          prefsChanged();
          break;

        case ID_PRE_CHK_HTTPPROXYENABLED:
          EnableWindow(mHTxtHTTPProxyAddress, enabled);
          EnableWindow(mHTxtHTTPProxyPort, enabled);
          prefsChanged();
          break;

        case ID_PRE_RAD_LIST:
          if(enabled && PrefsManager::mInstance.mMainDlgView != PrefsManager::MDV_LIST)
            prefsChanged();
          break;

        case ID_PRE_RAD_TABS:
          if(enabled && PrefsManager::mInstance.mMainDlgView != PrefsManager::MDV_TABS)
            prefsChanged();
          break;

        case ID_PRE_RAD_MULTI:
          if(enabled && PrefsManager::mInstance.mMainDlgView != PrefsManager::MDV_MULTI)
            prefsChanged();
          break;

        case ID_PRE_BTN_APPLY:
          saveChanges();
          UIButton::disable(mHBtnApply);     // Apply button must be disabled, since changes have been saved
          break;

        // -------- BE CAREFUL, THESE TWO LABELS ARE LINKED TOGETHER --------
        case ID_PRE_BTN_OK:
          if(mPrefsHaveChanged)
            saveChanges();
        case ID_PRE_BTN_CANCEL:
          MyDialogBox::onClose();
          break;
        // ------------------------------------------------------------------
      }
      break;
  }

  return FALSE;
}
