/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _PREFSMANAGER_H
#define _PREFSMANAGER_H

#include "fahMon.h"


class PrefsManager
{
public:
  // The order MUST NOT be changed
  typedef enum _MAINDLGVIEW
  {
    MDV_LIST,
    MDV_TABS,
    MDV_ERROR,
    MDV_MULTI
  } MainDlgView;


public:
  static PrefsManager mInstance;

  // Application information
  const char* mVersion;
  const char* mAppName;
  const char* mAppNameVersion;

  // Size of the main dialog box
  unsigned int mDialogWidth;
  unsigned int mDialogHeight;

  // Size of the benchmarks dialog box
  unsigned int mBenchmarksDlgWidth;
  unsigned int mBenchmarksDlgHeight;

  // Size of the clients dialog box
  unsigned int mClientsDlgWidth;
  unsigned int mClientsDlgHeight;

  // Width of the columns for the clients dialog box
  unsigned int mClientsDlgColumnNameWidth;
  unsigned int mClientsDlgColumnLocationWidth;

  // Auto reload
  bool mAutoReloadEnabled;
  unsigned int mAutoReloadFrequency;

  // Horizontal scrolling of the text area
  bool mLogHScrollEnabled;

  // The view that should be used in the main dialog box
  MainDlgView mMainDlgView;

  // Minimize to systray?
  bool mMinimizeToTrayEnabled;

  // Only one instance allowed ?
  bool mThereCanBeOnlyOne;

  // Analyse last frame duration ?
  bool mAnalyseLastFrameDuration;

  // Display ETA?
  bool mComputeETA;

  // Check for inactive clients
  bool mCheckForActivity;

  // Use an HTTP proxy ?
  bool mHTTPProxyEnabled;
  char mHTTPProxyAddress[128];
  unsigned int mHTTPProxyPort;


  PrefsManager(void);

  void loadPrefs(const char* filename);
  void savePrefs(const char* filename) const;
};


#endif
