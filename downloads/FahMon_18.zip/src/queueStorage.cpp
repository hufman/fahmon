/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "QueueStorage.h"


/**
 * Constructor
**/
QueueStorage::QueueStorage(unsigned int size) : mSize(size)
{
  mQueue      = new void*[size];
  mNbElements = 0;
  mIn         = 0;
  mOut        = 0;
}


/**
 * Destructor
**/
QueueStorage::~QueueStorage(void)
{
  delete[] mQueue;
}


/**
 * Put an element in the queue
**/
void QueueStorage::put(void *element)
{
  // Store the given element only if there is enough space in the queue
  if(mNbElements < mSize)
  {
    mQueue[mIn] = element;
    ++mNbElements;
    ++mIn;
    if(mIn == mSize)
      mIn = 0;
  }
}


/**
 * Get an element
**/
void* QueueStorage::get(void)
{
  void *element;

  // If the queue is empty, nothing can be returned
  if(mNbElements == 0)
    return NULL;

  // Otherwise, remove and return the element located at position "mOut"
  element = mQueue[mOut];
  --mNbElements;
  ++mOut;
  if(mOut == mSize)
    mOut = 0;

  return element;
}
