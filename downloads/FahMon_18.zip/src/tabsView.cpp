#include "tabsView.h"
#include <commctrl.h>
#include "resource.h"
#include "worker.h"
#include "tools.h"

#include "UITab.h"


TabsView::TabsView(HWND hDialog, unsigned int currentClient) : MainView(hDialog, GetDlgItem(hDialog, ID_MAI_TAB_CLIENTS), currentClient)
{
  unsigned int i, neededSizeY, nbRows;

  // Create a tab for each known client
  for(i=0; i<ClientsList::mInstance.getSize(); ++i)
    UITab::insertTab(mHViewControl, ClientsList::mInstance.getClient(i)->getClientName(), i);

  // Compute the needed height
  SetWindowPos(mHViewControl, NULL, 0, 0, 479, 1, SWP_NOMOVE | SWP_NOZORDER);
  nbRows = UITab::getRowCount(mHViewControl);
  if(nbRows == 1)
    neededSizeY = 23;
  else if(nbRows <= 3)
    neededSizeY = nbRows * 20 + 1;
  else
    neededSizeY = 77;

  // Move and resize the tabs control
  SetWindowPos(mHViewControl, NULL, 9, (77 - neededSizeY)/2 + 10, 479, neededSizeY, SWP_NOZORDER);
}


/**
 * Destructor.
 * Reset the tabs control to its initial (empty) state.
**/
TabsView::~TabsView(void)
{
  UITab::deleteAllTabs(mHViewControl);
}


/**
 * The view has been changed to tabs, so initialize what needs to be initialized.
 *
 * @param currentClient The currently selected client.
**/
void TabsView::init(unsigned int currentClient, bool errorMode)
{
  mCurrentClient = currentClient;
  UITab::show(mHViewControl);
  UITab::setCurrentSelection(mHViewControl, mCurrentClient);

  mErrorMode = errorMode;
  if(mErrorMode)
    switchToError();
  else
    switchToView();

  reloadRequested();

  // Give the correct position/size to items
  SetWindowPos(mHLblProject, NULL, 29, 140, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblCredit, NULL, 29, 175, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblProjectValue, NULL, 81, 140, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblCreditValue, NULL, 81, 175, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDownloaded, NULL, 236, 140, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDueTime, NULL, 236, 175, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDownloadedValue, NULL, 323, 140, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDueTimeValue, NULL, 323, 175, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblCoreName, NULL, 17, 110, 460, 20, SWP_NOZORDER);
  SetWindowPos(mHGrpWuInfo, NULL, 6, 93, 487, 121, SWP_NOZORDER);
  SetWindowPos(mHIcoInfo, mHGrpWuInfo, 19, 90, 20, 20, 0); 
}


/**
 * Manage the WM_NOTIFY message.
**/
BOOL TabsView::onNotify(NMHDR* information)
{
  if(information->idFrom == ID_MAI_TAB_CLIENTS && information->code == TCN_SELCHANGE)
  {
    mCurrentClient = UITab::getCurrentSelection(mHViewControl);
    reloadRequested();
  }

  return FALSE;
}


/**
 * A client has been reloaded.
 *
 * @param clientIndex The index of this client.
 *
 * @return true if information about the client could be loaded, false otherwise.
**/
void TabsView::reloadDone(unsigned int clientIndex)
{
  char buffer[256];
  FahClient *client;

  if(clientIndex == mCurrentClient)
  {
    MainView::displayInfo();

    client = ClientsList::mInstance.getClient(clientIndex);
    if(PrefsManager::mInstance.mComputeETA)
    {
      if(!client->isValid())
        CopyMemory(buffer, MAIN_GROUP_LABEL, MAIN_GROUP_LABEL_SIZE+1);
      else if(PrefsManager::mInstance.mCheckForActivity && !client->isRunning())
        wsprintf(buffer, "%s  /  Inactive ", MAIN_GROUP_LABEL);
      else
        wsprintf(buffer, "%s  /  %s ", MAIN_GROUP_LABEL, client->getWUETA());

      setGroupLabel(buffer);
    }
  }
}


/**
 * Perform a reload.
**/
void TabsView::reloadRequested(void)
{
  if(mCurrentClient < ClientsList::mInstance.getSize())
    Worker::mInstance->addJob(mHDialog, Worker::JOB_LOADCLIENT, (WPARAM)ClientsList::mInstance.getClient(mCurrentClient), (LPARAM)mCurrentClient);
}
