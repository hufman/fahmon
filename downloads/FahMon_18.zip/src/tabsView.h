#ifndef _TABSVIEW_H
#define _TABSVIEW_H

#include "fahMon.h"
#include "mainView.h"


class TabsView : public MainView
{
public:
  TabsView(HWND hDialog, unsigned int currentClient);
  ~TabsView(void);

  virtual void init(unsigned int currentClient, bool errorMode);
  virtual void reloadRequested(void);
  virtual void reloadDone(unsigned int clientIndex);
  virtual BOOL onNotify(NMHDR* information);
};


#endif
