/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _TOOLS_H
#define _TOOLS_H

#include "fahMon.h"

class Tools
{
public:
  static unsigned int atoi(const char* string);
  static double atod(const char* string);
  static bool strcmp(const char* left, const char* right, unsigned int maxSize);
  static void secondsToString(char* output, unsigned int nbSeconds);
  static void accurateSecondsToString(char* output, unsigned int nbSeconds);
  static void openURL(const char* url);
  static bool isRunningOnXP(void);
};


#endif
