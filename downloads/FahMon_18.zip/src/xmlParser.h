/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _XMLPARSER_H
#define _XMLPARSER_H

#include "fahMon.h"
#include "t_DynamicArray.h"

class XMLParser
{
public:
  typedef enum
  {
    TK_START_TAG,
    TK_END_TAG,
    TK_UNKNOWN_START_TAG,
    TK_UNKNOWN_END_TAG,
    TK_TEXT,
    TK_END
  } TOKEN;


protected:
  // The String to parse
  const char *mToBeParsed;
  unsigned int mToBeParsedLength;
  unsigned int mCurrentPos;
  unsigned int mCurrentLine;

  // The last found token
  TOKEN mCurrentToken;
  unsigned int mCurrentTag;

  // Store the text found between tags
  char* mText;
  unsigned int mTextLength;
  unsigned int mTextMaxLength;
  const unsigned int mTextStep;

  // All the known tags
  TDynamicArray<char> mKnownTagsAscii;
  TDynamicArray<unsigned int> mKnownTagsValue;

  // true when the character is a separator, false otherwise
  bool mSeparators[256];

  void atotag(const char* tag, unsigned int length);


public:
  XMLParser(char* toBeParsed);
  ~XMLParser(void);

  void addTag(const char* tag, unsigned int value);
  void nextToken(void);
  
  TOKEN getToken(void) const {return mCurrentToken;}
  const char* getTextValue(void) const {return mText;}
  unsigned int getTextLength(void) const {return mTextLength;}
  unsigned int getTag(void) const {return mCurrentTag;}
  unsigned int getCurrentLine(void) const {return mCurrentLine;}
};


#endif
