/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "UIListView.h"
#include "fahMon.h"


/**
 * Change the selection of a ListView
**/
void UIListView::setCurrentSelection(HWND hList, unsigned int item)
{
  ListView_SetItemState(hList, item, LVIS_SELECTED, LVIS_SELECTED);
  ListView_SetItemState(hList, item, LVIS_FOCUSED, LVIS_FOCUSED);
  ListView_EnsureVisible(hList, item, FALSE);
}


/**
 * Add a colum to the given list
**/
void UIListView::addColumn(HWND hList, unsigned int columnIndex, const char* name, unsigned int width)
{
  LVCOLUMN columnInfo;

  columnInfo.mask = LVCF_TEXT | LVCF_WIDTH;
  columnInfo.pszText = const_cast<char*>(name);
  columnInfo.cx = width;
  ListView_InsertColumn(hList, columnIndex, &columnInfo);
}


/**
 * Insert an item into the given list
**/
void UIListView::insertItemWithoutIcon(HWND hList, unsigned int itemIndex, unsigned int columnIndex, const char* name)
{
  LVITEM itemInfo;

  itemInfo.mask = LVIF_TEXT;
  itemInfo.iItem = itemIndex;
  itemInfo.iSubItem = columnIndex;
  itemInfo.pszText = const_cast<char*>(name);
  ListView_InsertItem(hList, &itemInfo);
}


/**
 * Insert an item into the given list
**/
void UIListView::insertItemWithIcon(HWND hList, unsigned int itemIndex, unsigned int columnIndex, unsigned int iconIndex, const char* name)
{
  LVITEM itemInfo;

  itemInfo.mask = LVIF_TEXT | LVIF_IMAGE;
  itemInfo.iItem = itemIndex;
  itemInfo.iSubItem = columnIndex;
  itemInfo.iImage = iconIndex;
  itemInfo.pszText = const_cast<char*>(name);
  ListView_InsertItem(hList, &itemInfo);
}


/**
 * Change the text of an item
**/
void UIListView::setItemText(HWND hList, unsigned int itemIndex, unsigned int columnIndex, const char* name)
{
  LVITEM itemInfo;

  itemInfo.mask = LVIF_TEXT;
  itemInfo.iItem = itemIndex;
  itemInfo.iSubItem = columnIndex;
  itemInfo.pszText = const_cast<char*>(name);
  ListView_SetItem(hList, &itemInfo);
}


/**
 * Retrieve the label of the given item
 * itemText is filled with the label, which will be truncated if it is longer than itemTextMaxLength
**/
void UIListView::getItemText(HWND hList, unsigned int itemIndex, unsigned int columnIndex, char* itemText, unsigned int itemTextMaxLength)
{
  LVITEM itemInfo;

  itemInfo.mask = LVIF_TEXT;
  itemInfo.iItem = itemIndex;
  itemInfo.iSubItem = columnIndex;
  itemInfo.cchTextMax = itemTextMaxLength;
  itemInfo.pszText = itemText;
  ListView_GetItem(hList, &itemInfo);
}
