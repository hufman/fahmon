/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _CLIENTLIST_H_
#define _CLIENTLIST_H_

#include "fahMon.h"
#include "FahClient.h"
#include "t_DynamicArray.h"


class ClientsList
{
protected:
  TDynamicArray<FahClient> mClients;

public:

  static ClientsList mInstance;

  void loadFromFile(const char* filename);
  void saveToFile(const char* filename);


  //
  // Inline members
  //
  

  /**
   * Add a new client to the list.
  **/
  void addClient(const char* name, const char* directory)
  {
    mClients.addItem(new FahClient(name, directory));
  }


  /**
   * @return The client located at the specified index.
  **/
  FahClient* getClient(unsigned int index)
  {
    return mClients.getItem(index);
  }


  /**
   * @return The number of stored clients.
  **/
  unsigned int getSize(void) const
  {
    return mClients.getNbItems();
  }


  /**
   * Remove all the known clients.
  **/
  void clear(void)
  {
    mClients.clear();
  }
};


#endif
