/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "date.h"
#include "tools.h"


unsigned int nbDaysPerMonth[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};


/**
 * Constructor.
 * The format of the String should be something like '13:25:40'
**/
Date::Date(const char* timestamp)
{
  SYSTEMTIME sysTime;

  GetLocalTime(&sysTime);

  mHour   = Tools::atoi(timestamp);
  mMinute = Tools::atoi(&timestamp[3]);
  mSecond = Tools::atoi(&timestamp[6]);

  mDay   = sysTime.wDay;
  mMonth = sysTime.wMonth - 1;
  mYear  = sysTime.wYear;

  // February has 29 days if the year is a leap one
  if(Date::isLeapYear(mYear))
    nbDaysPerMonth[1] = 29;
}


/**
 * Constructor.
 * Set the time to the current one.
**/
Date::Date(void)
{
  SYSTEMTIME sysTime;

  GetLocalTime(&sysTime);

  mSecond = sysTime.wSecond;
  mMinute = sysTime.wMinute;
  mHour   = sysTime.wHour;
  mDay    = sysTime.wDay;
  mMonth  = sysTime.wMonth - 1;
  mYear   = sysTime.wYear;

  // February has 29 days if the year is a leap one
  if(Date::isLeapYear(mYear))
    nbDaysPerMonth[1] = 29;
}


/**
 * Compute the number of elapsed seconds between the current date and the one given as a parameter.
 * Only seconds, minutes and hours are used.
**/
unsigned int Date::computeElapsedSeconds(Date *anotherDate) const
{
  int nbSec = (anotherDate->mHour - mHour) * 3600 + (anotherDate->mMinute - mMinute) * 60 + anotherDate->mSecond - mSecond;

  if(nbSec > 0)
    return nbSec;

  return nbSec + 86400;
}


/**
 * Add a given amount of seconds to the current date.
**/
void Date::add(unsigned int nbSeconds)
{
  // 1. Second
  mSecond += nbSeconds;
  if(mSecond < 60)
    return;

  // 2. Minute
  mMinute += mSecond/60;
  mSecond %= 60;
  if(mMinute < 60)
    return;

  // 3. Hour
  mHour += mMinute/60;
  mMinute %= 60;
  if(mHour < 24)
    return;

  // 4. Day, Month, Year
  mDay += mHour/24;
  mHour %= 24;
  while(mDay > nbDaysPerMonth[mMonth])
  {
    mDay -= nbDaysPerMonth[mMonth];
    ++mMonth;
    if(mMonth == 12)
    {
      mMonth = 0;
      ++mYear;

      // Take care of February
      if(Date::isLeapYear(mYear))
        nbDaysPerMonth[1] = 29;
      else
        nbDaysPerMonth[1] = 28;
    }
  }
}
