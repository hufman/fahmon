/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _FAHCLIENT_H
#define _FAHCLIENT_H

#include "fahMon.h"
#include "fahContributor.h"
#include "fahWorkUnit.h"
#include "fahLog.h"


class FahClient
{
protected:
  // false if something went wrong when loading information
  bool mValid;

  // Where is located this client?
  char mClientName[CLIENT_NAME_MAX_LENGTH];
  char* mBasePath;
  char* mUnitinfoPath;
  char* mClientCfgPath;
  char* mFahLogPath;

  // Information about it
  unsigned short int mClientNumber;
  bool mIsRunning;
  FahContributor mUserInformation;
  FahWorkUnit mWUInformation;
  FahLog mLog;
  char mETA[256];

  void loadUnitinfo(char* buffer, unsigned int bufferSize);
  void loadConfigFile(char* buffer, unsigned int bufferSize);
  void computeETA(void);
  void checkForActivity(void);

public:
  FahClient(const char *clientname, const char* directory);
  ~FahClient(void);

  void load(void);

  bool isValid(void) const {return mValid;}
  bool isRunning(void) const {return mIsRunning;}

  const char* getClientName(void) const {return mClientName;}

  const char* getLogContent(void) const {return mLog.getLogContent();}
  const char* getPath(void) const {return mBasePath;}

  const char* getContributorUserName(void) const {return mUserInformation.getUserName();}
  unsigned int getContributorTeamNumber(void) const {return mUserInformation.getTeamNumber();}

  unsigned int getWUProjectNumber(void) const {return mWUInformation.getProjectNumber();}
  const char* getWUETA(void) const {return mETA;}
  unsigned int getWUProgress(void) const {return mWUInformation.getProgress();}
  const char* getWUDownloadTime(void) const {return mWUInformation.getDownloadTime();}
  const char* getWUDueTime(void) const {return mWUInformation.getDueTime();}
  double getWUCredit(void) const {return mWUInformation.getCredit();}
  FahCore::CORE getWUCore(void) const {return mWUInformation.getCore();}

  void updateWUInformation(void) {mWUInformation.setProjectNumber(mWUInformation.getProjectNumber());}
};


#endif
