/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "fahLog.h"
#include <limits.h>
#include "fileTools.h"
#include "tools.h"
#include "date.h"


#define FAHLOG_ERROR        "The log file could not be loaded!"
#define FAHLOG_ERROR_LENGTH 33


FahWURun::FahWURun(void)
{
  reset();
}


void FahWURun::reset(void)
{
  mValid                   = false;
  mRunDuration             = 0;
  mRunNumber               = 0;
  mElapsedTimeSinceThisRun = 0;
}


/**
 * Constructor.
**/
FahLog::FahLog(void)
{
  mLogContent                      = NULL;
  mLogContentSize                  = 0;
  mElapsedTimeSinceLastWriteAccess = UINT_MAX;
  mPath[0]                         = '\0';
}


/**
 * Destructor.
**/
FahLog::~FahLog(void)
{
  if(mLogContent != NULL)
    delete[] mLogContent;
}


/**
 * Load the content of the log file.
**/
void FahLog::load(void)
{
  char* newLog;

  // Free the memory used by the old content, if any, and load the new content
  if(mLogContent != NULL)
    delete[] mLogContent;
  mLogContent = FileTools::loadTextFile(mPath, &mLogContentSize);

  // If the log cannot be loaded, we load the default error
  if(mLogContent == NULL)
  {
    mLogContentSize = FAHLOG_ERROR_LENGTH;
    mLogContent     = new char[FAHLOG_ERROR_LENGTH + 1];
    CopyMemory(mLogContent, FAHLOG_ERROR, FAHLOG_ERROR_LENGTH + 1);
  }
  // Otherwise, we delete any uneeded empty new lines at the end
  else
  {
    while(mLogContent[mLogContentSize-1] == CHAR_LF || mLogContent[mLogContentSize-1] == CHAR_CR)
      --mLogContentSize;
    mLogContent[mLogContentSize] = '\0';

    // Convert the log to the Windows text file format (LF -> CR LF) so that the text area should correctly display it
    // If the content was already in the Windows format, newLog will be equal to NULL
    newLog = FileTools::linuxFmtToWindowsFmt(mLogContent, &mLogContentSize);
    if(newLog != NULL)
    {
      delete[] mLogContent;
      mLogContent = newLog;
    }
  }
}


/**
 * Find where the previous line begins, starting from the given index.
 *
 * @remark the return value is equal to startIndex when the start of the log file has been reached.
**/
inline int FahLog::findPreviousLine(unsigned int startIndex)
{
  unsigned int index;

  if(startIndex == 0)
    return 0;

  index = startIndex - 1;
  while(mLogContent[index] != CHAR_LF)
  {
    if(index == 0)
      return startIndex;

    --index;
  }

  return index+1;
}


/**
 * Analyze the last frame done.
**/
void FahLog::analyzeLastRun(void)
{
  unsigned int startIndex, newStartIndex, currentIndex, nbTotalSteps, nbCurrentSteps, tmpIndex;
  Date *runStartDate = NULL, *runEndDate = NULL, *tmpDate = NULL;
  SYSTEMTIME sysTime;
  FILETIME fileTime1, fileTime2;
  LARGE_INTEGER li1, li2;

  mElapsedTimeSinceLastWriteAccess = UINT_MAX;
  mLastRunInformation.reset();

  // Start parsing from the end of the log
  startIndex = mLogContentSize;

  while(true)
  {
    // Find the starting index of the previous line
    currentIndex = findPreviousLine(startIndex);

    // Stop if there is no previous line
    // Stop also if there is no time tag: these lines are generally found when the client has just been started, so we won't find any frame information
    if(currentIndex == startIndex || mLogContent[currentIndex] != '[')
      break;

    // Use the first time tag to determine the elapsed time since the last write acess
    if(mElapsedTimeSinceLastWriteAccess == UINT_MAX)
    {
      tmpDate = new Date(&mLogContent[currentIndex+1]);

      FileTools::getLastWriteAccess(mPath, &fileTime1);
      FileTimeToSystemTime(&fileTime1, &sysTime);
      sysTime.wHour   = tmpDate->mHour;
      sysTime.wMinute = tmpDate->mMinute;
      sysTime.wSecond = tmpDate->mSecond;
      SystemTimeToFileTime(&sysTime, &fileTime1);
      //   2) Current time
      GetSystemTime(&sysTime);
      SystemTimeToFileTime(&sysTime, &fileTime2);
      //   3) Elapsed time
      CopyMemory(&li1, &fileTime1, sizeof(LARGE_INTEGER));
      CopyMemory(&li2, &fileTime2, sizeof(LARGE_INTEGER));
      //   4) Absolute difference
      if(li2.QuadPart > li1.QuadPart)
        mElapsedTimeSinceLastWriteAccess = (unsigned int)((li2.QuadPart - li1.QuadPart) / 10000000);
      else
        mElapsedTimeSinceLastWriteAccess = (unsigned int)((li1.QuadPart - li2.QuadPart) / 10000000);

      delete tmpDate;
    }

    // Next time, we will search the previous line before the current one
    newStartIndex = currentIndex - 2;

    // We know there is a time tag, so we just skip it
    currentIndex += 11;

    // 'Completed' (Gromacs/DGromacs/Amber) and 'Finished' (Tinker) words indicate the end of a run
    if(Tools::strcmp(&mLogContent[currentIndex], "Completed", 9) || Tools::strcmp(&mLogContent[currentIndex], "Finished", 8))
    {
      // Find the run number, starting from the end of the line
      while(mLogContent[startIndex] != '(')
        --startIndex;

      // Is this the end of the last run, or its start?
      if(runEndDate == NULL)
      {
        mLastRunInformation.setRunNumber(Tools::atoi(&mLogContent[startIndex + 1]));
        runEndDate = new Date(&mLogContent[currentIndex] - 10);

        // Compute how many seconds have elapsed since the end of this run
        //   1) Time of the end
        FileTools::getLastWriteAccess(mPath, &fileTime1);
        FileTimeToSystemTime(&fileTime1, &sysTime);
        sysTime.wHour   = runEndDate->mHour;
        sysTime.wMinute = runEndDate->mMinute;
        sysTime.wSecond = runEndDate->mSecond;
        SystemTimeToFileTime(&sysTime, &fileTime1);
        //   2) Current time
        GetSystemTime(&sysTime);
        SystemTimeToFileTime(&sysTime, &fileTime2);
        //   3) Elapsed time
        CopyMemory(&li1, &fileTime1, sizeof(LARGE_INTEGER));
        CopyMemory(&li2, &fileTime2, sizeof(LARGE_INTEGER));
        mLastRunInformation.setElapsedTimeSinceThisRun((unsigned int)((li2.QuadPart - li1.QuadPart) / 10000000));
      }
      // This is the start of the last run, since the end has already been found
      else
      {
        // Be careful to not use incomplete 'runs' (useful for Gromacs, DGromacs and Amber WUs)
        if(mLogContent[currentIndex] == 'C')
        {
          // The number of completed steps must be a 'round' number
          //  "Completed 96283 out of 100000 steps  (96)" is not a correct frame.
          //
          // As a general rule, "Completed X out of Y steps" means that X MUST be a multiple of Y/100

          // Retrieve the current step
          tmpIndex = currentIndex + 10;
          nbCurrentSteps = Tools::atoi(&mLogContent[tmpIndex]);

          // Skip the digits
          while(mLogContent[tmpIndex] != ' ')
            ++tmpIndex;

          // Retrieve the total number of steps
          nbTotalSteps = Tools::atoi(&mLogContent[tmpIndex + 8]);

          // And check if this run is a complete one or not
          if(nbCurrentSteps % (nbTotalSteps/100) == 0)
            runStartDate = new Date(&mLogContent[currentIndex]-10);
        }
        // Tinker WUs always perform complete runs
        else
          runStartDate = new Date(&mLogContent[currentIndex]-10);

        // We can stop parsing the log because we can now compute the duration of the last frame
        break;
      }
    }
    // The line is not the end of a frame, so we have to decide if we continue to parse the file or not
    // Only a few words are accepted:
    //  'Timered'  --> 'Timered checkpoint triggered.'
    //  'Writing'  --> 'Writing local files'
    //  'Received' --> 'Received unknown signal from OS.'
    //  'Trying'   --> 'Trying to send all finished work units'
    //  '+'        --> '+ No unsent completed units remaining.'
    //  '-'        --> '- Autosend completed'
    //  'Extra'    --> 'Extra SSE boost OK'.
    else if(!Tools::strcmp(&mLogContent[currentIndex], "Timered", 7)  &&
            !Tools::strcmp(&mLogContent[currentIndex], "Writing", 7)  &&
            !Tools::strcmp(&mLogContent[currentIndex], "Received", 8) &&
            !Tools::strcmp(&mLogContent[currentIndex], "Trying", 6)   &&
            mLogContent[currentIndex] != '+'                          &&
            mLogContent[currentIndex] != '-'                          &&
            !Tools::strcmp(&mLogContent[currentIndex], "Extra", 5)
           )
      break;

    // Use the new index for the next loop
    startIndex = newStartIndex;
  }

  if(runEndDate != NULL)
  {
    if(runStartDate != NULL)
    {
      mLastRunInformation.setRunDuration(runStartDate->computeElapsedSeconds(runEndDate));
      mLastRunInformation.setValid(true);
      delete runStartDate;
    }
    delete runEndDate;
  }
}
