/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

// The content of this file should not be inserted in the final executable if _MEMORY_DEBUG_ is not defined
#ifndef _MEMORY_DEBUG_

void lh_dump(void)
{

}


#else


#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <malloc.h>


#define MAX_FILENAME 128
#define OUTPUT_FILE "leakHunter.log"


// This structure is used to keep trace of allocated memory
typedef struct _ALLOCATED_BLOCK
{
  void *ptr;                        // Pointer returned by malloc()
  char file[MAX_FILENAME];          // The filename which contains the call to new
  unsigned int line;                // The line where the new is located
  unsigned int size;                // Size of the allocated memory
  struct _ALLOCATED_BLOCK *next;
} ALLOCATED_BLOCK;


ALLOCATED_BLOCK *lh_trace = NULL;
unsigned int lh_maxUsedMemory = 0;
unsigned int lh_usedMemory = 0;


/**
 * Dump the unfreed memory, if there is some
**/
void lh_dump(void)
{
  ALLOCATED_BLOCK *currentBlock = lh_trace;
  ALLOCATED_BLOCK *tmpBlock;
  unsigned int total = 0;
  HANDLE hFile;
  DWORD written;
  char buffer[256];
  
  // Don't do anything if the memory was correctly freed
  if(!currentBlock)
    return;

  MessageBox(NULL, "Some unfreed memory has been found\nA log file will be created.", "Memory leak!", MB_OK | MB_ICONEXCLAMATION);

  // Open the file
  if(INVALID_HANDLE_VALUE == (hFile = CreateFile(OUTPUT_FILE, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL)))
  {
    MessageBox(NULL, "Unable to create the log file!", "Memory leak!", MB_OK | MB_ICONERROR);
    return;
  }

  if(lh_maxUsedMemory <1024)
    sprintf(buffer, "\nMaximum used memory : %d byte(s).\n\n", lh_maxUsedMemory);
  else if(lh_maxUsedMemory < 1024*1024)
    sprintf(buffer, "\nMaximum used memory : %.2f Kbyte(s).\n\n", (double)lh_maxUsedMemory/1024.0);
  else
    sprintf(buffer, "\nMaximum used memory : %.2f Mbyte(s).\n\n", (double)lh_maxUsedMemory/(1024.0*1024.0));
  WriteFile(hFile, buffer, lstrlen(buffer), &written, NULL);

  sprintf(buffer, "[%s, %d] Some memory has not been freed.\n\n", __FILE__, __LINE__);
  WriteFile(hFile, buffer, lstrlen(buffer), &written, NULL);
  sprintf(buffer, "File                                                Line    Size\n");
  WriteFile(hFile, buffer, lstrlen(buffer), &written, NULL);
  sprintf(buffer, "----------------------------------------------------------------\n");
  WriteFile(hFile, buffer, lstrlen(buffer), &written, NULL);
  while(currentBlock)
  {
    sprintf(buffer, "%-50s % 5d  % 6d\n", currentBlock->file, currentBlock->line, currentBlock->size);
    WriteFile(hFile, buffer, lstrlen(buffer), &written, NULL);
    total += currentBlock->size;

    // Free the memory, but it shouldn't be useful
    tmpBlock = currentBlock;
    currentBlock = currentBlock->next;
    free(tmpBlock);
  }
  sprintf(buffer, "----------------------------------------------------------------\n");
  WriteFile(hFile, buffer, lstrlen(buffer), &written, NULL);
  if(total <1024)
    sprintf(buffer, "Total : %d byte(s).\n\n", total);
  else if(total < 1024*1024)
    sprintf(buffer, "Total : %.2f Kbyte(s).\n\n", (double)total/1024.0);
  else
    sprintf(buffer, "Total : %.2f Mbyte(s).\n\n", (double)total/(1024.0*1024.0));
  WriteFile(hFile, buffer, lstrlen(buffer), &written, NULL);
}


/**
 * Remove a trace from the linked list
**/
void lh_removeTrace(void *ptr)
{
  ALLOCATED_BLOCK *currentBlock = lh_trace;
  ALLOCATED_BLOCK **oldBlock = &lh_trace;

  // Find the block
  while(currentBlock)
  {
    if(currentBlock->ptr == ptr)
    {
      *oldBlock = currentBlock->next;
      lh_usedMemory -= currentBlock->size;
      free(currentBlock);
      break;
    }

    oldBlock = &currentBlock->next;
    currentBlock = currentBlock->next;    
  }
}


/**
 * Add a trace
**/
void lh_addTrace(void *ptr, const char *file, int line, int size)
{
  ALLOCATED_BLOCK *block = (ALLOCATED_BLOCK*)malloc(sizeof(ALLOCATED_BLOCK));

  block->ptr = ptr;
  block->line = line;
  block->size = size;
  strncpy(block->file, file, MAX_FILENAME);
  block->next = lh_trace;
  lh_trace = block;
}


/**
 * Our customized version of new
**/
void* __cdecl operator new(size_t size, const char *file, int line)
{
  void *ptr = malloc(size);

  lh_usedMemory += size;
  if(lh_usedMemory > lh_maxUsedMemory)
    lh_maxUsedMemory = lh_usedMemory;

  lh_addTrace(ptr, file, line, size);

  return ptr;
}


/**
 * Our customized version of delete
**/
void __cdecl operator delete(void* ptr)
{
  lh_removeTrace(ptr);
  free(ptr);
}


#endif
