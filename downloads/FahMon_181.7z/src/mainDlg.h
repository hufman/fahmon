/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _MAINDLG_H
#define _MAINDLG_H

#include "fahMon.h"
#include "myDialogBox.h"
#include "resizableDlg.h"
#include "clientsList.h"
#include "projectsManager.h"
#include "systrayManager.h"
#include "prefsDlg.h"
#include "aboutDlg.h"
#include "clientsDlg.h"
#include "benchmarksDlg.h"
#include "prefsManager.h"
#include "worker.h"
#include "resource.h"
#include "listOfAllViews.h"


class MainDlg : public MyDialogBox, public ResizableDlg
{
protected:
  // These attributes are used to bind the controls
  HWND mHTxtLog;
  HWND mHLblCoreName;
  HWND mHLblError;
  HWND mHLblStatus;

  SystrayManager *mSystrayManager;
  PrefsDlg *mPrefsDlg;
  AboutDlg *mAboutDlg;
  ClientsDlg *mClientsDlg;
  BenchmarksDlg *mBenchmarksDlg;
  PrefsManager::MainDlgView mCurrentViewId;
  MainView *mCurrentView;
  TabsView *mTabsView;
  ListView *mListView;
  MultiView *mMultiView;
  bool mStartMinimized, mTimerRunning, mIsMinimized, mShouldReloadAfterRestore, mWorkInBackground;
  unsigned int mLastProjectsUpdate;

  BOOL dialogProc(UINT msg, WPARAM wParam, LPARAM lParam);
  BOOL onInitDialog(void* param);
  BOOL onClose(void);
  BOOL onCommand(unsigned int notifyCode, unsigned int id, HWND hControl);
  BOOL onNotify(unsigned int id, NMHDR* information);
  BOOL onCtlColorStatic(HDC hDc, HWND hWnd);
  BOOL onSize(unsigned int fwSizeType, unsigned int width, unsigned int height);
  BOOL onTrayNotification(unsigned int mouseAction);
  BOOL onTimer(unsigned int timerId);
  BOOL onWorkerThread(Worker::JOB job, LPARAM lParam);

  void workInBackground(bool working);
  void setStatus(const char *msg) {SetWindowText(getItem(ID_MAI_LBL_STATUS), msg);}
  void reflowControls(unsigned int clientAreaWidth, unsigned int clientAreaHeight) const;

  void gotoStatsURL(void);
  void updatePoints(void);
  void updateAutoReload(void);
  void updateMainView(unsigned int currentCLient);
  void updateClientsList(void);
  void updateScrollbar(void);

public:
  MainDlg(HINSTANCE hInstance, bool startMinimized = false);
  ~MainDlg(void);
};


#endif
