#include "multiView.h"
#include <commctrl.h>
#include "resource.h"
#include "worker.h"
#include "tools.h"

#include "UIListView.h"


/**
 * Constructor.
**/
MultiView::MultiView(HWND hDialog, unsigned int currentClient) : MainView(hDialog, GetDlgItem(hDialog, ID_MAI_LST_CLIENTSMULTI), currentClient),
                                                                 mLongestNameLength(0),
                                                                 mInitializing(false),
                                                                 mFixedFont(NULL),
                                                                 mFixedStrikedFont(NULL)
{
  unsigned int i, length;
  FahClient* client;
  char buffer[128];

  // General font for the list
  mFixedFont = CreateFont(15, 7, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, "Courier New");
  if(mFixedFont != NULL)
    SendMessage(mHViewControl, WM_SETFONT, (WPARAM)mFixedFont, (LPARAM)TRUE);

  // Used for invalid clients
  mFixedStrikedFont = CreateFont(15, 7, 0, 0, FW_NORMAL, FALSE, FALSE, TRUE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, "Courier New");

  UIListView::enableFullRowSelection(mHViewControl);
  UIListView::addColumn(mHViewControl, 0, "", (ClientsList::mInstance.getSize() > 12) ? 215 : 231);
  SetWindowPos(mHViewControl, NULL, 6, 13, 239, 202, SWP_NOZORDER);

  for(i=0; i<ClientsList::mInstance.getSize(); ++i)
  {
    client = ClientsList::mInstance.getClient(i);

    // Store the longest length
    length = lstrlen(client->getClientName());
    if(length > mLongestNameLength)
      mLongestNameLength = length;

    // And add an entry
    wsprintf(buffer, "00% %s", client->getClientName());
    UIListView::insertItemWithoutIcon(mHViewControl, i, 0, buffer);
  }
}


/**
 * Destructor.
**/
MultiView::~MultiView(void)
{
  if(mFixedFont != NULL)
    DeleteObject(mFixedFont);

  if(mFixedStrikedFont != NULL)
    DeleteObject(mFixedStrikedFont);

  UIListView::deleteAllItems(mHViewControl);
  UIListView::deleteColumn(mHViewControl, 0);
}


/**
 * The view has been changed to tabs, so initialize what needs to be initialized.
 *
 * @param currentClient The currently selected client.
**/
void MultiView::init(unsigned int currentClient, bool errorMode)
{
  mCurrentClient = currentClient;
  UIListView::show(mHViewControl);
  setGroupLabel(MAIN_GROUP_LABEL);

  mErrorMode = errorMode;
  if(mErrorMode)
    switchToError();
  else
    switchToView();

  // mInitializing prevents onNotify() to modify mCurrentClient
  mInitializing = true;
  UIListView::setCurrentSelection(mHViewControl, mCurrentClient);
  mInitializing = false;
  
  reloadRequested();

  // Give the correct position/size to items
  SetWindowPos(mHLblProject, NULL, 288, 70, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblProjectValue, NULL, 339, 70, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblCredit, NULL, 286, 107, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblCreditValue, NULL, 339, 105, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDownloaded, NULL, 252, 140, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDownloadedValue, NULL, 339, 140, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDueTime, NULL, 252, 175, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDueTimeValue, NULL, 339, 175, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblCoreName, NULL, 272, 30, 204, 20, SWP_NOZORDER);
  SetWindowPos(mHGrpWuInfo, NULL, 254, 6, 238, 210, SWP_NOZORDER);
  SetWindowPos(mHIcoInfo, mHGrpWuInfo, 267, 3, 20, 20, 0); 
}


/**
 * Manage the WM_NOTIFY message.
**/
BOOL MultiView::onNotify(NMHDR* information)
{
  unsigned int selectedItem;
  NMLVCUSTOMDRAW *customDraw;
  LONG lResult;
  FahClient *client;

  if(information->idFrom != ID_MAI_LST_CLIENTSMULTI)
    return FALSE;

  switch(information->code)
  {
    // If the selection has changed and is valid, then reload and display the corresponding information
    case LVN_ITEMCHANGED:
      selectedItem = UIListView::getCurrentSelection(mHViewControl);
      if(!mInitializing && selectedItem < ClientsList::mInstance.getSize() && selectedItem != mCurrentClient)
      {
        mCurrentClient = selectedItem;
        Worker::mInstance->addJob(mHDialog, Worker::JOB_LOADCLIENT, (WPARAM)ClientsList::mInstance.getClient(mCurrentClient), (LPARAM)mCurrentClient);
      }
      break;

    // Force the current selection to keep the focus
    case NM_CLICK:
    case NM_RCLICK:
    case NM_DBLCLK:
    case NM_RDBLCLK:
      UIListView::setCurrentSelection(mHViewControl, mCurrentClient);
      break;

    case NM_CUSTOMDRAW:
      customDraw = (NMLVCUSTOMDRAW*)information;
      lResult = CDRF_DODEFAULT;

      switch(customDraw->nmcd.dwDrawStage)
      {
        case CDDS_PREPAINT:
          lResult = CDRF_NOTIFYITEMDRAW;
          break;

        case CDDS_ITEMPREPAINT:
          // Darken every odd line
          if(customDraw->nmcd.dwItemSpec & 1)
          {
            customDraw->clrTextBk = LISTVIEW_COLOR_ODDLINES;
            lResult = CDRF_NEWFONT;
          }

          client = ClientsList::mInstance.getClient(customDraw->nmcd.dwItemSpec);
          if(!client->isValid())
          {
            SelectObject(customDraw->nmcd.hdc, mFixedStrikedFont);
            lResult = CDRF_NEWFONT;
          }
          else if(PrefsManager::mInstance.mAnalyseLastFrameDuration && PrefsManager::mInstance.mCheckForActivity && !client->isRunning())
          {
            customDraw->clrText = RGB(200, 0, 0);
            lResult = CDRF_NEWFONT;
          }

          // We have to do tricky things to change the color of the selected item, but it seems that there is no other way to do it
          // (OWNER_DRAW could do the job, but it requires more code than this method)
          // 1. Change the background color
          // 2. Un-Highlight the item
          // 3. Ask the item to be notified AFTER the drawing operations
          // 4. Re-Highlight the item
          if(ListView_GetItemState(mHViewControl, customDraw->nmcd.dwItemSpec, LVIS_SELECTED) != 0)
          {
            if(GetFocus()== mHViewControl)
              customDraw->clrTextBk = LISTVIEW_COLOR_FOCUS;
            else
              customDraw->clrTextBk = LISTVIEW_COLOR_NORMAL;
            ListView_SetItemState(mHViewControl, customDraw->nmcd.dwItemSpec, 0, LVIS_SELECTED);
            lResult = lResult | CDRF_NOTIFYPOSTPAINT;
          }
          break;

        case CDDS_ITEMPOSTPAINT:
          ListView_SetItemState(mHViewControl, customDraw->nmcd.dwItemSpec, 0xFF, LVIS_SELECTED);
          break;
      }

      SetWindowLong(mHDialog, DWL_MSGRESULT, lResult);
      return TRUE;
  }

  return FALSE;
}


/**
 * A client has been reloaded.
 *
 * @param clientIndex The index of this client.
**/
void MultiView::reloadDone(unsigned int clientIndex)
{
  FahClient *client;
  char displayed[256];
  unsigned int length, pos;

  client = ClientsList::mInstance.getClient(clientIndex);

  if(client->isValid())
  {
    if(client->getWUProgress() == 100)
      wsprintf(displayed, "OK  %s", client->getClientName());
    else
      wsprintf(displayed, "%02d%% %s", client->getWUProgress(), client->getClientName());

    if(PrefsManager::mInstance.mComputeETA && (PrefsManager::mInstance.mCheckForActivity == false || client->isRunning()))
    {
      // Align ETA's
      length = lstrlen(client->getClientName());
      pos = length + 4;
      length = mLongestNameLength - length + 2;
      while(length--)
        displayed[pos++] = ' ';
      displayed[pos] = '\0';

      lstrcat(displayed, client->getWUETA());
    }
  }
  else
    wsprintf(displayed, "00%% %s", client->getClientName());

  UIListView::setItemText(mHViewControl, clientIndex, 0, displayed);

  if(clientIndex == mCurrentClient)
    MainView::displayInfo();

}


/**
 * Perform a reload.
**/
void MultiView::reloadRequested(void)
{
  Worker::mInstance->addJob(mHDialog, Worker::JOB_LOADALLCLIENTS, (WPARAM)NULL, (LPARAM)NULL);
}
