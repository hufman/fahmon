#ifndef _MULTIVIEW_H
#define _MULTIVIEW_H

#include "fahMon.h"
#include "mainView.h"


class MultiView : public MainView
{
protected:
  bool mInitializing;
  unsigned int mLongestNameLength;
  HFONT mFixedFont;
  HFONT mFixedStrikedFont;

public:
  MultiView(HWND hDialog, unsigned int currentClient);
  ~MultiView(void);

  virtual void init(unsigned int currentClient, bool errorMode);
  virtual void reloadRequested(void);
  virtual void reloadDone(unsigned int clientIndex);
  virtual BOOL onNotify(NMHDR* information);
};


#endif
