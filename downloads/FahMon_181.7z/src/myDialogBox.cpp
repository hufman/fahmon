/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "MyDialogBox.h"
#include "UIWindow.h"
#include "prefsmanager.h"
#include "tools.h"


/**
 * Constructor
**/
MyDialogBox::MyDialogBox(HINSTANCE hInstance, HWND hParentDlg, unsigned int dialogID) : mHDlg(NULL),
                                                                                        mHDlgParent(hParentDlg),
                                                                                        mDlgId(dialogID),
                                                                                        mHInstance(hInstance)
{
  // --
}


/**
 * Destructor
**/
MyDialogBox::~MyDialogBox(void)
{
  if(mHDlg != NULL)
  {
    DestroyWindow(mHDlg);
    mHDlg = NULL;
  }
}


/**
 * Display another dialog box in top of the current one, which is then disabled
**/
void MyDialogBox::showChildDialog(MyDialogBox* child, void* param) const
{
  UIWindow::disable(mHDlg);
  child->showModal(param);
  UIWindow::enable(mHDlg);

  // This is needed for our main dialog to regain the focus, Windows won't give it back otherwise
  SetForegroundWindow(mHDlg);
}


/**
 * Display the dialog box
**/
int MyDialogBox::showModal(void* param, bool visible, HACCEL accelerators)
{
  MSG msg;

  // If the dialog has never been displayed, create it
  if(mHDlg == NULL)
  {
    mHDlg = CreateDialog(mHInstance, MAKEINTRESOURCE(mDlgId), mHDlgParent, sDialogProc);
    SetWindowLong(mHDlg, GWL_USERDATA, (LONG)this);
  }

  // We have to explicitly send this message, because the one sent by CreateDialog() is ignored
  // (GWL_USERDATA has not already been initialized so there is no DialogProc() defined)
  SendMessage(mHDlg, WM_INITDIALOG, 0, (LPARAM)param);

  // Display the dialog box if needed
  if(visible)
    ShowWindow(mHDlg, SW_SHOW);

  while(GetMessage(&msg, NULL, 0, 0))
  {
    if(!accelerators || !TranslateAccelerator(mHDlg, accelerators, &msg))
    {
      if(!IsDialogMessage(mHDlg, &msg))
      {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
      }
    }
  }

  // The loop exits only if we get a WM_QUIT, in this case wParam is the exit code
  return msg.wParam;
}


/**
 * Static dialog procedure
 * Get the handler thanks to GWL_USERDATA and dispatch the message
**/
BOOL CALLBACK MyDialogBox::sDialogProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  MyDialogBox* _this = (MyDialogBox*)GetWindowLong(hDlg, GWL_USERDATA);

  if(_this != NULL)
    return _this->dialogProc(uMsg, wParam, lParam);

  return FALSE;
}


/**
 * Base Dialog Procedure
**/
BOOL MyDialogBox::dialogProc(UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch(msg)
  {
    case WM_NOTIFY:
      return onNotify(wParam, (NMHDR*)lParam);

    case WM_COMMAND:
      return onCommand(HIWORD(wParam), LOWORD(wParam), (HWND)lParam);

    case WM_CTLCOLORSTATIC:
      return onCtlColorStatic((HDC)wParam, (HWND)lParam);

    case WM_SIZE:
      return onSize(wParam, LOWORD(lParam), HIWORD(lParam));

    case WM_INITDIALOG:
      return onInitDialog((void*)lParam);

    case WM_CLOSE:
      return onClose();  
  }

  return FALSE;
}


/**
 * Close the dialog box
**/
void MyDialogBox::endDialog(unsigned int exitCode) const
{
  ShowWindow(mHDlg, SW_HIDE);
  PostMessage(mHDlg, WM_QUIT, (WPARAM)exitCode, (LPARAM)0);
}


/**
 * Display an error message
**/
int MyDialogBox::errorMessageBox(const char* text) const
{
  return MessageBox(mHDlg, text, PrefsManager::mInstance.mAppName, MB_OK | MB_ICONERROR);
}


/**
 * Display a warning message
**/
int MyDialogBox::warningMessageBox(const char* text) const
{
  return MessageBox(mHDlg, text, PrefsManager::mInstance.mAppName, MB_OK | MB_ICONWARNING);
}


/**
 * Ask the use to answer yes or no to a question
**/
int MyDialogBox::questionMessageBox(const char* text) const
{
  return MessageBox(mHDlg, text, PrefsManager::mInstance.mAppName, MB_YESNO | MB_ICONQUESTION);
}


/**
 * Set the big and small icons to the given ones.
 *
 * WinXP icons are used only if the program is running on this OS.
**/
void MyDialogBox::setIcons(unsigned int smallIconId, unsigned int bigIconId, unsigned int smallIconIdWinXP, unsigned int bigIconIdWinXP) const
{
  if(Tools::isRunningOnXP())
  {
    SendMessage(mHDlg, WM_SETICON, (WPARAM)ICON_SMALL, (LPARAM)LoadIcon(mHInstance, MAKEINTRESOURCE(smallIconIdWinXP)));
    SendMessage(mHDlg, WM_SETICON, (WPARAM)ICON_BIG, (LPARAM)LoadIcon(mHInstance, MAKEINTRESOURCE(bigIconIdWinXP)));
  }
  else
  {
    SendMessage(mHDlg, WM_SETICON, (WPARAM)ICON_SMALL, (LPARAM)LoadIcon(mHInstance, MAKEINTRESOURCE(smallIconId)));
    SendMessage(mHDlg, WM_SETICON, (WPARAM)ICON_BIG, (LPARAM)LoadIcon(mHInstance, MAKEINTRESOURCE(bigIconId)));
  }
}
