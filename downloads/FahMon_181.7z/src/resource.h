//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FahMon.rc
//
#define ID_PRE_BTN_APPLY                3
#define ID_DLG_MAIN                     101
#define ID_DLG_PREFS                    112
#define ID_DLG_ABOUT                    113
#define ID_ICO_CLIENTXP                 125
#define ID_ICO_CLIENTOTHER              126
#define ID_ICO_DIALOG                   127
#define ID_ICO_INFO                     128
#define ID_MEN_MAIN                     130
#define ID_ACC_MAIN                     131
#define ID_DLG_CLIENTS                  132
#define ID_DLG_BENCHMARKS               133
#define ID_MAI_LBL_PROJECTVALUE         1000
#define ID_MAI_LBL_DOWNLOADEDVALUE      1001
#define ID_MAI_LBL_DUETIMEVALUE         1002
#define ID_MAI_LBL_CREDITVALUE          1003
#define ID_MAI_TXT_LOG                  1007
#define ID_MAI_PRG_PROGRESS             1008
#define ID_MAI_LBL_PROGRESS             1010
#define ID_MAI_LBL_DUETIME              1011
#define ID_MAI_LBL_CORENAME             1016
#define ID_MAI_GRP_WUINFO               1022
#define ID_MAI_LBL_PROJECT              1023
#define ID_MAI_LBL_CREDIT               1024
#define ID_MAI_LBL_DOWNLOADED           1025
#define ID_MAI_LBL_ERROR                1026
#define ID_MAI_LST_CLIENTS              1028
#define ID_MAI_LST_CLIENTSMULTI         1031
#define ID_PRE_CHK_AUTORELOAD           1034
#define ID_PRE_BTN_OK                   1035
#define ID_PRE_BTN_CANCEL               1036
#define ID_PRE_SPI_AUTORELOAD           1037
#define ID_PRE_TXT_AUTORELOAD           1038
#define ID_PRE_TXT_HTTPPROXYADDRESS     1039
#define ID_PRE_CHK_MINIMIZETOTRAY       1040
#define ID_PRE_RAD_LIST                 1041
#define ID_PRE_RAD_TABS                 1042
#define ID_ABO_BTN_OK                   1042
#define ID_PRE_CHK_HTTPPROXYENABLED     1043
#define ID_ABO_LBL_VERSION              1044
#define ID_PRE_TXT_HTTPPROXYPORT        1044
#define ID_ABO_LBL_URL                  1045
#define ID_PRE_RAD_MULTI                1045
#define ID_MAI_TAB_CLIENTS              1046
#define ID_PRE_CHK_LOGHSCROLL           1046
#define ID_PRE_CHK_THERECANBEONLYONE    1047
#define ID_PRE_CHK_COMPUTEETA           1048
#define ID_MAI_LBL_STATUS               1049
#define ID_PRE_CHK_DETECTINACTIVECLIENTS 1049
#define ID_PRE_CHK_AUTOUPDATE           1050
#define ID_MAI_SCR_GRIP                 1051
#define ID_MAI_ICO_INFO                 1052
#define ID_CLI_LST_KNOWNCLIENTS         1053
#define ID_CLI_BTN_NEW                  1054
#define ID_CLI_BTN_REMOVE               1055
#define ID_CLI_TXT_NAME                 1056
#define ID_CLI_TXT_LOCATION             1057
#define ID_CLI_BTN_BROWSE               1058
#define ID_CLI_BTN_APPLY                1059
#define ID_CLI_BTN_UP                   1060
#define ID_CLI_BTN_DOWN                 1061
#define ID_CLI_LBL_STATUS               1062
#define ID_BEN_CBB_PROJECTS             1063
#define ID_BEN_TXT_DESCRIPTION          1064
#define ID_BEN_BTN_CLOSE                1065
#define ID_PRE_CHK_ANALYSELASTFRAME     1066
#define ID_BEN_LBL_SEEBENCHMARKS        1067
#define ID_CLI_LBL_NAME                 1068
#define ID_CLI_LBL_LOCATION             1069
#define ID_CLI_GRP_CLIENT               1070
#define ID_PRE_CBB_ETAFORMATS           1071
#define ID_PRE_LBL_ETAFORMATS           1072
#define ID_MIT_ABOUT                    40003
#define ID_MIT_PREFS                    40004
#define ID_MIT_VIEWSTATS                40005
#define ID_MIT_RELOADCLIENT             40006
#define ID_MIT_UPDATEDATABASE           40007
#define ID_MIT_QUIT                     40008
#define ID_MIT_CONFCLIENTS              40009
#define ID_MIT_VIEWBENCHMARKS           40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1073
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
