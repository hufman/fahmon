/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "systrayManager.h"
#include "dlgMessages.h"


/**
 * Constructor
**/
SystrayManager::SystrayManager(HWND hDlg, unsigned int id, HICON hIcon)
{
  mIsInSystray = false;

  mIconData.cbSize = sizeof(NOTIFYICONDATA);
  mIconData.hWnd = hDlg;
  mIconData.uID = id;
  mIconData.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
  mIconData.uCallbackMessage = WM_SYSTRAYNOTIFICATION;
  mIconData.hIcon = hIcon;
  wsprintf(mIconData.szTip, "No tooltip was defined");
}


/**
 * Change the text of the tooltip
**/
void SystrayManager::setTooltip(const char* tooltip)
{
  // Copy the new tooltip
  CopyMemory(mIconData.szTip, tooltip, 64);

  // If our icon is already in the systray, notify Windows to modify its tooltip
  if(mIsInSystray)
    Shell_NotifyIcon(NIM_MODIFY, &mIconData);
}


/**
 * Minimize the dialog box to the systray
**/
void SystrayManager::minimize(void)
{
  // If needed, add the icon to the systray and hide the dialog box
  if(!mIsInSystray)
  {
    mIsInSystray = true;
    Shell_NotifyIcon(NIM_ADD, &mIconData);
    ShowWindow(mIconData.hWnd, SW_HIDE);
  }
}


/**
 * Restore the dialog box
**/
void SystrayManager::restore(void)
{
  // If needed, remove the icon from the systray, show the dialog box and bring it on top
  if(mIsInSystray)
  {
    mIsInSystray = false;
    Shell_NotifyIcon(NIM_DELETE, &mIconData);
    ShowWindow(mIconData.hWnd, SW_SHOWNORMAL);
    SetForegroundWindow(mIconData.hWnd);
  }
}
