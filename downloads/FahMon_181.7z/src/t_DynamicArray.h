/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _TDYNAMICARRAY_H
#define _TDYNAMICARRAY_H


template <class DAItem>
class TDynamicArray
{
protected:
  unsigned int mNbItems;
  unsigned int mNbMaxItems;
  const unsigned int mCapacityIncrement;
  DAItem **mArray;

public:
  TDynamicArray(void);
  TDynamicArray(unsigned int initialCapacity);
  ~TDynamicArray(void);

  void addItem(DAItem *item);
  void clear(void);

  unsigned int getNbItems(void) const {return mNbItems;}
  DAItem* getItem(unsigned int index) const {assert(index < mNbItems); return mArray[index];}
};


/**
 * Constructor.
**/
template <class DAItem>
TDynamicArray<DAItem>::TDynamicArray(void) : mCapacityIncrement(10)
{
  mNbItems    = 0;
  mNbMaxItems = mCapacityIncrement;
  mArray      = new DAItem*[mNbMaxItems];
}


/**
 * Constructor.
**/
template <class DAItem>
TDynamicArray<DAItem>::TDynamicArray(unsigned int initialCapacity) : mCapacityIncrement(10)
{
  mNbItems    = 0;
  mNbMaxItems = initialCapacity;
  mArray      = new DAItem*[mNbMaxItems];
}


/**
 * Destructor.
**/
template <class DAItem>
TDynamicArray<DAItem>::~TDynamicArray(void)
{
  unsigned int i;

  for(i=0; i<mNbItems; ++i)
    delete mArray[i];
  delete[] mArray;
}


/**
 * Add the given item to the array.
**/
template <class DAItem>
void TDynamicArray<DAItem>::addItem(DAItem *item)
{
  DAItem **newArray;

  // Should we increase the size of the array?
  if(mNbItems == mNbMaxItems)
  {
    mNbMaxItems += mCapacityIncrement;
    newArray = new DAItem*[mNbMaxItems];
    CopyMemory(newArray, mArray, mNbItems * sizeof(DAItem*));
    delete[] mArray;
    mArray = newArray;
  }

  // We are sure that there is now enough space for our item
  mArray[mNbItems] = item;
  ++mNbItems;
}


/**
 * Clear the array by freeing all its elements.
**/
template <class DAItem>
void TDynamicArray<DAItem>::clear(void)
{
  while(mNbItems != 0)
  {
    delete mArray[mNbItems-1];
    --mNbItems;
  }
}


#endif
