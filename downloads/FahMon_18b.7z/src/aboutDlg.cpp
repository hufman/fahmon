/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "AboutDlg.h"
#include "resource.h"
#include "prefsmanager.h"
#include "tools.h"

#include "UIText.h"


#define IDC_HAND (MAKEINTRESOURCE(32649))


/**
 * Constructor
**/
AboutDlg::AboutDlg(HINSTANCE hInstance, HWND parentDlg) : MyDialogBox(hInstance, parentDlg, ID_DLG_ABOUT),
                                                          mHasBeenInitialized(false),
                                                          mUnderlinedFont(NULL),
                                                          mBoldFont(NULL)
{
}


/**
 * Destructor
**/
AboutDlg::~AboutDlg(void)
{
  if(mHasBeenInitialized == true)
  {
    DeleteObject(mUnderlinedFont);
    DeleteObject(mBoldFont);
  }
}


/**
 * Initialize the dialog box
**/
inline void AboutDlg::initialize(void)
{
  LOGFONT logFont;
  char buffer[64];

  // Bind the controls
  mHLblUrl     = getItem(ID_ABO_LBL_URL);
  mHLblVersion = getItem(ID_ABO_LBL_VERSION);

  // Display the up-to-date version number
  UIText::setText(mHLblVersion, PrefsManager::mInstance.mAppNameVersion);

  // Set the title and the icon of the dialog box
  wsprintf(buffer, "%s  /  About", PrefsManager::mInstance.mAppNameVersion);
  setTitle(buffer);
  setSmallIcon(ID_ICO_DIALOG);

  // Underline the url
  mUnderlinedFont = UIText::getFont(mHLblUrl);
  GetObject(mUnderlinedFont, sizeof(logFont), &logFont);
  logFont.lfUnderline = TRUE;
  mUnderlinedFont = CreateFontIndirect(&logFont);
  UIText::setFont(mHLblUrl, mUnderlinedFont);

  // Bold the version
  mBoldFont = UIText::getFont(mHLblVersion);
  GetObject(mBoldFont, sizeof(logFont), &logFont);
  logFont.lfWeight = FW_BOLD;
  mBoldFont = CreateFontIndirect(&logFont);
  UIText::setFont(mHLblVersion, mBoldFont);
}


/**
 * DialogProc that received windows events
**/
BOOL AboutDlg::dialogProc(UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch(msg)
  {
    case WM_MOUSEMOVE:
      return onMouseMove(wParam, LOWORD(lParam), HIWORD(lParam));

    case WM_LBUTTONDOWN:
      return onLButtonDown(wParam, LOWORD(lParam), HIWORD(lParam));
  }

  return MyDialogBox::dialogProc(msg, wParam, lParam);
}


/**
 * Manager the WM_INITDIALOG message
**/
BOOL AboutDlg::onInitDialog(void)
{
  if(!mHasBeenInitialized)
  {
    initialize();
    mHasBeenInitialized = true;
  }

  mMouseIsOverURL = false;
  SetFocus(getItem(ID_ABO_BTN_OK));

  return FALSE;
}


/**
 * Manage the WM_CLOSE message
**/
BOOL AboutDlg::onClose(void)
{
  // Restore the default cursor (hey, one never knows, the dialog box could exit with the hand cursor)
  SetClassLong(mHDlg, GCL_HCURSOR, (long)LoadCursor(NULL, IDC_ARROW));

  return MyDialogBox::onClose();
}


/**
 * Manage the WM_COMMAND message
**/
BOOL AboutDlg::onCommand(unsigned int notifyCode, unsigned int id, HWND hControl)
{
  if(id == ID_ABO_BTN_OK)
    onClose();

  return FALSE;
}


/**
 * Manage the WM_CTLCOLORSTATIC message
**/
BOOL AboutDlg::onCtlColorStatic(HDC hDc, HWND hWnd)
{
  if(hWnd == mHLblUrl)
  {
    if(mMouseIsOverURL)
      SetTextColor(hDc, RGB(128, 0, 128));
    else
      SetTextColor(hDc, RGB(0, 0, 255));
    
    SetBkColor(hDc, GetSysColor(COLOR_BTNFACE));
    return (BOOL)GetSysColorBrush(COLOR_BTNFACE);
  }

  return FALSE;
}


/**
 * Manage the WM_MOUSEMOVE message
**/
inline BOOL AboutDlg::onMouseMove(unsigned int fwKeys, unsigned int xPos, unsigned int yPos)
{
  RECT rect;
  bool overURL;
  POINT pos = {xPos, yPos};

  // Convert coordinates to the same (screen) system
  ClientToScreen(mHDlg, &pos);
  GetWindowRect(mHLblUrl, &rect);

  // Is the mouse over the URL?
  overURL = (PtInRect(&rect, pos) == TRUE) ? true : false;

  // Was that the case the last time?
  if(overURL != mMouseIsOverURL)
  {
    mMouseIsOverURL = overURL;
    InvalidateRect(mHLblUrl, NULL, TRUE);

    // Change the cursor. SetCursor() is not used because its changes are immediately
    // overwritten by the class' default cursor
    if(mMouseIsOverURL)
      SetClassLong(mHDlg, GCL_HCURSOR, (long)LoadCursor(NULL, IDC_HAND));
    else
      SetClassLong(mHDlg, GCL_HCURSOR, (long)LoadCursor(NULL, IDC_ARROW));
  }

  return FALSE;
}


/**
 * Manage the WM_LBUTTONDOWN message
**/
inline BOOL AboutDlg::onLButtonDown(unsigned int fwKeys, unsigned int xPos, unsigned int yPos)
{
  if(mMouseIsOverURL)
    Tools::openURL("http://fahmon.silent-blade.org");

  return FALSE;
}
