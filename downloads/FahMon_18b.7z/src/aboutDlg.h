/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _ABOUTDLG_H
#define _ABOUTDLG_H

#include "fahMon.h"
#include "MyDialogBox.h"


class AboutDlg : public MyDialogBox
{
protected:
  // These attributes are used to bind the controls of the dialog box
  HWND mHLblUrl;
  HWND mHLblVersion;

  bool mMouseIsOverURL;
  bool mHasBeenInitialized;
  HFONT mUnderlinedFont;
  HFONT mBoldFont;

  BOOL dialogProc(UINT msg, WPARAM wParam, LPARAM lParam);
  BOOL onInitDialog(void);
  BOOL onCommand(unsigned int notifyCode, unsigned int id, HWND hControl);
  BOOL onCtlColorStatic(HDC hDc, HWND hWnd);
  BOOL onMouseMove(unsigned int fwKeys, unsigned int xPos, unsigned int yPos);
  BOOL onLButtonDown(unsigned int fwKeys, unsigned int xPos, unsigned int yPos);
  BOOL onClose(void);

  void initialize(void);

public:
  AboutDlg(HINSTANCE hInstance, HWND parentDlg);
  ~AboutDlg(void);
};


#endif
