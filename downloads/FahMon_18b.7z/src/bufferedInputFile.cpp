/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "bufferedInputFile.h"


/**
 * Constructor.
 * The method isValid() should always be called to know if the file could correctly be loaded in memory.
**/
BufferedInputFile::BufferedInputFile(const char* filename)
{
  HANDLE hFile;
  DWORD bytesRead;

  mFileIndex = 0;

  hFile = CreateFile(filename, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  if(hFile == INVALID_HANDLE_VALUE)
  {
    mValid           = false;
    mFileContent     = NULL;
    mFileContentSize = 0;
  }
  else
  {
    mValid           = true;
    mFileContentSize = GetFileSize(hFile, NULL);
    mFileContent     = new unsigned char[mFileContentSize];
    ReadFile(hFile, mFileContent, mFileContentSize, &bytesRead, NULL);
    CloseHandle(hFile);
  }
}


/**
 * Destructor.
**/
BufferedInputFile::~BufferedInputFile(void)
{
  if(mFileContent != NULL)
    delete[] mFileContent;
}


/**
 * Read some bytes from the file.
 *
 * @param dstPtr Pointer to buffer which will be filled with the bytes read.
 * @param bytesToRead Number of bytes to read from the file.
 *
 * @return true if the given number of bytes could read, false otherwise.
**/
bool BufferedInputFile::read(void* dstPtr, unsigned int bytesToRead)
{
  if(mFileIndex + bytesToRead > mFileContentSize)
    return false;

  CopyMemory(dstPtr, &mFileContent[mFileIndex], bytesToRead);
  mFileIndex += bytesToRead;
  return true;
}
