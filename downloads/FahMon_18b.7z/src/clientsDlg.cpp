/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "clientsDlg.h"
#include "shlobj.h"
#include "resource.h"
#include "prefsmanager.h"

#include "UI.h"
#include "UIListView.h"
#include "UIButton.h"
#include "UIEdit.h"
#include "UIText.h"


enum {COLUMN_NAME, COLUMN_LOCATION};


/**
 * Constructor
**/
ClientsDlg::ClientsDlg(HINSTANCE hInstance, HWND parentDlg) : MyDialogBox(hInstance, parentDlg, ID_DLG_CLIENTS), ResizableDlg(false)
{
  mHasBeenInitialized = false;
}


/**
 * Initialize the dialog box
**/
inline void ClientsDlg::initialize(void)
{
  unsigned int i;
  FahClient* client;
  char buffer[64];

  // Bind all the controls to their corresponding attributes
  mHLstClients  = getItem(ID_CLI_LST_KNOWNCLIENTS);
  mHTxtName     = getItem(ID_CLI_TXT_NAME);
  mHTxtLocation = getItem(ID_CLI_TXT_LOCATION);
  mHBtnNew      = getItem(ID_CLI_BTN_NEW);
  mHBtnRemove   = getItem(ID_CLI_BTN_REMOVE);
  mHBtnUp       = getItem(ID_CLI_BTN_UP);
  mHBtnDown     = getItem(ID_CLI_BTN_DOWN);
  mHBtnApply    = getItem(ID_CLI_BTN_APPLY);
  mHBtnBrowse   = getItem(ID_CLI_BTN_BROWSE);
  mHLblStatus   = getItem(ID_CLI_LBL_STATUS);
  mHLblName     = getItem(ID_CLI_LBL_NAME);
  mHLblLocation = getItem(ID_CLI_LBL_LOCATION);
  mHGrpClient   = getItem(ID_CLI_GRP_CLIENT);

  // Initialize the dialog box
  setSmallIcon(ID_ICO_DIALOG);
  wsprintf(buffer, "%s  /  Clients list", PrefsManager::mInstance.mAppNameVersion);
  setTitle(buffer);

  UIListView::enableFullRowSelection(mHLstClients);
  UIListView::addColumn(mHLstClients, COLUMN_NAME, "Name", PrefsManager::mInstance.mClientsDlgColumnNameWidth);
  UIListView::addColumn(mHLstClients, COLUMN_LOCATION, "Location", PrefsManager::mInstance.mClientsDlgColumnLocationWidth);

  // We need to fill the list only on the first initialization
  mNbKnownClients = ClientsList::mInstance.getSize();
  for(i=0; i<mNbKnownClients; ++i)
  {
    client = ClientsList::mInstance.getClient(i);
    UIListView::insertItemWithoutIcon(mHLstClients, i, COLUMN_NAME, client->getClientName());
    UIListView::setItemText(mHLstClients, i, COLUMN_LOCATION, client->getPath());
  }
  mCurrentSelection = 0;

  // Define the resize behavior
  setDlgResizable(DLG_CLIENTS_MIN_WIDTH, DLG_CLIENTS_MIN_HEIGHT);
  initResizableDlg(mHDlg, mHInstance, PrefsManager::mInstance.mClientsDlgWidth, PrefsManager::mInstance.mClientsDlgHeight);
}


/**
 * Enable/Disable up and down buttons, depending on the current selection and the number of entries
**/
void ClientsDlg::updateUpDownButtons(void)
{
  // Check the up button
  if(mCurrentSelection == 0)
    UIButton::disable(mHBtnUp);
  else
    UIButton::enable(mHBtnUp);

  // And the down one
  if(mNbKnownClients < 2 || mCurrentSelection == mNbKnownClients-1)
    UIButton::disable(mHBtnDown);
  else
    UIButton::enable(mHBtnDown);
}


/**
 * Enable/Disable the fields used for the client edition
**/
void ClientsDlg::setEditionAreaEnabled(bool enabled)
{
  UIEdit::setEnabled(mHTxtName, enabled);
  UIEdit::setEnabled(mHTxtLocation, enabled);
  UIButton::setEnabled(mHBtnBrowse, enabled);

  // Fields must be cleared if we disable them
  if(!enabled)
  {
    UIEdit::clear(mHTxtName);
    UIEdit::clear(mHTxtLocation);
    UIButton::disable(mHBtnApply);
  }
}


/**
 * Manage the WM_INITDIALOG message
**/
BOOL ClientsDlg::onInitDialog(void)
{
  if(mHasBeenInitialized == false)
  {
    initialize();
    mHasBeenInitialized = true;
  }

  if(mNbKnownClients == 0)
  {
    setEditionAreaEnabled(false);
    UIButton::disable(mHBtnRemove);
  }
  else
  {
    setEditionAreaEnabled(true);
    UIListView::setCurrentSelection(mHLstClients, 0);
  }

  updateUpDownButtons();
  UIButton::disable(mHBtnApply);
  updateDisplayedNumberOfClients();

  // Needed for calls to SHBrowseForFolder()
  CoInitialize(NULL);

  return FALSE;
}


/**
 * Manage the WM_CLOSE message
**/
BOOL ClientsDlg::onClose(void)
{
  CoUninitialize();
  saveClientsList();

  PrefsManager::mInstance.mClientsDlgColumnNameWidth     = UIListView::getColumnWidth(mHLstClients, COLUMN_NAME);
  PrefsManager::mInstance.mClientsDlgColumnLocationWidth = UIListView::getColumnWidth(mHLstClients, COLUMN_LOCATION);

  return MyDialogBox::onClose();
}


/**
 * Manage the WM_COMMAND message
**/
BOOL ClientsDlg::onCommand(unsigned int notifyCode, unsigned int id, HWND hControl)
{
  if(notifyCode == EN_CHANGE)
  {
    // The two textfields enable the apply button, so we don't need to check which one has generated an EN_CHANGE
    UIButton::enable(mHBtnApply);
  }
  else
  {
    switch(id)
    {
      case ID_CLI_BTN_BROWSE:
        browseFolders();
        break;

      case ID_CLI_BTN_NEW:
        newClient();
        break;

      case ID_CLI_BTN_REMOVE:
        removeClient();
        break;

      case ID_CLI_BTN_APPLY:
        applyChanges();
        break;

      case ID_CLI_BTN_UP:
        swapEntries(mCurrentSelection, mCurrentSelection-1);
        --mCurrentSelection;
        UIListView::setCurrentSelection(mHLstClients, mCurrentSelection);
        SetFocus(mHLstClients);
        break;

      case ID_CLI_BTN_DOWN:
        swapEntries(mCurrentSelection, mCurrentSelection+1);
        ++mCurrentSelection;
        UIListView::setCurrentSelection(mHLstClients, mCurrentSelection);
        SetFocus(mHLstClients);
        break;
    }
  }

  return FALSE;
}


/**
 * Manage the WM_SIZE
**/
BOOL ClientsDlg::onSize(unsigned int fwSizeType, unsigned int width, unsigned int height)
{
  sizeHasChanged(mHDlg, fwSizeType, width, height);
  return FALSE;
}


/**
 * Manage the WM_NOTIFY message
**/
BOOL ClientsDlg::onNotify(unsigned int id, NMHDR* information)
{
  NMLVCUSTOMDRAW *customDraw;
  LONG lResult;
  unsigned int selectedItem;

  switch(information->code)
  {
    case LVN_ITEMCHANGED:
      selectedItem = UIListView::getCurrentSelection(mHLstClients);
      if(selectedItem != mCurrentSelection)
      {
        mCurrentSelection = selectedItem;
        fillEditionArea();
        updateUpDownButtons();
        UIButton::enable(mHBtnRemove);
      }
      break;

    case NM_CUSTOMDRAW:
      customDraw = (NMLVCUSTOMDRAW*)information;

      switch(customDraw->nmcd.dwDrawStage)
      {
        case CDDS_PREPAINT:
          lResult = CDRF_NOTIFYITEMDRAW;
          break;

        case CDDS_ITEMPREPAINT:
          lResult = CDRF_DODEFAULT;

          // Darken every odd line
          if(customDraw->nmcd.dwItemSpec & 1)
          {
            customDraw->clrTextBk = LISTVIEW_COLOR_ODDLINES;
            lResult = CDRF_NEWFONT;
          }

          // We have to do tricky things to change the color of the selected item, but it seems that there is no other way to do it
          // (OWNER_DRAW could do the job, but it requires more code than this method)
          // 1. Change the background color
          // 2. Un-Highlight the item
          // 3. Ask the item to be notified AFTER the drawing operations
          // 4. Re-Highlight the item
          if(ListView_GetItemState(mHLstClients, customDraw->nmcd.dwItemSpec, LVIS_SELECTED) != 0)
          {
            if(GetFocus()== mHLstClients)
              customDraw->clrTextBk = LISTVIEW_COLOR_FOCUS;
            else
              customDraw->clrTextBk = LISTVIEW_COLOR_NORMAL;
            ListView_SetItemState(mHLstClients, customDraw->nmcd.dwItemSpec, 0, LVIS_SELECTED);
            lResult = lResult | CDRF_NOTIFYPOSTPAINT;
          }
          break;

        case CDDS_ITEMPOSTPAINT:
          ListView_SetItemState(mHLstClients, customDraw->nmcd.dwItemSpec, 0xFF, LVIS_SELECTED);
          break;
      }

      SetWindowLong(mHDlg, DWL_MSGRESULT, lResult);
      return TRUE;

    case LVN_KEYDOWN:
      if(((LPNMLVKEYDOWN)information)->wVKey == VK_DELETE)
        removeClient();
      break;

    // Force the current selection to keep the focus
    case NM_CLICK:
    case NM_DBLCLK:
    case NM_RCLICK:
    case NM_RDBLCLK:
      UIListView::setCurrentSelection(mHLstClients, mCurrentSelection);
      break;
  }

  return FALSE;
}


/**
 * Display a dialog box that allows the user to select a folder.
 * The text area is filled with the selection.
**/
inline void ClientsDlg::browseFolders(void)
{
  BROWSEINFO browseInfo;
  LPITEMIDLIST idl;
  char selectedPath[MAX_PATH];

  browseInfo.hwndOwner = mHDlg;
  browseInfo.pidlRoot = NULL;
  browseInfo.pszDisplayName = selectedPath;
  browseInfo.lpszTitle = "Please select the folder in which the client is installed:";
  browseInfo.ulFlags = 0;
  browseInfo.lpfn = NULL;
  browseInfo.lParam = 0;

  idl = SHBrowseForFolder(&browseInfo);
  if(idl != NULL)
  {
    SHGetPathFromIDList(idl, selectedPath);
    SetWindowText(mHTxtLocation, selectedPath);
    CoTaskMemFree(idl);
  }
}


/**
 * Insert a new client in the list
**/
inline void ClientsDlg::newClient(void)
{
  // Insert the entry
  UIListView::insertItemWithoutIcon(mHLstClients, mNbKnownClients, COLUMN_NAME, "New Client");
  UIEdit::setText(mHTxtName, "New Client");

  // Set it as the current selection
  mCurrentSelection = mNbKnownClients;
  UIListView::setCurrentSelection(mHLstClients, mCurrentSelection);
  ++mNbKnownClients;
  updateDisplayedNumberOfClients();

  // Enable the edition of this client and focus the name text area
  setEditionAreaEnabled(TRUE);
  SetFocus(mHTxtName);
  UIEdit::selectText(mHTxtName);

  // We know there is at least a client in the list, so remove/up/down buttons can be used
  updateUpDownButtons();
}


/**
 * Remove the currently selected client
**/
inline void ClientsDlg::removeClient(void)
{
  unsigned int oldSelection;

  // We remove a client only if there is at least one and the user confirms he really want to delete it
  if(mCurrentSelection < mNbKnownClients && questionMessageBox("Do you really want to remove this client?") == IDYES)
  {
    // The deletion changes the value of mCurrentSelection, so we have to save it
    oldSelection = mCurrentSelection;
    UIListView::deleteItem(mHLstClients, mCurrentSelection);
    --mNbKnownClients;
    updateDisplayedNumberOfClients();

    // If there are no more defined clients, disable fields
    if(mNbKnownClients == 0)
    {
      setEditionAreaEnabled(FALSE);
      UIButton::disable(mHBtnRemove);
    }
    else
    {
      // The selected item remains the same if it is possible, if not select the last one
      if(oldSelection < mNbKnownClients)
        mCurrentSelection = oldSelection;
      else
        mCurrentSelection = mNbKnownClients - 1;
      UIListView::setCurrentSelection(mHLstClients, mCurrentSelection);
      SetFocus(mHLstClients);

      // This is needed to correctly re-color each row
      ListView_RedrawItems(mHLstClients, 0, mNbKnownClients-1);
    }

    updateUpDownButtons();
  }
}


/**
 * Change the parameters of the currently selected client
**/
inline void ClientsDlg::applyChanges(void)
{
  char bufferName[CLIENT_NAME_MAX_LENGTH];
  char bufferPath[PATH_MAX_LENGTH];

  // Fill the currently selected item with the values of the two text fields
  UIEdit::getText(mHTxtName, bufferName, CLIENT_NAME_MAX_LENGTH);
  UIListView::setItemText(mHLstClients, mCurrentSelection, COLUMN_NAME, bufferName);

  UIEdit::getText(mHTxtLocation, bufferPath, PATH_MAX_LENGTH);
  UIListView::setItemText(mHLstClients, mCurrentSelection, COLUMN_LOCATION, bufferPath);

  // Apply button can no longer be used until fields are changed again
  UIButton::disable(mHBtnApply);
}


/**
 * Fill the edition fields with the currently selected client.
**/
inline void ClientsDlg::fillEditionArea(void)
{
  char bufferName[CLIENT_NAME_MAX_LENGTH];
  char bufferPath[PATH_MAX_LENGTH];

  // First retrieve the name
  UIListView::getItemText(mHLstClients, mCurrentSelection, COLUMN_NAME, bufferName, CLIENT_NAME_MAX_LENGTH);
  UIEdit::setText(mHTxtName, bufferName);

  // And then the location
  UIListView::getItemText(mHLstClients, mCurrentSelection, COLUMN_LOCATION, bufferPath, PATH_MAX_LENGTH);
  UIEdit::setText(mHTxtLocation, bufferPath);

  // Apply button can no longer be clicked
  UIButton::disable(mHBtnApply);
}


/**
 * Swap the two given entries
**/
void ClientsDlg::swapEntries(unsigned int entryIndex1, unsigned int entryIndex2)
{
  char entryName1[CLIENT_NAME_MAX_LENGTH], entryLocation1[PATH_MAX_LENGTH];
  char entryName2[CLIENT_NAME_MAX_LENGTH], entryLocation2[PATH_MAX_LENGTH];
  
  // Retrieve information about the first entry
  UIListView::getItemText(mHLstClients, entryIndex1, COLUMN_NAME, entryName1, CLIENT_NAME_MAX_LENGTH);
  UIListView::getItemText(mHLstClients, entryIndex1, COLUMN_LOCATION, entryLocation1, PATH_MAX_LENGTH);

  // Retrieve information about the second entry
  UIListView::getItemText(mHLstClients, entryIndex2, COLUMN_NAME, entryName2, CLIENT_NAME_MAX_LENGTH);
  UIListView::getItemText(mHLstClients, entryIndex2, COLUMN_LOCATION, entryLocation2, PATH_MAX_LENGTH);

  UIListView::disableRedraw(mHLstClients);

  // Set the first entry to the information of the second one
  UIListView::setItemText(mHLstClients, entryIndex1, COLUMN_NAME, entryName2);
  UIListView::setItemText(mHLstClients, entryIndex1, COLUMN_LOCATION, entryLocation2);

  // "Et vice et versa..."
  UIListView::setItemText(mHLstClients, entryIndex2, COLUMN_NAME, entryName1);
  UIListView::setItemText(mHLstClients, entryIndex2, COLUMN_LOCATION, entryLocation1);

  UIListView::enableRedraw(mHLstClients);
}


/**
 * Change the displayed number of client in the status bar
**/
void ClientsDlg::updateDisplayedNumberOfClients(void)
{
  char buffer[64];

  if(mNbKnownClients == 0)
    UIText::setText(mHLblStatus, "No defined client.");
  else
  {
    wsprintf(buffer, "%u client(s).", mNbKnownClients);
    UIText::setText(mHLblStatus, buffer);
  }
}


/**
 * Replace the current list of clients with the current one.
**/
inline void ClientsDlg::saveClientsList(void)
{
  unsigned int i;
  char name[CLIENT_NAME_MAX_LENGTH], location[PATH_MAX_LENGTH];

  ClientsList::mInstance.clear();

  for(i=0; i<mNbKnownClients; ++i)
  {
    UIListView::getItemText(mHLstClients, i, COLUMN_NAME, name, CLIENT_NAME_MAX_LENGTH);
    UIListView::getItemText(mHLstClients, i, COLUMN_LOCATION, location, PATH_MAX_LENGTH);
    ClientsList::mInstance.addClient(name, location);
  }

  ClientsList::mInstance.saveToFile(FILE_CLIENTSLIST);
}


/**
 * Move and/or resize the controls
**/
void ClientsDlg::reflowControls(unsigned int clientAreaWidth, unsigned int clientAreaHeight) const
{
  unsigned int posX, posY;

  SetWindowPos(mHLblStatus, NULL, 10, clientAreaHeight - 20, clientAreaWidth - 20, 15, SWP_NOZORDER);
  SetWindowPos(mHGrpClient, NULL, 10, clientAreaHeight - 154, clientAreaWidth - 20, 124, SWP_NOZORDER);
  SetWindowPos(mHBtnApply, NULL, (clientAreaWidth - 90) / 2, clientAreaHeight - 64, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblLocation, NULL, 35, clientAreaHeight - 92, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblName, NULL, 35, clientAreaHeight - 124, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHTxtLocation, NULL, 93, clientAreaHeight - 95, clientAreaWidth - 163, 21, SWP_NOZORDER);
  SetWindowPos(mHTxtName, NULL, 93, clientAreaHeight - 128, clientAreaWidth/3, 21, SWP_NOZORDER);
  SetWindowPos(mHBtnBrowse, NULL, clientAreaWidth - 60, clientAreaHeight - 95, 0, 0, SWP_NOZORDER | SWP_NOSIZE);

  posX = (clientAreaWidth - 360) / 2;
  posY = clientAreaHeight - 189;

  SetWindowPos(mHBtnNew, NULL, posX, posY, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHBtnRemove, NULL, posX + 83, posY, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHBtnUp, NULL, posX + 220, posY, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHBtnDown, NULL, posX + 303, posY, 0, 0, SWP_NOZORDER | SWP_NOSIZE);

  SetWindowPos(mHLstClients, NULL, 0, 0, clientAreaWidth - 20, clientAreaHeight - 216, SWP_NOZORDER | SWP_NOMOVE);

  // Save the new size
  PrefsManager::mInstance.mClientsDlgWidth  = clientAreaWidth;
  PrefsManager::mInstance.mClientsDlgHeight = clientAreaHeight;
}
