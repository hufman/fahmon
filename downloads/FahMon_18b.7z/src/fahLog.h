/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _FAHLOG_H
#define _FAHLOG_H

#include "fahMon.h"


// A run:
//  For Gromacs, DGromacs and Amber cores, it is the time used to compute a complete percent
//  For Tinker core, it is the time used to compute a complete frame
class FahWURun
{
protected:
  bool mValid;
  unsigned int mRunNumber;   // Current frame or current percent
  unsigned int mRunDuration;
  unsigned int mElapsedTimeSinceThisRun;

public:
  FahWURun(void);

  void reset(void);

  bool isValid(void) const {return mValid;}
  void setValid(bool valid) {mValid = valid;}

  unsigned int getRunNumber(void) const {return mRunNumber;}
  void setRunNumber(unsigned int runNumber) {mRunNumber = runNumber;}

  unsigned int getRunDuration(void) const {return mRunDuration;}
  void setRunDuration(unsigned int runDuration) {mRunDuration = runDuration;}

  unsigned int getElapsedTimeSinceThisRun(void) const {return mElapsedTimeSinceThisRun;}
  void setElapsedTimeSinceThisRun(unsigned int elapsedTimeSinceThisRun) {mElapsedTimeSinceThisRun = elapsedTimeSinceThisRun;}
};


class FahLog
{
protected:
  char mPath[PATH_MAX_LENGTH];

  char* mLogContent;
  unsigned int mLogContentSize;
  unsigned int mElapsedTimeSinceLastWriteAccess;
  FahWURun mLastRunInformation;

  int findPreviousLine(unsigned int startPos);

public:
  FahLog(void);
  ~FahLog(void);

  void setPath(const char* path) {lstrcpyn(mPath, path, PATH_MAX_LENGTH);}
  void load(void);
  void analyzeLastRun(void);

  const char* getLogContent(void) const {return mLogContent;}
  const FahWURun* getLastRunInformation(void) const {return &mLastRunInformation;}
  unsigned int getElapsedTimeSinceLastWriteAccess(void) const {return mElapsedTimeSinceLastWriteAccess;}
};


#endif
