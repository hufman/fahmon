/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _FAHMON_CONSTANTS_H
#define _FAHMON_CONSTANTS_H

#define CHAR_LF 10
#define CHAR_CR 13


#define MAIN_GROUP_LABEL      "          Work Unit Information "
#define MAIN_GROUP_LABEL_SIZE 32

// How many maximum number of projects should we store?
#define PROJECTS_MAX_KNOWN_NUMBER 6000      // 6000 is sufficient for the moment

// How long can a path be?
#define PATH_MAX_LENGTH 256

// How long can a machine name be?
#define CLIENT_NAME_MAX_LENGTH 128

// The file which store the list of known clients
#define FILE_CLIENTSLIST "clients.cfg"
// The file which store the list of benchmarks
#define FILE_BENCHMARKS "benchmarks.dat"
// The file which store the preferences
#define FILE_PREFERENCES "prefs.dat"

// Colors used in ListView controls
#define LISTVIEW_COLOR_ODDLINES RGB(230, 230, 230)
#define LISTVIEW_COLOR_FOCUS RGB(141, 239, 180)
#define LISTVIEW_COLOR_NORMAL RGB(202, 239, 217)

// Size of the min dialog box
#define DLG_MAIN_FIXED_WIDTH 500
#define DLG_MAIN_MIN_HEIGHT  500

// Minimum size for the benchmarks dialog box
#define DLG_BENCHMARKS_MIN_WIDTH  320
#define DLG_BENCHMARKS_MIN_HEIGHT 320

// Minimum size for the clients dialog box
#define DLG_CLIENTS_MIN_WIDTH  440
#define DLG_CLIENTS_MIN_HEIGHT 415

// Default size of the columns of the ListView in the clients dialog box
#define DLG_CLIENTS_NAME_COL_WIDTH     150
#define DLG_CLIENTS_LOCATION_COL_WIDTH 260

#endif
