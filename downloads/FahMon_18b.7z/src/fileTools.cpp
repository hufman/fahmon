/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "fileTools.h"


/**
 * Return a buffer filled with the content of the given text file, NULL if an error occured.
 * filesize is filled with the number of bytes read and a NULL character is appended.
**/
char* FileTools::loadTextFile(const char* filename, unsigned int *filesize)
{
  HANDLE hFile;
  char* buffer;
  DWORD bytesRead;
  unsigned int length;

  // Open the file if it exists
  hFile = CreateFile(filename, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  if(hFile == INVALID_HANDLE_VALUE)
    return NULL;

  // Create a buffer to handle its data and fill it
  length = GetFileSize(hFile, NULL);
  buffer = new char[length + 1];
  ReadFile(hFile, buffer, length, &bytesRead, NULL);
  buffer[length] = '\0';
  CloseHandle(hFile);

  *filesize = length;

  return buffer;
}


/**
 * Convert a multi-line text from Linux file Format (LF) to Windows file format (CR-LF).
 *
 * @param text The text to transform.
 * @param textLength Number of characters in the text. Updated if the format is changed.
 *
 * @return NULL if no conversion was required, a new buffer oterwise.
 *
 * @remark In case of a conversion, the 'text' parameter is not freed, it is up to the caller to do it.
**/
char* FileTools::linuxFmtToWindowsFmt(const char* text, unsigned int *oldTextLength)
{
  unsigned int startPos, endPos, nbLines, i, posNewText, length, textLength;
  char* newText;

  textLength = *oldTextLength;

  // Check if this is a Linux format, if not, return immediately
  nbLines = 0;
  for(i=0; i<textLength; ++i)
  {
    switch(text[i])
    {
      // A CR character indicates that this text is already in the Windows file format.
      case CHAR_CR:
        return NULL;

      // Otherwise, count how many lines are present
      case CHAR_LF:
        ++nbLines;
        break;
    }
  }

  // If there is no line break, there is nothing to do
  if(nbLines == 0)
    return NULL;

  // Convert the text
  newText = new char[textLength + nbLines + 1];
  posNewText = 0;
  startPos = 0;
  endPos = 0;
  while(startPos < textLength)
  {
    while(endPos < textLength && text[endPos] != CHAR_LF)
      ++endPos;

    if(endPos != startPos)
    {
      length = endPos - startPos;
      CopyMemory(&newText[posNewText], &text[startPos], length);
      posNewText += length;
    }

    if(endPos != textLength)
    {
      newText[posNewText++] = CHAR_CR;
      newText[posNewText++] = CHAR_LF;
    }

    ++endPos;
    startPos = endPos;
  }
  newText[posNewText] = '\0';

  *oldTextLength += nbLines;
  return newText;
}


bool FileTools::getLastWriteAccess(const char* filename, FILETIME *fileTime)
{
  HANDLE hFile;

  hFile = CreateFile(filename, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  if(hFile == INVALID_HANDLE_VALUE)
    return false;

  GetFileTime(hFile, NULL, NULL, fileTime);
  CloseHandle(hFile);

  return true;
}

/*
bool FileTools::exists(const char* filename)
{
  HANDLE hFile;

  hFile = CreateFile(filename, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  if(hFile == INVALID_HANDLE_VALUE)
    return false;

  CloseHandle(hFile);
  return true;
}
*/