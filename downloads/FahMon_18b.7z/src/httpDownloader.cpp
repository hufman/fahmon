/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "httpDownloader.h"
#include <mmsystem.h>
#include "prefsmanager.h"


#define BUFFER_LENGTH 1024


const char* HTTPDownloader::mInitError    = "Could not initialize win32 sockets";
const char* HTTPDownloader::mSocketError  = "Could not create the socket";
const char* HTTPDownloader::mHostError    = "Could not resolve host name";
const char* HTTPDownloader::mConnectError = "Could not connect to the server";
const char* HTTPDownloader::mIOError      = "An I/O error occured while communicating with the server";


/**
 * Download a remote file accessible via HTTP protocol to a local file.
 * The PrefsManager is used to determine if a proxy should be used.
**/
const char* HTTPDownloader::download(const char* host, unsigned int port, const char* resource, BufferedOutputFile *outFile)
{
  WSADATA wsaData;
  SOCKET httpSocket;
  struct hostent *hostInfo;
  struct sockaddr_in server;
  const char* error;
  char buffer[BUFFER_LENGTH];
  char request[BUFFER_LENGTH];
  unsigned int receivedBytes;
  unsigned int receivedBytesGrandTotal;
  char status[BUFFER_LENGTH];
  DWORD startTime;
  DWORD elapsedTime;

  // Initalize win32 sockets
  if(WSAStartup(MAKEWORD(1, 1), &wsaData))
    return mInitError;

  // Format the request and decide which host and port to use, in regards to the HTTP proxy configuration
  if(PrefsManager::mInstance.mHTTPProxyEnabled)
  {
    wsprintf(request, "GET http://%s:%d/%s HTTP/1.0\nHost: %s\n\n", host, port, resource, host);
    host = PrefsManager::mInstance.mHTTPProxyAddress;
    port = PrefsManager::mInstance.mHTTPProxyPort;
  }
  else
    wsprintf(request, "GET /%s HTTP/1.0\nHost: %s\n\n", resource, host);

  // No error should occur
  error = NULL;

  // Create our socket
  if((httpSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == INVALID_SOCKET)
    error = mSocketError;
  else
  {
    // Resolve hostname
    if((hostInfo = gethostbyname(host)) == NULL)
      error = mHostError;
    else
    {
      // Connect to the server
      server.sin_family      = AF_INET;
      server.sin_port        = htons(port); 
      server.sin_addr.s_addr = *((unsigned long*)hostInfo->h_addr);

      if(connect(httpSocket, (struct sockaddr *)&server, sizeof(server)) == SOCKET_ERROR)
        error = mConnectError;
      else
      {
        // Send the request
        if(send(httpSocket, request, lstrlen(request), 0) == SOCKET_ERROR)
          error = mIOError;
        else
        {
          // Used for statistical reasons
          receivedBytesGrandTotal = 0;
          startTime               = timeGetTime();

          // Loop until no more data is available
          while((receivedBytes = recv(httpSocket, buffer, BUFFER_LENGTH, 0)) != 0)
          {
            receivedBytesGrandTotal += receivedBytes;
            elapsedTime = timeGetTime() - startTime;

            // Avoid division by zero when formatting status and send it to the observer
            if(elapsedTime == 0)
              wsprintf(status, "%u Kb", receivedBytesGrandTotal / 1024);
            else
              wsprintf(status, "%u Kb [%u Kb/s]", receivedBytesGrandTotal / 1024, (unsigned int)(receivedBytesGrandTotal  * 1000 / elapsedTime / 1024));
            sendStatusToObserver(status);

            // Save the data to the disk
            outFile->write(buffer, receivedBytes);
          }
        }
      }
    }

    // Close the socket
    shutdown(httpSocket, 0);
    closesocket(httpSocket);
  }

  // Clean up before leaving
  WSACleanup();

  return error;
}
