#include "listView.h"
#include "resource.h"
#include "worker.h"
#include "tools.h"

#include "UIListView.h"


/**
 * Constructor
**/
ListView::ListView(HINSTANCE hInstance, HWND hDialog, unsigned int currentClient) : MainView(hDialog, GetDlgItem(hDialog, ID_MAI_LST_CLIENTS), currentClient)
{
  unsigned int i, neededSizeX, neededSizeY;
  HICON hIcon;
  RECT clientBounds;
  DWORD idIcon;

  // Create the ImageList used for the ListView
  mHImgList = ImageList_Create(32, 32, ILC_COLOR32, 1, 1);

  // Load the correct icon, depending on the OS
  idIcon = Tools::isRunningOnXP() ? ID_ICO_CLIENTXP : ID_ICO_CLIENTOTHER;
  hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(idIcon));
  ImageList_AddIcon(mHImgList, hIcon); 
  DeleteObject(hIcon);
  ListView_SetImageList(mHViewControl, mHImgList, LVSIL_NORMAL);

  // Add an icon for each known client
  for(i=0; i<ClientsList::mInstance.getSize(); ++i)
    UIListView::insertItemWithIcon(mHViewControl, i, 0, 0, ClientsList::mInstance.getClient(i)->getClientName());

  // Compute the needed width for all the items
  ListView_GetViewRect(mHViewControl, &clientBounds);
  neededSizeX = clientBounds.right - clientBounds.left + 5;

  // The size must not exceed the width of the dialog box
  if(neededSizeX > 479)
  {
    neededSizeX = 479;
    neededSizeY = 77;
  }
  else
    neededSizeY = 59;

  // Finally, move and resize it so that it should be centered
  SetWindowPos(mHViewControl, NULL, (497 - neededSizeX)/2 - 1, (77 - neededSizeY)/2 + 10, neededSizeX, neededSizeY, SWP_NOZORDER);
}


/**
 * Destructor.
**/
ListView::~ListView(void)
{
  ImageList_Destroy(mHImgList);
  ListView_DeleteAllItems(mHViewControl);
}


/**
 * The view has been changed to tabs, so initialize what needs to be initialized.
 *
 * @param currentClient The currently selected client.
**/
void ListView::init(unsigned int currentClient, bool errorMode)
{
  mCurrentClient = currentClient;
  ShowWindow(mHViewControl, TRUE);
  UIListView::setCurrentSelection(mHViewControl, mCurrentClient);

  mErrorMode = errorMode;
  if(mErrorMode)
    switchToError();
  else
    switchToView();

  reloadRequested();

  // Give the correct position/size to items
  SetWindowPos(mHLblProject, NULL, 29, 140, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblProjectValue, NULL, 81, 140, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblCredit, NULL, 29, 175, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblCreditValue, NULL, 81, 175, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDownloaded, NULL, 236, 140, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDownloadedValue, NULL, 323, 140, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDueTime, NULL, 236, 175, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblDueTimeValue, NULL, 323, 175, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
  SetWindowPos(mHLblCoreName, NULL, 42, 110, 410, 20, SWP_NOZORDER);
  SetWindowPos(mHGrpWuInfo, NULL, 6, 93, 487, 121, SWP_NOZORDER);
  SetWindowPos(mHIcoInfo, mHGrpWuInfo, 19, 90, 20, 20, 0); 
}


/**
 * Manage the WM_NOTIFY message.
**/
BOOL ListView::onNotify(NMHDR* information)
{
  unsigned int selectedItem;

  if(information->idFrom == ID_MAI_LST_CLIENTS)
  {
    switch(information->code)
    {
      // If the selection has changed and is valid, then reload and display the corresponding information
      case LVN_ITEMCHANGED:
        selectedItem = SendMessage(mHViewControl, LVM_GETNEXTITEM, -1, LVNI_FOCUSED);
        if(selectedItem < ClientsList::mInstance.getSize() && selectedItem != mCurrentClient)
        {
          mCurrentClient = selectedItem;
          Worker::mInstance->addJob(mHDialog, Worker::JOB_LOADCLIENT, (WPARAM)ClientsList::mInstance.getClient(mCurrentClient), (LPARAM)mCurrentClient);
        }
        break;

      // Force the current selection to keep the focus
      case NM_CLICK:
      case NM_RCLICK:
      case NM_DBLCLK:
      case NM_RDBLCLK:
        UIListView::setCurrentSelection(mHViewControl, mCurrentClient);
        break;
    }
  }

  return FALSE;
}


/**
 * A client has been reloaded.
 *
 * @param clientIndex The index of this client.
**/
void ListView::reloadDone(unsigned int clientIndex)
{
  char buffer[256];
  FahClient *client;

  if(clientIndex == mCurrentClient)
  {
    MainView::displayInfo();

    client = ClientsList::mInstance.getClient(clientIndex);
    if(PrefsManager::mInstance.mComputeETA)
    {
      if(!client->isValid())
        CopyMemory(buffer, MAIN_GROUP_LABEL, MAIN_GROUP_LABEL_SIZE+1);
      else if(PrefsManager::mInstance.mCheckForActivity && !client->isRunning())
        wsprintf(buffer, "%s  /  Inactive ", MAIN_GROUP_LABEL);
      else
        wsprintf(buffer, "%s  /  %s ", MAIN_GROUP_LABEL, client->getWUETA());

      setGroupLabel(buffer);
    }
  }
}


/**
 * Perform a reload.
**/
void ListView::reloadRequested(void)
{
  if(mCurrentClient < ClientsList::mInstance.getSize())
    Worker::mInstance->addJob(mHDialog, Worker::JOB_LOADCLIENT, (WPARAM)ClientsList::mInstance.getClient(mCurrentClient), (LPARAM)mCurrentClient);
}
