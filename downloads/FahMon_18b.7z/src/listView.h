#ifndef _LISTVIEW_H
#define _LISTVIEW_H

#include "fahMon.h"
#include "mainView.h"
#include <commctrl.h>


class ListView : public MainView
{
protected:
  HIMAGELIST mHImgList;

public:
  ListView(HINSTANCE hInstance, HWND hDialog, unsigned int currentClient);
  ~ListView(void);

  virtual void init(unsigned int currentClient, bool errorMode);
  virtual void reloadRequested(void);
  virtual void reloadDone(unsigned int clientIndex);
  virtual BOOL onNotify(NMHDR* information);
};


#endif
