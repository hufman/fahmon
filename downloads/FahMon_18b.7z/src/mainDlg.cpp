/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "MainDlg.h"
#include <commctrl.h>
#include "UIEdit.h"
#include "dlgMessages.h"


#define STATUS_IDLE "Done"  // The text displayed in the status bar when FahMon is idle
#define TIMER_ID    1234    // Arbitrary value for the timer used for auto-reloading
#define SIZEGRIPW   17      // Width of the size grip
#define SIZEGRIPH   17      // Height ---------------


/**
 * Constructor
**/
MainDlg::MainDlg(HINSTANCE hInstance, bool startMinimized) : MyDialogBox(hInstance, NULL, ID_DLG_MAIN), ResizableDlg(true)
{
  mStartMinimized = startMinimized;
  mIsMinimized    = false;

  mCurrentView   = NULL;
  mTabsView      = NULL;
  mListView      = NULL;
  mMultiView     = NULL;
  mCurrentViewId = PrefsManager::MDV_ERROR;

  mTimerRunning             = false; 
  mShouldReloadAfterRestore = false;
  mWorkInBackground         = false;
  
}


/**
 * Destructor
**/
MainDlg::~MainDlg(void)
{
  // Free the views
  mCurrentView = NULL;  
  if(mTabsView)
    delete mTabsView;
  if(mListView)
    delete mListView;
  if(mMultiView)
    delete mMultiView;

  delete mPrefsDlg;
  delete mAboutDlg;
  delete mClientsDlg;
  delete mBenchmarksDlg;
  delete mSystrayManager;
}


/**
 * Is the worker thread doing something?
**/
void MainDlg::workInBackground(bool working)
{
  unsigned int menuItemEnabled = working ? MF_GRAYED : MF_ENABLED;
  HMENU hMenu = GetMenu(mHDlg);

  mWorkInBackground = working;
  mCurrentView->enable(!working);

  EnableMenuItem(hMenu, ID_MIT_RELOADCLIENT, menuItemEnabled);
  EnableMenuItem(hMenu, ID_MIT_UPDATEDATABASE, menuItemEnabled);
  EnableMenuItem(hMenu, ID_MIT_QUIT, menuItemEnabled);
  EnableMenuItem(hMenu, ID_MIT_VIEWSTATS, menuItemEnabled);
  EnableMenuItem(hMenu, ID_MIT_CONFCLIENTS, menuItemEnabled);
  EnableMenuItem(hMenu, ID_MIT_PREFS, menuItemEnabled);
  EnableMenuItem(hMenu, ID_MIT_ABOUT, menuItemEnabled);
}


/**
 * Open the default browser on the personal stats page of the user
**/
inline void MainDlg::gotoStatsURL(void)
{
  const FahClient* client = mCurrentView->getCurrentClient();

  if(client->isValid())
    Worker::mInstance->addJob(mHDlg, Worker::JOB_OPENBROWSERSTATS, (WPARAM)client->getContributorUserName(), (LPARAM)client->getContributorTeamNumber());
}


/**
 * Kill or set timers for auto reload
**/
void MainDlg::updateAutoReload(void)
{
  if(mTimerRunning)
  {
    KillTimer(mHDlg, TIMER_ID);
    mTimerRunning = false;
  }

  if(PrefsManager::mInstance.mAutoReloadEnabled)
  {
    SetTimer(mHDlg, TIMER_ID, PrefsManager::mInstance.mAutoReloadFrequency*60000, NULL);
    mTimerRunning = true;
  }
}


/**
 * The list of clients has (potentially) been changed.
**/
void MainDlg::updateClientsList(void)
{
  unsigned int currentClient;

  // BUGFIX
  // Even if the underlying view has been nullified, mCurrentView keeps the old value of the pointer
  // It HAS to be nullified to avoid 'segmentation faults'
  currentClient = mCurrentView->getCurrentClientIndex();
  mCurrentView = NULL;

  // Delete each instanciated view
  if(mListView)
  {
    delete mListView;
    mListView = NULL;
  }
  if(mTabsView)
  {
    delete mTabsView;
    mTabsView = NULL;
  }
  if(mMultiView)
  {
    delete mMultiView;
    mMultiView = NULL;
  }

  // And redraw the current one
  mCurrentViewId = PrefsManager::MDV_ERROR;
  updateMainView(currentClient);
}


/**
 * Dynamically change the main view according to the preferences
**/
void MainDlg::updateMainView(unsigned int currentClient)
{
  bool errorMode;

  // We need to change the current view only if it is different from the requested one
  if(mCurrentViewId != PrefsManager::mInstance.mMainDlgView)
  {
    mCurrentViewId = PrefsManager::mInstance.mMainDlgView;

    // Should we use the error mode?
    if(mCurrentView != NULL)
    {
      mCurrentView->leave();
      errorMode = mCurrentView->getErrorMode();
    }
    else
      errorMode = false;
    if(ClientsList::mInstance.getSize() == 0)
      errorMode = true;

    // Switch to the requested view, but create it before if needed
    switch(mCurrentViewId)
    {
      case PrefsManager::MDV_TABS:
        if(!mTabsView)
          mTabsView = new TabsView(mHDlg, currentClient);
        mCurrentView = mTabsView;
        break;

      case PrefsManager::MDV_LIST:
        if(!mListView)
          mListView = new ListView(mHInstance, mHDlg, currentClient);
        mCurrentView = mListView;
        break;

      case PrefsManager::MDV_MULTI:
        if(!mMultiView)
          mMultiView = new MultiView(mHDlg, currentClient);
        mCurrentView = mMultiView;
        break;
    }
    mCurrentView->init(currentClient, errorMode);
    mCurrentView->gainFocus();
  }
}


/**
 * Enable/Disable the horizontal scrollbar in the text area.
**/
void MainDlg::updateScrollbar(void)
{
  BOOL show = PrefsManager::mInstance.mLogHScrollEnabled ? TRUE : FALSE;

  ShowScrollBar(mHTxtLog, SB_HORZ, show);
}


/**
 * Manage custom messages
**/
BOOL MainDlg::dialogProc(UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch(msg)
  {
    case WM_TIMER:
      return onTimer(wParam);

    case WM_WORKERTHREAD:
      return onWorkerThread((Worker::JOB)wParam, lParam);

    case WM_WORKERSTATUS:
      setStatus((char*)wParam);
      return FALSE;

    case WM_SYSTRAYNOTIFICATION:
      return onTrayNotification(lParam);
  }

  return MyDialogBox::dialogProc(msg, wParam, lParam);
}


/**
 * Manage the WM_INITDIALOG message
**/
BOOL MainDlg::onInitDialog(void)
{
  // Bind the controls to their corresponding attributes
  mHTxtLog      = getItem(ID_MAI_TXT_LOG);
  mHLblCoreName = getItem(ID_MAI_LBL_CORENAME);
  mHLblError    = getItem(ID_MAI_LBL_ERROR);
  mHLblStatus   = getItem(ID_MAI_LBL_STATUS);

  // Create all the needed objects
  mPrefsDlg       = new PrefsDlg(mHInstance, mHDlg);
  mAboutDlg       = new AboutDlg(mHInstance, mHDlg);
  mClientsDlg     = new ClientsDlg(mHInstance, mHDlg);
  mBenchmarksDlg  = new BenchmarksDlg(mHInstance, mHDlg);
  mSystrayManager = new SystrayManager(mHDlg, 0, LoadIcon(mHInstance, MAKEINTRESOURCE(ID_ICO_DIALOG)));

  // Initialize the dialog box
  setSmallIcon(ID_ICO_DIALOG);
  setTitle(PrefsManager::mInstance.mAppNameVersion);
  setStatus(STATUS_IDLE);
  mSystrayManager->setTooltip(PrefsManager::mInstance.mAppNameVersion);

  // Load all the needed files
  if(ProjectsManager::mInstance.loadPointsFile(".\\points.dat") == false)
    warningMessageBox("Unable to find a points file.\nNo credit/core information will be displayed");

  // Define the resizing behavior
  setFixedWidth(DLG_MAIN_FIXED_WIDTH);
  setResizabledHeight(DLG_MAIN_MIN_HEIGHT);
  initResizableDlg(mHDlg, mHInstance, PrefsManager::mInstance.mDialogWidth, PrefsManager::mInstance.mDialogHeight);

  // Adjust the behavior depending on the preferences
  updateMainView(0);
  updateAutoReload();
  updateScrollbar();

  // Should the dialog box be minimized immediately?
  if(mStartMinimized)
  {
    mIsMinimized = true;
    if(PrefsManager::mInstance.mMinimizeToTrayEnabled)
      mSystrayManager->minimize();
    else
      ShowWindow(mHDlg, SW_SHOWMINIMIZED); 
  }
  else if(ClientsList::mInstance.getSize() == 0)
    onCommand(BN_CLICKED, ID_MIT_CONFCLIENTS, getItem(ID_MIT_CONFCLIENTS));

  return FALSE;
}


/**
 * Manage the WM_CLOSE message
**/
BOOL MainDlg::onClose(void)
{
  if(mWorkInBackground)
  {
    errorMessageBox("Please wait for the current task to stop before exiting");
    return FALSE;
  }

  return MyDialogBox::onClose();
}


/**
 * Manage the WM_COMMAND message
**/
BOOL MainDlg::onCommand(unsigned int notifyCode, unsigned int id, HWND hControl)
{
  switch(id)
  {
    case ID_MIT_VIEWSTATS:
      gotoStatsURL();
      break;

    case ID_MIT_QUIT:
      onClose();
      break;

    case ID_MIT_RELOADCLIENT:
      mCurrentView->reloadRequested();
      mCurrentView->gainFocus();
      break;

    case ID_MIT_ABOUT:
      showChildDialog(mAboutDlg);
      break;

    case ID_MIT_VIEWBENCHMARKS:
      showChildDialog(mBenchmarksDlg);
      break;

    case ID_MIT_CONFCLIENTS:
      showChildDialog(mClientsDlg);
      updateClientsList();
      break;

    case ID_MIT_PREFS:
      showChildDialog(mPrefsDlg);
      mCurrentView->reloadRequested();
      updateAutoReload();
      updateMainView(mCurrentView->getCurrentClientIndex());
      updateScrollbar();
      break;

    case ID_MIT_UPDATEDATABASE:
      workInBackground(true);
      Worker::mInstance->addJob(mHDlg, Worker::JOB_UPDATEPOINTS, (WPARAM)NULL, (LPARAM)NULL);
      break;
  }
  return FALSE;
}


/**
 * Manage the WM_NOTIFY message
**/
BOOL MainDlg::onNotify(unsigned int id, NMHDR* information)
{
  switch(id)
  {
    case ID_MAI_LST_CLIENTS:
    case ID_MAI_LST_CLIENTSMULTI:
    case ID_MAI_TAB_CLIENTS:
      if(mCurrentView)
        return mCurrentView->onNotify(information);
      break;
  }

  return FALSE;
}


/**
 * Manage the WM_CTLCOLORSTATIC message
**/
BOOL MainDlg::onCtlColorStatic(HDC hDc, HWND hWnd)
{
  // Color the core name and the error message in red
  if(hWnd == mHLblCoreName || hWnd == mHLblError)
  {
    SetTextColor(hDc, RGB(200, 50, 50));
    SetBkColor(hDc, GetSysColor(COLOR_BTNFACE));
    return (BOOL)GetSysColorBrush(COLOR_BTNFACE);
  }
  // Give 'standard' colors to the textarea (read-only textareas are greyed)
  else if(hWnd == mHTxtLog)
  {
    SetBkColor(hDc, RGB(255, 255, 255));
    return (BOOL)GetStockObject(WHITE_BRUSH);
  }

  return FALSE;
}


/**
 * Manage the WM_SIZE message
**/
BOOL MainDlg::onSize(unsigned int fwSizeType, unsigned int width, unsigned int height)
{
  sizeHasChanged(mHDlg, fwSizeType, width, height);

  switch(fwSizeType)
  {
    case SIZE_MINIMIZED:
      if(!mIsMinimized)
      {
        mIsMinimized = true;
        if(PrefsManager::mInstance.mMinimizeToTrayEnabled)
          mSystrayManager->minimize();
      }
      break;

    case SIZE_RESTORED:
      // If the dialog was minimized, should we refresh information ?
      if(mIsMinimized)
      {
        mIsMinimized = false;
        if(mShouldReloadAfterRestore)
        {
          mShouldReloadAfterRestore = false;
          mCurrentView->reloadRequested();
        }
      }
      break;
  }

  return FALSE;
}


/**
 * Manage the WM_TRAYNOTIFICATION message
**/
inline BOOL MainDlg::onTrayNotification(unsigned int mouseAction)
{
  if(mouseAction == WM_LBUTTONDBLCLK)
  {
    mSystrayManager->restore();
    mCurrentView->gainFocus();
  }

  return FALSE;
}


/**
 * Manage the WM_TIMER message
**/
inline BOOL MainDlg::onTimer(unsigned int timerId)
{
  // FahMon uses only one timer, there's no need to check which one it is

  // Refresh only if FahMon is visible (not minimized)
  if(mIsMinimized)
    mShouldReloadAfterRestore = true;
  else
    mCurrentView->reloadRequested();

  return FALSE;
}


/**
 * Manage the WM_WORKERTHREAD message
**/
inline BOOL MainDlg::onWorkerThread(Worker::JOB job, LPARAM lParam)
{
  const char *error;

  switch(job)
  {
    // Points have been updated
    case Worker::JOB_END_UPDATEPOINTS:
      if((error = (const char*)lParam) != NULL)
        errorMessageBox(error);
      else
      {
        ClientsList::mInstance.getClient(mCurrentView->getCurrentClientIndex())->updateWUInformation();
        mCurrentView->displayCorePoints();
      }
      setStatus(STATUS_IDLE);
      workInBackground(false);
      mCurrentView->gainFocus();
      break;

    case Worker::JOB_END_LOADCLIENT:
      mCurrentView->reloadDone((unsigned int)lParam);
      setStatus(STATUS_IDLE);
      break;
  }

  return FALSE;
}


/**
 * The size of the dialog box has changed, give a correct position to the controls and/or resize them
**/
void MainDlg::reflowControls(unsigned int clientAreaWidth, unsigned int clientAreaHeight) const
{
  // Move the controls
  SetWindowPos(mHTxtLog, NULL, 0, 0, 487, clientAreaHeight - 275, SWP_NOMOVE | SWP_NOZORDER);
  UIEdit::scrollToEnd(mHTxtLog);
  SetWindowPos(mHLblStatus, NULL, 8, clientAreaHeight - 20, clientAreaWidth - 30, 20, SWP_NOZORDER);
  SetWindowPos(mHLblError, NULL, 0, (clientAreaHeight / 2) - 5, 0, 0, SWP_NOSIZE | SWP_NOZORDER);

  // Save the new size
  PrefsManager::mInstance.mDialogHeight = clientAreaHeight;
  PrefsManager::mInstance.mDialogWidth  = clientAreaWidth;
}
