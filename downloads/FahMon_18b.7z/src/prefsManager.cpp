/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "prefsmanager.h"
#include "bufferedInputFile.h"
#include "bufferedOutputFile.h"


#define APP_NAME         "FahMon"
#define APP_VERSION      "1.8b"
#define APP_NAME_VERSION APP_NAME" "APP_VERSION

#define PREFS_VERSION_NEEDED 0


// This is the only instance across the application
PrefsManager PrefsManager::mInstance;


/**
 * Constructor
**/
PrefsManager::PrefsManager(void)
{
  // Application information
  mVersion        = APP_VERSION;
  mAppName        = APP_NAME;
  mAppNameVersion = APP_NAME_VERSION;

  // Size of the main dialog box
  mDialogWidth  = DLG_MAIN_FIXED_WIDTH;
  mDialogHeight = DLG_MAIN_MIN_HEIGHT;

  // Size of the benchmarks dialog box
  mBenchmarksDlgWidth  = DLG_BENCHMARKS_MIN_WIDTH;
  mBenchmarksDlgHeight = DLG_BENCHMARKS_MIN_HEIGHT;

  // Size of the clients dialog box
  mClientsDlgWidth  = DLG_CLIENTS_MIN_WIDTH;
  mClientsDlgHeight = DLG_CLIENTS_MIN_HEIGHT;

  // Width of the columns for the clients dialog box
  mClientsDlgColumnNameWidth     = DLG_CLIENTS_NAME_COL_WIDTH;
  mClientsDlgColumnLocationWidth = DLG_CLIENTS_LOCATION_COL_WIDTH;
  
  // Auto reload
  mAutoReloadEnabled   = false;
  mAutoReloadFrequency = 5;

  // Horizontal scrolling of the text area
  mLogHScrollEnabled = false;

  // The view that should be used in the main dialog box
  mMainDlgView = MDV_MULTI;

  // Minimize to systray?
  mMinimizeToTrayEnabled = true;

  // Only one instance allowed ?
  mThereCanBeOnlyOne = true;

  // Analyse last frame duration ?
  mAnalyseLastFrameDuration = true;

  // Display ETA?
  mComputeETA = true;

  // Check for inactive clients
  mCheckForActivity = true;

  // Use an HTTP proxy ?
  mHTTPProxyEnabled    = false;
  mHTTPProxyAddress[0] = '\0';
  mHTTPProxyPort       = 8080;
}


/**
 * Load the preferences from the saved file
**/
void PrefsManager::loadPrefs(const char* filename)
{
  DWORD prefsVersion, length;
  BufferedInputFile prefsFile(filename);

  // Open the file
  if(prefsFile.isValid() == false)
    return;

  // ~~~~==== Read the prefs ====~~~~
  //
  // The order should not be changed between releases!!
  // We want the configuration file to be readable between releases

  //
  // ~~~~~~====== v1.5.3 ======~~~~~~
  //

  // Read the version number
  // It is no longer used, but we have to keep it in order to be able to read previous prefs files
  prefsFile.read(&prefsVersion, sizeof(prefsVersion));

  // Size of the main dialog box
  prefsFile.read(&mDialogWidth, sizeof(mDialogWidth));
  prefsFile.read(&mDialogHeight, sizeof(mDialogHeight));

  //
  // ~~~~~~====== v1.7 ======~~~~~~
  //

  // Auto reload
  prefsFile.read(&mAutoReloadEnabled, sizeof(mAutoReloadEnabled));
  prefsFile.read(&mAutoReloadFrequency, sizeof(mAutoReloadFrequency));

  // The view that should be used in the main dialog box
  prefsFile.read(&mMainDlgView, sizeof(mMainDlgView));

  // Minimize to systray?
  prefsFile.read(&mMinimizeToTrayEnabled, sizeof(mMinimizeToTrayEnabled));

  // Use an HTTP proxy ?
  prefsFile.read(&mHTTPProxyEnabled, sizeof(mHTTPProxyEnabled));
  prefsFile.read(&length, sizeof(length));
  prefsFile.read(mHTTPProxyAddress, length);
  mHTTPProxyAddress[length] = '\0';
  prefsFile.read(&mHTTPProxyPort, sizeof(mHTTPProxyPort));

  //
  // ~~~~~~====== v1.7.2 ======~~~~~~
  //

  // Horizontal scrolling in the text area?
  prefsFile.read(&mLogHScrollEnabled, sizeof(mLogHScrollEnabled));

  // Only one instance allowed ?
  prefsFile.read(&mThereCanBeOnlyOne, sizeof(mThereCanBeOnlyOne));

  // Display ETA?
  prefsFile.read(&mComputeETA, sizeof(mComputeETA));

  // Check for inactive clients
  prefsFile.read(&mCheckForActivity, sizeof(mCheckForActivity));

  //
  // ~~~~~~====== v1.8 ======~~~~~~
  //

  // Analyse last frame duration ?
  prefsFile.read(&mAnalyseLastFrameDuration, sizeof(mAnalyseLastFrameDuration));

  // Size of the benchmarks dialog box
  prefsFile.read(&mBenchmarksDlgWidth, sizeof(mBenchmarksDlgWidth));
  prefsFile.read(&mBenchmarksDlgHeight, sizeof(mBenchmarksDlgHeight));

  // Size of the clients dialog box
  prefsFile.read(&mClientsDlgWidth, sizeof(mClientsDlgWidth));
  prefsFile.read(&mClientsDlgHeight, sizeof(mClientsDlgHeight));

  // Size of the columns for the clients dialog box
  prefsFile.read(&mClientsDlgColumnNameWidth, sizeof(mClientsDlgColumnNameWidth));
  prefsFile.read(&mClientsDlgColumnLocationWidth, sizeof(mClientsDlgColumnLocationWidth));
}


/**
 * Save the preferences to the disk
**/
void PrefsManager::savePrefs(const char* filename) const
{
  DWORD prefsVersion = PREFS_VERSION_NEEDED, length;
  BufferedOutputFile outFile(filename);
  
  // Open the file
  if(outFile.isValid() == false)
    return;

  // ~~~~==== Write the prefs ====~~~~
  //
  // The order should not be changed between releases!!
  // We want the configuration file to be readable between releases
  
  //
  // ~~~~~~====== v1.5.3 ======~~~~~~
  //
  
  // Write the version number
  // It is no longer used, but we have to keep it in order to be able to read previous prefs files
  outFile.write(&prefsVersion, sizeof(prefsVersion));

  // Size of the main dialog box
  outFile.write(&mDialogWidth, sizeof(mDialogWidth));
  outFile.write(&mDialogHeight, sizeof(mDialogHeight));

  //
  // ~~~~~~====== v1.7 ======~~~~~~
  //

  // Auto reload
  outFile.write(&mAutoReloadEnabled, sizeof(mAutoReloadEnabled));
  outFile.write(&mAutoReloadFrequency, sizeof(mAutoReloadFrequency));
  
  // The view that should be used in the main dialog box
  outFile.write(&mMainDlgView, sizeof(mMainDlgView));

  // Minimize to systray?
  outFile.write(&mMinimizeToTrayEnabled, sizeof(mMinimizeToTrayEnabled));

  // Use an HTTP proxy ?
  outFile.write(&mHTTPProxyEnabled, sizeof(mHTTPProxyEnabled));
  length = lstrlen(mHTTPProxyAddress);
  outFile.write(&length, sizeof(length));
  outFile.write(mHTTPProxyAddress, length);
  outFile.write(&mHTTPProxyPort, sizeof(mHTTPProxyPort));

  //
  // ~~~~~~====== v1.7.2 ======~~~~~~
  //

  // Horizontal scrolling in the text area?
  outFile.write(&mLogHScrollEnabled, sizeof(mLogHScrollEnabled));

  // Only one instance allowed ?
  outFile.write(&mThereCanBeOnlyOne, sizeof(mThereCanBeOnlyOne));

    // Display ETA?
  outFile.write(&mComputeETA, sizeof(mComputeETA));

  // Check for inactive clients
  outFile.write(&mCheckForActivity, sizeof(mCheckForActivity));

  //
  // ~~~~~~====== v1.8 ======~~~~~~
  //

  // Analyse last frame duration ?
  outFile.write(&mAnalyseLastFrameDuration, sizeof(mAnalyseLastFrameDuration));

  // Size of the main dialog box
  outFile.write(&mBenchmarksDlgWidth, sizeof(mBenchmarksDlgWidth));
  outFile.write(&mBenchmarksDlgHeight, sizeof(mBenchmarksDlgHeight));

  // Size of the clients dialog box
  outFile.write(&mClientsDlgWidth, sizeof(mClientsDlgWidth));
  outFile.write(&mClientsDlgHeight, sizeof(mClientsDlgHeight));

  // Size of the columns for the clients dialog box
  outFile.write(&mClientsDlgColumnNameWidth, sizeof(mClientsDlgColumnNameWidth));
  outFile.write(&mClientsDlgColumnLocationWidth, sizeof(mClientsDlgColumnLocationWidth));
}
