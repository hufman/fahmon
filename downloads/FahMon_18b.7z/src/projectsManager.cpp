/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "projectsManager.h"
#include "bufferedInputFile.h"
#include "bufferedOutputFile.h"
#include "xmlParser.h"
#include "fileTools.h"
#include "tools.h"

enum{TD, TR};


// This is the only instance across the application
ProjectsManager ProjectsManager::mInstance;


/**
 * Constructor
**/
ProjectsManager::ProjectsManager(void)
{
  FillMemory(mProjects, PROJECTS_MAX_KNOWN_NUMBER*sizeof(FahProject*), NULL);
}


/**
 * Destructor
**/
ProjectsManager::~ProjectsManager(void)
{
  unsigned int i;

  for(i=0; i<PROJECTS_MAX_KNOWN_NUMBER; ++i)
    if(mProjects[i] != NULL)
      delete mProjects[i];
}


/**
 * Retrieve the requested project
**/
const FahProject* ProjectsManager::getProjectInfos(unsigned int projectID) const
{
  if(projectID < PROJECTS_MAX_KNOWN_NUMBER)
    return mProjects[projectID];

  return NULL;
}


/**
 * Parse a psummary file
**/
bool ProjectsManager::loadPSummaryFile(const char* filename)
{
  char* fileString;
  XMLParser *parser;
  bool firstTR = true;
  unsigned int i, fileSize;
  FahProject *tmpProject;

  // Open and read the whole file
  if(!(fileString = FileTools::loadTextFile(filename, &fileSize)))
    return false;

  parser = new XMLParser(fileString);
  parser->addTag("td", TD);
  parser->addTag("tr", TR);

  parser->nextToken();
  while(parser->getToken() != XMLParser::TK_END)
  {
    if(parser->getToken() == XMLParser::TK_START_TAG && parser->getTag() == TR)
    {
      if(firstTR)
        firstTR = false;
      else
      {
        while(parser->getToken() != XMLParser::TK_START_TAG || parser->getTag() != TD)
          parser->nextToken();
      
        // Project number
        parser->nextToken();
        tmpProject = new FahProject();
        tmpProject->mId = Tools::atoi(parser->getTextValue());
      
        for(i=0; i<18; ++i)
          parser->nextToken();

        // Credit
        tmpProject->mValue = Tools::atod(parser->getTextValue());
        for(i=0; i<3; ++i)
          parser->nextToken();

        // Number of runs
        tmpProject->mNbRuns = Tools::atoi(parser->getTextValue());
        for(i=0; i<3; ++i)
          parser->nextToken();

        // Needed core
        tmpProject->mCore = FahCore::atocore(parser->getTextValue());

        // Add this new project
        if(tmpProject->mId < PROJECTS_MAX_KNOWN_NUMBER)
          mProjects[tmpProject->mId] = tmpProject;
      }
    }
    parser->nextToken();
  }

  delete parser;
  delete[] fileString;
  return true;
}


/**
 * Parse the file that contains projects information
**/
bool ProjectsManager::loadPointsFile(const char* filename)
{
  FahProject *tmpProject;
  BufferedInputFile pointsFile(filename);

  if(pointsFile.isValid() == false)
    return false;

  // Load the content of the file
  while(true)
  {
    // Read the next project and stop if we have reached the end of the file
    tmpProject = new FahProject();
    if(pointsFile.read(tmpProject, sizeof(FahProject)) == false)
      break;

    // Take care to not go out of the array
    if(tmpProject->mId < PROJECTS_MAX_KNOWN_NUMBER)
      mProjects[tmpProject->mId] = tmpProject;
  }
  delete tmpProject;

  return true;
}


/**
 * Update the current list with the given list
**/
void ProjectsManager::updateProjects(ProjectsManager *upToDateprojects)
{
  unsigned int i;

  for(i=0; i<PROJECTS_MAX_KNOWN_NUMBER; ++i)
    if(upToDateprojects->mProjects[i])
    {
      if(!mProjects[i])
        mProjects[i] = new FahProject();

      CopyMemory(mProjects[i], upToDateprojects->mProjects[i], sizeof(FahProject));
    }
}


/**
 * Write the known projects to a simple file
**/
bool ProjectsManager::writeTo(const char* filename) const
{
  unsigned int i;
  BufferedOutputFile outFile(filename);

  // Create the file
  if(outFile.isValid() == false)
    return false;

  // Save projects information
  for(i=0; i<PROJECTS_MAX_KNOWN_NUMBER; ++i)
  {
    // We save only *known* projects
    if(mProjects[i] != NULL)
      outFile.write(mProjects[i], sizeof(FahProject));
  }

  return true;
}
