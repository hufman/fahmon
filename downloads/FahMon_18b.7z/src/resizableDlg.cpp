/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "resizableDlg.h"


#define SIZEGRIP_WIDTH  17
#define SIZEGRIP_HEIGHT 17


/**
 * Constructor.
**/
ResizableDlg::ResizableDlg(bool hasAMenu)
{
  mHasAMenu    = hasAMenu;
  mHResizeGrip = NULL;

  mFixedWidth     = false;
  mPreferredWidth = 0;
  mMinWidth       = 0;

  mFixedHeight     = false;
  mPreferredHeight = 0;
  mMinHeight       = 0;
}


/**
 * Destructor.
**/
ResizableDlg::~ResizableDlg(void)
{
  // It seems that we don't have to destroy mHResizeGrip, because the dialog box automatically destroys its associated children
}


/**
 * Set the size to some initial value and center the dialog box
**/
void ResizableDlg::initResizableDlg(HWND hDlg, HINSTANCE hInstance, unsigned int clientAreaWidth, unsigned int clientAreaHeight)
{
  RECT workAreaSize, dialogBoxSize;
  unsigned int neededSizeX, neededSizeY;

  // 1. Retrieve the size of the work area
  SystemParametersInfo(SPI_GETWORKAREA, 0, &workAreaSize, 0);

  // 2. Compute the size needed to display the dialog box, depending on the requested size for the client area
  dialogBoxSize.left   = 0;
  dialogBoxSize.right  = clientAreaWidth;
  dialogBoxSize.top    = 0;
  dialogBoxSize.bottom = clientAreaHeight;
  AdjustWindowRect(&dialogBoxSize, WS_OVERLAPPEDWINDOW, mHasAMenu);

  neededSizeX = dialogBoxSize.right - dialogBoxSize.left;
  neededSizeY = dialogBoxSize.bottom - dialogBoxSize.top;

  // 3. Insure that the diaog box fits in the work area size
  if(neededSizeX > (unsigned int)workAreaSize.right)
  {
    dialogBoxSize.left   = 0;
    dialogBoxSize.top    = 0;
    dialogBoxSize.bottom = clientAreaHeight;

    if(mFixedWidth)
      dialogBoxSize.right = mPreferredWidth;
    else
      dialogBoxSize.right = mMinWidth;

    AdjustWindowRect(&dialogBoxSize, WS_OVERLAPPEDWINDOW, mHasAMenu);
    neededSizeX = dialogBoxSize.right - dialogBoxSize.left;
  }
  if(neededSizeY > (unsigned int)workAreaSize.bottom)
  {
    dialogBoxSize.left   = 0;
    dialogBoxSize.right  = clientAreaWidth;
    dialogBoxSize.top    = 0;

    if(mFixedHeight)
      dialogBoxSize.bottom = mPreferredHeight;
    else
      dialogBoxSize.bottom = mMinHeight;

    AdjustWindowRect(&dialogBoxSize, WS_OVERLAPPEDWINDOW, mHasAMenu);
    neededSizeY = dialogBoxSize.bottom - dialogBoxSize.top;
  }

  // 4. Center the dialog box
  SetWindowPos(hDlg, NULL, (workAreaSize.right-neededSizeX)/2, (workAreaSize.bottom-neededSizeY)/2, neededSizeX, neededSizeY, SWP_NOZORDER);

  // 5. Create the resize grip and place it in the bottom right corner
  GetClientRect(hDlg, &dialogBoxSize);
  mHResizeGrip = CreateWindowEx(0, "SCROLLBAR", "", WS_CHILD | WS_VISIBLE | SBS_SIZEGRIP,
                                dialogBoxSize.right -  SIZEGRIP_WIDTH, dialogBoxSize.bottom - SIZEGRIP_HEIGHT,
                                SIZEGRIP_WIDTH, SIZEGRIP_HEIGHT,
                                hDlg, NULL, hInstance, NULL);
}


/**
 * Must be called when a WM_SIZE message is received
**/
void ResizableDlg::sizeHasChanged(HWND hDlg, unsigned int fwSizeType, unsigned int clientAreaWidth, unsigned int clientAreaHeight) const
{
  RECT rect;
  unsigned int width;
  unsigned int height;

  // Don't do anything if it isn't needed (minimizing for example)
  if(fwSizeType != SIZE_RESTORED)
    return;

  // Check if the new width is correct
  if(mFixedWidth == true)
    width = mPreferredWidth;
  else if(clientAreaWidth < mMinWidth)
    width = mMinWidth;
  else
    width = clientAreaWidth;

  // Check if the new height is correct
  if(mFixedHeight == true)
    height = mPreferredHeight;
  else if(clientAreaHeight < mMinHeight)
    height = mMinHeight;
  else
    height = clientAreaHeight;

  // Resize the dialog box if needed
  if(width != clientAreaWidth || height != clientAreaHeight)
  {
    rect.left   = 0;
    rect.right  = width;
    rect.top    = 0;
    rect.bottom = height;
    AdjustWindowRect(&rect, WS_OVERLAPPEDWINDOW, mHasAMenu);
    SetWindowPos(hDlg, NULL, 0, 0, rect.right - rect.left, rect.bottom - rect.top, SWP_NOMOVE | SWP_NOZORDER);
  }

  // Move the resize grip to the correct location (bottom right corner of the dialog box)
  SetWindowPos(mHResizeGrip, NULL, width - SIZEGRIP_WIDTH, height - SIZEGRIP_HEIGHT, 0, 0, SWP_NOZORDER | SWP_NOSIZE);

  // And reflow the other controls
  reflowControls(width, height);
}
