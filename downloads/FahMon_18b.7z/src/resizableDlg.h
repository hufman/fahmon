/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#ifndef _RESIZABLEDLG_H
#define _RESIZABLEDLG_H

#include "fahMon.h"


// Does not support maximizing for the moment
class ResizableDlg
{
protected:
  HWND mHResizeGrip;
  bool mHasAMenu;

  bool mFixedWidth;
  unsigned int mPreferredWidth;
  unsigned int mMinWidth;
  
  bool mFixedHeight;
  unsigned int mPreferredHeight;
  unsigned int mMinHeight;

public:
  ResizableDlg(bool hasAMenu);
  ~ResizableDlg(void);

  void initResizableDlg(HWND hDlg, HINSTANCE hInstance, unsigned int clientAreaWidth, unsigned int clientAreaHeight);
  void sizeHasChanged(HWND hDlg, unsigned int fwSizeType, unsigned int clientAreaWidth, unsigned int clientAreaHeight) const;
  virtual void reflowControls(unsigned int clientAreaWidth, unsigned int clientAreaHeight) const = 0;

  void setFixedWidth(unsigned int width) {mFixedWidth = true; mPreferredWidth = width;}
  void setResizabledWidth(unsigned int minWidth) {mFixedWidth = false; mMinWidth = minWidth;}

  void setFixedHeight(unsigned int height) {mFixedHeight = true; mPreferredHeight = height;}
  void setResizabledHeight(unsigned int minHeight) {mFixedHeight = false; mMinHeight = minHeight;}

  void setDlgResizable(unsigned int minWidth, unsigned int minHeight) {setResizabledWidth(minWidth); setResizabledHeight(minHeight);}
};


#endif
