/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "tools.h"

unsigned int toLowerCase[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255};


#define IS_A_SEPARATOR(c) (c == ' ' || c == '\t')
#define IS_A_NUMBER(c) (c >= '0' && c <= '9')


/**
 * Convert a string to an unsigned int, ignore leading spaces and trailing characters.
**/
unsigned int Tools::atoi(const char* string)
{
  unsigned int value = 0, pos = 0;

  // Skip leading separators
  while(IS_A_SEPARATOR(string[pos]))
    ++pos;

  // Conversion to an int
  while(IS_A_NUMBER(string[pos]))
    value = value * 10 + string[pos++] - '0';
  
  return value;
}


/**
 * Convert a string to a double, ignore leading spaces and trailing characters
**/
double Tools::atod(const char* string)
{
  int intPart = 0, decimalPart = 0, pos = 0, size = 1;
  
  // Skip leading separators
  while(IS_A_SEPARATOR(string[pos]))
    ++pos;
  
  // Convert the integer part of the double
  while(IS_A_NUMBER(string[pos]))
    intPart = intPart * 10 + string[pos++] - '0';

  // Is it really a double?
  if(string[pos++] != '.')
    return (double)intPart;
  
  // Convert the decimal part of the double
  while(IS_A_NUMBER(string[pos]))
  {
    decimalPart = decimalPart * 10 + string[pos++] - '0';
    size = size * 10;
  }
  
  if(decimalPart)
    return (double)intPart + (double)decimalPart / size;

  return (double)intPart;
}


/**
 * Compare two strings, but no more than the given number of characters
 * The comparison is case insensitive
**/
bool Tools::strcmp(const char* left, const char* right, unsigned int maxSize)
{
  while(maxSize != 0)
  {
    if(toLowerCase[*left++] != toLowerCase[*right++])
      return false;

    --maxSize;
  }

  return true;
}


/**
 * Format a number of seconds into a correct string.
**/
void Tools::secondsToString(char* output, unsigned int nbSeconds)
{
  unsigned int nbDays, nbHours, nbMinutes;

  nbDays    = nbSeconds / 86400;
  nbSeconds = nbSeconds % 86400;
  nbHours   = nbSeconds / 3600;
  nbMinutes = (nbSeconds % 3600) / 60;

  if(nbDays != 0)
    wsprintf(output, "%dd %02dh %02dmn", nbDays, nbHours, nbMinutes);
  else if(nbHours != 0)
    wsprintf(output, "%02dh %02dmn", nbHours, nbMinutes);
  else
    wsprintf(output, "%02dmn", nbMinutes);
}


/**
 * Format a number of seconds into a correct string.
**/
void Tools::accurateSecondsToString(char* output, unsigned int nbSeconds)
{
  char buffer[128];

  Tools::secondsToString(output, nbSeconds);
  wsprintf(buffer, " %02ds", ((nbSeconds % 86400) % 3600) % 60);
  lstrcat(output, buffer);
}


/**
 * Open the default browser on the specified url.
**/
void Tools::openURL(const char* url)
{
  SHELLEXECUTEINFO shellInfo;

  ZeroMemory(&shellInfo, sizeof(shellInfo));
  shellInfo.cbSize = sizeof(shellInfo);
  shellInfo.fMask = SEE_MASK_FLAG_NO_UI | SEE_MASK_NOCLOSEPROCESS;
  shellInfo.lpFile = url;
  shellInfo.lpParameters = NULL;

  // CloseHandle() must be called to avoid handles leaks
  if(ShellExecuteEx(&shellInfo))
    CloseHandle(shellInfo.hProcess);
}


/**
 * @return true if the OS is WinXP, false otherwise.
 *
 * @remark Method found at http://www.codeproject.com/win32/osdetect.asp?df=100&forumid=2755&exp=0&select=68705
**/
bool Tools::isRunningOnXP(void)
{
  OSVERSIONINFO OSversion;

  OSversion.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  GetVersionEx(&OSversion);

  if(OSversion.dwPlatformId == VER_PLATFORM_WIN32_NT && OSversion.dwMajorVersion == 5 && OSversion.dwMinorVersion == 1)
    return true;

  return false;
}
