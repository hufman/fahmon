/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************************************************************************/

#include "worker.h"
#include "dlgMessages.h"
#include "prefsManager.h"
#include "projectsManager.h"
#include "httpDownloader.h"
#include "clientsList.h"
#include "fahClient.h"
#include "tools.h"
#include "bufferedOutputFile.h"

#define MAX_JOBS 1024
#define BUFFER_SIZE 256
#define TEXT_UPDATE_DATABASE "Downloading the new protein definition"

enum{OBSERVABLE_HTTPDOWNLOADER};


Worker* Worker::mInstance;


/**
 * Constructor
**/
Worker::Worker(void) : mQueue(MAX_JOBS)
{
  buffer1 = new char[BUFFER_SIZE];
  buffer2 = new char[BUFFER_SIZE];
  mHSemaphore = CreateSemaphore(NULL, 0, MAX_JOBS, NULL);
  InitializeCriticalSection(&mHCriticalSection);
  CreateThread(NULL, 0, staticThreadProc, (void*)this, 0, &mThreadID);
}


/**
 * Destructor
**/
Worker::~Worker(void)
{
  delete[] buffer1;
  delete[] buffer2;
  CloseHandle(mHSemaphore);
}


/**
 * Update the current progress of the worker
**/
inline void Worker::setProgress(HWND hWnd, const char *msg) const
{
  PostMessage(hWnd, WM_WORKERSTATUS, (WPARAM)msg, (LPARAM)NULL);
}


/**
 * Add a job to the queue
**/
void Worker::addJob(HWND hDlg, JOB job, WPARAM wParam, LPARAM lParam)
{
  JobDesc *newJob = new JobDesc;

  // Create the new entry
  newJob->mHDlg = hDlg;
  newJob->mJob = job;
  newJob->mWParam = wParam;
  newJob->mLParam = lParam;

  // Synchronize access to the queue
  EnterCriticalSection(&mHCriticalSection);
  mQueue.put(newJob);
  LeaveCriticalSection(&mHCriticalSection);

  // Launch a signal to the thread
  ReleaseSemaphore(mHSemaphore, 1, NULL);
}


/**
 * Called when the thread has been created
**/
DWORD WINAPI Worker::staticThreadProc(void *param)
{
  Worker *_this = (Worker*)param;

  if(_this != NULL)
    return _this->threadProc();

  return 0;
}


/**
 * This were the main wait loop is located
**/
DWORD Worker::threadProc(void)
{
  JobDesc *todo = NULL;
  bool loop = true;

  while(loop)
  {
    // Wait for a job
    if(WaitForSingleObject(mHSemaphore, INFINITE) == WAIT_OBJECT_0)
    {
      // Synchronize access to the queue
      EnterCriticalSection(&mHCriticalSection);
      todo = (JobDesc*)mQueue.get();
      LeaveCriticalSection(&mHCriticalSection);

      if(todo != NULL)
      {
        switch(todo->mJob)
        {
          case JOB_QUIT:
            loop = false;
            break;

          case JOB_UPDATEPOINTS:
            onUpdatePoints(todo);
            break;

          case JOB_OPENBROWSERSTATS:
            onOpenBrowserStats(todo);
            break;

          case JOB_LOADCLIENT:
            onLoadClient(todo);
            break;

          case JOB_LOADALLCLIENTS:
            onLoadAllClients(todo);
            break;
        }
        delete todo;
      }
    }
  }

  return 1;
}


/**
 * Manage the UPDATEPOINTS job
**/
void Worker::onUpdatePoints(JobDesc *job)
{
  const char *error = NULL;
  ProjectsManager psummaryProjects;
  HTTPDownloader httpDownloader;
  BufferedOutputFile *outFile;

  setProgress(job->mHDlg, "Creating a temporary file...");

  // Try to use the temp path, otherwise use the local directory
  if(!GetTempPath(BUFFER_SIZE, buffer1))
    CopyMemory(buffer1, ".\\", 4);

  // Create a  temporary file
  if(!GetTempFileName(buffer1, PrefsManager::mInstance.mAppName, 0, buffer2))
    error = "Unable to create a temporary file";
  else
  {
    outFile = new BufferedOutputFile(buffer2);

    if(outFile->isValid() == false)
      error = "Unable to create a temporary file";
    else
    {
      setProgress(job->mHDlg, TEXT_UPDATE_DATABASE);
      // Download the up-to-date psummary file
      httpDownloader.setObservableConfiguration(this, OBSERVABLE_HTTPDOWNLOADER, job->mHDlg);
      error = httpDownloader.download("vspx27.stanford.edu", 80, "psummaryC.html", outFile);
      delete outFile;
      if(!error)
      {
        // Update the local points file
        setProgress(job->mHDlg, "Parsing the new protein definition...");
        psummaryProjects.loadPSummaryFile(buffer2);
        setProgress(job->mHDlg, "Updating the local protein definition...");
        ProjectsManager::mInstance.updateProjects(&psummaryProjects);
        setProgress(job->mHDlg, "Saving the local protein definition...");
        if(!ProjectsManager::mInstance.writeTo(".\\points.dat"))
          error = "Unable to write projects information to the file <points.dat>";
      }
      DeleteFile(buffer2);
    }
  }

  PostMessage(job->mHDlg, WM_WORKERTHREAD, (WPARAM)JOB_END_UPDATEPOINTS, (LPARAM)error);
}


/**
 * Open the default browser on the stats page of a user
**/
inline void Worker::onOpenBrowserStats(JobDesc *job) const
{
  wsprintf(buffer1, "http://vspx27.stanford.edu/cgi-bin/main.py?qtype=userpage&teamnum=%d&username=%s", (char*)job->mLParam, (char*)job->mWParam);
  Tools::openURL(buffer1);
}


/**
 * Load information about a client
**/
inline void Worker::onLoadClient(JobDesc *job) const
{
  wsprintf(buffer1, "Reloading %s information...", ((FahClient*)job->mWParam)->getClientName());
  setProgress(job->mHDlg, buffer1);

  // We just have to call the load method
  ((FahClient*)job->mWParam)->load();
  // lParam is the client index
  PostMessage(job->mHDlg, WM_WORKERTHREAD, (WPARAM)JOB_END_LOADCLIENT, job->mLParam);
}


/**
 * Load information about all the known clients
**/
inline void Worker::onLoadAllClients(JobDesc *job) const
{
  unsigned int i;

  for(i=0; i<ClientsList::mInstance.getSize(); ++i)
  {
    wsprintf(buffer1, "Reloading %s information...", ClientsList::mInstance.getClient(i)->getClientName());
    setProgress(job->mHDlg, buffer1);

    ClientsList::mInstance.getClient(i)->load();
    PostMessage(job->mHDlg, WM_WORKERTHREAD, (WPARAM)JOB_END_LOADCLIENT, (LPARAM)i);
  }
}


/**
 * An observed object is sending its new status
**/
void Worker::setObservableStatus(unsigned int identifier, const char* status, void* callbackParam)
{
  switch(identifier)
  {
    case OBSERVABLE_HTTPDOWNLOADER:
      // callbackParam is the HANDLE of a window, it should not be equal to NULL
      assert(callbackParam != NULL);
      assert(status != NULL);

      wsprintf(buffer1, "%s -- %s", TEXT_UPDATE_DATABASE, status);
      setProgress((HWND)callbackParam, buffer1);
      break;

    // Unknown observable object??
    default:
      assert(false);
      break;
  }
}
