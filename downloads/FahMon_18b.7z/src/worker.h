/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
          
****************************************************************************/

#ifndef _WORKER_H
#define _WORKER_H

#include "fahMon.h"
#include "observer.h"
#include "queueStorage.h"

class Worker : public Observer
{
public:
  typedef enum _JOB
  {
    // Download the current psummary from Stanford's website and update the local points file
    //  wParam: NULL
    //  lParam: NULL
    JOB_UPDATEPOINTS,
    // lParam: char* errorMsg    NULL if no error occured
    JOB_END_UPDATEPOINTS,

    // Load information about a client
    //  wParam: FahClient *client
    //  lParam: unsigned int clientIndex
    JOB_LOADCLIENT,
    // Load information about all the known clients
    //  wParam: NULL
    //  lParam: NULL
    //  remark: A JOB_END_LOADCLIENT is generated for each loaded client
    JOB_LOADALLCLIENTS,
    // lParam: unsigned int clientIndex
    JOB_END_LOADCLIENT,


    // Open the default browser on the stats page of a user
    //  wParam: const char* userName
    //  lParam: const char* teamNumber
    JOB_OPENBROWSERSTATS,


    // Stop the thread
    //  wParam: NULL
    //  lParam: NULL
    JOB_QUIT
  } JOB;

protected:

  typedef struct _JOBDESC
  {
    HWND mHDlg;
    JOB mJob;
    WPARAM mWParam;
    LPARAM mLParam;
  } JobDesc;

  DWORD mThreadID;
  HANDLE mHSemaphore;
  CRITICAL_SECTION mHCriticalSection;
  QueueStorage mQueue;
  char *buffer1, *buffer2;

  static DWORD WINAPI staticThreadProc(void *param);
  DWORD threadProc(void);

  void onUpdatePoints(JobDesc *job);
  void onOpenBrowserStats(JobDesc *job) const;
  void onLoadClient(JobDesc *job) const;
  void onLoadAllClients(JobDesc *job) const;

  void setProgress(HWND hWnd, const char *msg) const;

public:

  static Worker* mInstance;

  Worker(void);
  ~Worker(void);

  void addJob(HWND hDlg, JOB job, WPARAM wParam, LPARAM lParam);
  virtual void setObservableStatus(unsigned int identifier, const char* status, void* callbackParam);
};


#endif
