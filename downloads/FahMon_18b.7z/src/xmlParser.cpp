/****************************************************************************

Copyright 2003-2005 Fran�ois Ingelrest

This file is part of FahMon.

FAHMon is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FAHMon is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FAHMon; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
          
****************************************************************************/

#include "xmlParser.h"
#include "tools.h"

#define CR 13
#define LF 10
#define VALID_POS (mCurrentPos < mToBeParsedLength)


/**
 * Constructor
**/
XMLParser::XMLParser(char* toBeParsed) : mTextStep(256)
{
  mToBeParsed       = toBeParsed;
  mToBeParsedLength = lstrlen(toBeParsed);
  mCurrentPos       = 0;
  mCurrentLine      = 1;

  mCurrentToken = TK_END;

  mTextMaxLength = mTextStep;
  mText          = new char[mTextMaxLength];
  mText[0]       = '\0';
  mTextLength    = 0;

  // Initialize separators
  FillMemory(mSeparators, 256 * sizeof(bool), false);
  mSeparators[' ']  = true;
  mSeparators[CR]   = true;
  mSeparators[LF]   = true;
  mSeparators['\t'] = true;
}


/**
 * Destructor
**/
XMLParser::~XMLParser(void)
{
  delete[] mText;
}


/**
 * Add a tag to the list
**/
void XMLParser::addTag(const char* tag, unsigned int value)
{
  char* newTag;
  unsigned int length, *newValue;

  // Store the tag ...
  length = lstrlen(tag) + 1;
  newTag = new char[length];
  CopyMemory(newTag, tag, length);
  mKnownTagsAscii.addItem(newTag);

  // ... And its value
  newValue  = new unsigned int;
  *newValue = value;
  mKnownTagsValue.addItem(newValue);
}


/**
 * Convert an ascii string to the corresponding tag
**/
inline void XMLParser::atotag(const char* tag, unsigned int length)
{
  unsigned int i;

  for(i=0; i<mKnownTagsAscii.getNbItems(); ++i)
    if(Tools::strcmp(mKnownTagsAscii.getItem(i), tag, length) == true)
    {
      mCurrentTag = *(mKnownTagsValue.getItem(i));
      return;
    }

  // Unknown tag?
  if(mCurrentToken == TK_START_TAG)
    mCurrentToken = TK_UNKNOWN_START_TAG;
  else
    mCurrentToken = TK_UNKNOWN_END_TAG;
}


/**
 * Find the next tag
**/
void XMLParser::nextToken(void)
{
  unsigned int oldPos;

  // Skip all the separators
  while(true)
  {
    if(!VALID_POS)
    {
      mCurrentToken = TK_END;
      return;
    }

    if(!mSeparators[mToBeParsed[mCurrentPos]])
      break;

    if(mToBeParsed[mCurrentPos] == LF)
      ++mCurrentLine;

    ++mCurrentPos;
  }

  // Is it a tag?
  if(mToBeParsed[mCurrentPos] == '<')
  {
    ++mCurrentPos;

    // Is it a closing or an opening tag?
    if(mToBeParsed[mCurrentPos] == '/')
    {
      mCurrentToken = TK_END_TAG;
      ++mCurrentPos;
    }
    else
      mCurrentToken = TK_START_TAG;

    // Find the end of the name of the tag
    oldPos = mCurrentPos;
    while(VALID_POS && mToBeParsed[mCurrentPos] != '>' && !mSeparators[mToBeParsed[mCurrentPos]])
      ++mCurrentPos;

    // Determine what is this tag
    atotag(&mToBeParsed[oldPos], mCurrentPos - oldPos);

    // Find the closing character
    while(VALID_POS && mToBeParsed[mCurrentPos++] != '>')
    {
      if(mToBeParsed[mCurrentPos-1] == LF)
        ++mCurrentLine;
    }
  }
  else
  {
    mCurrentToken = TK_TEXT;
    oldPos = mCurrentPos;
    while(VALID_POS && mToBeParsed[mCurrentPos] != '<')
    {
      if(mToBeParsed[mCurrentPos] == LF)
        ++mCurrentLine;
      mCurrentPos++;
    }

    mTextLength = mCurrentPos - oldPos + 1;
    if(mTextLength > mTextMaxLength)
    {
      while(mTextLength > mTextMaxLength)
        mTextMaxLength += mTextStep;

      delete[] mText;
      mText = new char[mTextMaxLength];
    }
    CopyMemory(mText, &mToBeParsed[oldPos], --mTextLength);
    mText[mTextLength] = '\0';
  }
}
